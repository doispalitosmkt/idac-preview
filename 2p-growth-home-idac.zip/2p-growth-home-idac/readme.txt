=== 2P Growth Home (IDAC) ===
Contributors: doispalitosmkt
Tags: landing-page, homepage, idac
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 0.1.2
License: Proprietary

Disponibiliza a nova página inicial institucional do IDAC como um template independente do Elementor.

== Installation ==

1. Envie o arquivo ZIP em Plugins > Adicionar plugin > Enviar plugin.
2. Ative “2P Growth Home (IDAC)”.
3. Crie uma página chamada “Nova Home”.
4. Selecione o template “2P Growth Home (IDAC)” nos atributos da página.
5. Valide a página e, após aprovação, selecione-a em Configurações > Leitura > Página inicial.
6. Em Configurações > 2P Growth Home (IDAC), informe o endpoint seguro do formulário e, se necessário, as URLs definitivas dos vídeos.

== Integração ==

O plugin não inclui credenciais do RD Station no navegador. O campo de endpoint deve receber a URL de uma função segura que faça a comunicação com o CRM.

Os vídeos pesados ficam externos ao ZIP. Enquanto não houver CDN ou URLs da Biblioteca de mídia, o plugin utiliza os arquivos do preview público como fallback.

As atualizações são consultadas em um manifesto público gerado pelo repositório-fonte privado. Nenhuma credencial do GitHub é necessária no WordPress.

== Changelog ==

= 0.1.2 =
* Primeira versão instalável do template da nova home do IDAC.

