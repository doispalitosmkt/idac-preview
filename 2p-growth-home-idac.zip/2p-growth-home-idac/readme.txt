=== 2P Growth Home (IDAC) ===
Contributors: doispalitosmkt
Tags: landing-page, homepage, idac
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 0.3.4
License: Proprietary

Home e páginas internas do IDAC com templates próprios, prévia e migração reversível pelo painel.

== Menu principal ==

A versão 0.3.1 usa o mesmo menu na home e nas internas do plugin. Em Configurações > 2P Growth Home (IDAC) > Menu principal do site, use Criar e vincular menu do IDAC para iniciar com os links sugeridos, ou vincule um menu existente em Aparência > Menus. Depois, edite os links em Aparência > Menus. A atualização preserva menus e locais já configurados.

== Atualização para as páginas internas ==

A versão 0.3.0 acrescenta 11 modelos de internas. A 0.3.2 consolida os catálogos Presencial e Online na seção de cursos da home. Os 301 entram em vigor com a home do plugin publicada e podem ser desmarcados em Configurações > Páginas internas IDAC. As seleções dos demais redirecionamentos e dos modelos são preservadas na atualização.

O canal Instituto DAC e a playlist pública IDACast vêm configurados. Em Configurações > 2P Growth Home (IDAC), os campos Canal do IDAC no YouTube e Playlist do IDACast permitem atualizar os endereços. O player é carregado a pedido do visitante.

1. Atualize este mesmo plugin pelo painel; preserve suas configurações de RD Station, Google Sheets e vídeos.
2. Acesse Configurações > Páginas internas IDAC.
3. Abra as prévias autenticadas. Nelas, nenhum formulário envia dados e a indexação está desativada.
4. Selecione as páginas aprovadas ou use Selecionar páginas de conteúdo. A política depende de validação específica do texto pelo IDAC.
5. Clique em Aplicar páginas selecionadas. As páginas existentes mantêm seus IDs, URLs, conteúdo Elementor e metadados armazenados.
6. Limpe o cache pelo painel e confira as URLs afetadas.
7. Gerencie as regras de redirecionamento na seção separada. Presencial e Online levam à seção de cursos da home quando os dois 301 estão ativos.
8. Para voltar à apresentação anterior, use Reverter este lote no histórico e limpe o cache. Alterações manuais posteriores ao lote são preservadas e sinalizadas.

Não é necessário recriar páginas no editor, editar o tema ou acessar o servidor. A versão de apresentação é distribuída no código do plugin; alterações editoriais desse conteúdo exigem uma nova versão do pacote.

== Installation ==

1. Envie o arquivo ZIP em Plugins > Adicionar plugin > Enviar plugin.
2. Ative “2P Growth Home (IDAC)”.
3. Crie uma página chamada “Nova Home”.
4. Selecione o template “2P Growth Home (IDAC)” nos atributos da página.
5. Valide a página e, após aprovação, selecione-a em Configurações > Leitura > Página inicial.
6. Em Configurações > 2P Growth Home (IDAC), salve o token da instância do RD Station CRM e, se necessário, as URLs definitivas dos vídeos.
7. Teste a conexão e clique em “Preparar campos no RD Station”.
8. Publique o Google Apps Script da lista de próximas turmas e salve a URL `/exec` e o segredo compartilhado na mesma tela.
9. Limpe o LiteSpeed Cache e envie um lead real de teste em cada fluxo.

== Integração ==

O plugin não inclui credenciais do RD Station no navegador. O token fica no WordPress e a comunicação com o CRM ocorre somente no servidor.

O formulário cria um contato e uma negociação, usa o funil e o estágio padrão da conta e registra interesse, tipo de lead, objetivo e origem em campos estruturados e no histórico. A fonte da negociação é “Site IDAC”. Há validação, rate limit e deduplicação.

Os cards marcados como “Turmas abertas” aguardam a confirmação do RD Station e então encaminham o visitante para o WhatsApp do IDAC. Uma falha no CRM impede o redirecionamento.

Os cards “Quero participar da próxima turma” abrem um modal com os cursos atuais. Esse cadastro não vai para o RD Station: o servidor WordPress o envia exclusivamente ao Google Sheets por um Apps Script autenticado com segredo compartilhado.

O código que deve ser publicado no Google Apps Script acompanha o ZIP em `integrations/idac-course-waitlist.gs`. Configure a propriedade de script `IDAC_WAITLIST_SECRET`, publique como Web App executado pelo proprietário e salve a URL `/exec` e o mesmo segredo na tela do plugin.

O endpoint externo é opcional e só deve ser usado quando existir uma função intermediária própria.

Os vídeos pesados ficam externos ao ZIP. Enquanto não houver CDN ou URLs da Biblioteca de mídia, o plugin utiliza os arquivos do preview público como fallback.

As atualizações são consultadas em um manifesto público gerado pelo repositório-fonte privado. Nenhuma credencial do GitHub é necessária no WordPress.

== Changelog ==

= 0.3.4 =
* Onze páginas internas com conteúdo reformulado e identidade da home aprovada.
* Prévias autenticadas sem indexação e sem envio dos formulários.
* Aplicação e reversão em lote, preservando IDs, URLs, conteúdo Elementor e metadados.
* Canonicals e metadados próprios, com integração aos filtros de SEO do WordPress e Yoast.
* Regras opcionais de 301 e noindex específico da home antiga, sem alteração automática na instalação.
* Correção do retorno do Google Apps Script para não exibir erro após a gravação bem-sucedida.
* Modal separado para a lista de próximas turmas, com seleção múltipla dos cursos atuais.
* Entrega exclusiva ao Google Sheets, sem criar lead no RD Station.
* Proxy WordPress seguro, validação, rate limit e deduplicação para a lista de turmas.
* Formulário simplificado com uma única opção geral de cursos presenciais.
* Redirecionamento pós-RD Station para o WhatsApp nos cards de Turmas abertas.
* Preparação automática e idempotente dos campos do formulário e da fonte Site IDAC.
* Mapeamento estruturado dos próximos leads e remoção da avaliação automática Muito frio.
* Menu de cursos com acessos separados para modalidades presenciais e online.
* Integração direta e protegida do formulário com o RD Station CRM.
* Criação de contato, negociação e anotação com o contexto do lead.
* Teste de token, validação, rate limit, deduplicação e diagnóstico administrativo.

