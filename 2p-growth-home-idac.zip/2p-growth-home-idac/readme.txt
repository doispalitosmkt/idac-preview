=== 2P Growth Home (IDAC) ===
Contributors: doispalitosmkt
Tags: landing-page, homepage, idac
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 0.2.2
License: Proprietary

Disponibiliza a nova página inicial institucional do IDAC como um template independente do Elementor.

== Installation ==

1. Envie o arquivo ZIP em Plugins > Adicionar plugin > Enviar plugin.
2. Ative “2P Growth Home (IDAC)”.
3. Crie uma página chamada “Nova Home”.
4. Selecione o template “2P Growth Home (IDAC)” nos atributos da página.
5. Valide a página e, após aprovação, selecione-a em Configurações > Leitura > Página inicial.
6. Em Configurações > 2P Growth Home (IDAC), salve o token da instância do RD Station CRM e, se necessário, as URLs definitivas dos vídeos.
7. Teste a conexão e clique em “Preparar campos no RD Station”.
8. Limpe o LiteSpeed Cache e envie um lead real de teste.

== Integração ==

O plugin não inclui credenciais do RD Station no navegador. O token fica no WordPress e a comunicação com o CRM ocorre somente no servidor.

O formulário cria um contato e uma negociação, usa o funil e o estágio padrão da conta e registra interesse, tipo de lead, objetivo e origem em campos estruturados e no histórico. A fonte da negociação é “Site IDAC”. Há validação, rate limit e deduplicação.

O endpoint externo é opcional e só deve ser usado quando existir uma função intermediária própria.

Os vídeos pesados ficam externos ao ZIP. Enquanto não houver CDN ou URLs da Biblioteca de mídia, o plugin utiliza os arquivos do preview público como fallback.

As atualizações são consultadas em um manifesto público gerado pelo repositório-fonte privado. Nenhuma credencial do GitHub é necessária no WordPress.

== Changelog ==

= 0.2.2 =
* Preparação automática e idempotente dos campos do formulário e da fonte Site IDAC.
* Mapeamento estruturado dos próximos leads e remoção da avaliação automática Muito frio.
* Menu de cursos com acessos separados para modalidades presenciais e online.
* Integração direta e protegida do formulário com o RD Station CRM.
* Criação de contato, negociação e anotação com o contexto do lead.
* Teste de token, validação, rate limit, deduplicação e diagnóstico administrativo.

