=== 2P Growth Home (IDAC) ===
Contributors: doispalitosmkt
Tags: landing-page, homepage, idac
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 0.2.7
License: Proprietary

Disponibiliza a nova página inicial institucional do IDAC como um template independente do Elementor.

== Installation ==

1. Envie o arquivo ZIP em Plugins > Adicionar plugin > Enviar plugin.
2. Ative “2P Growth Home (IDAC)”.
3. Crie uma página chamada “Nova Home”.
4. Selecione o template “2P Growth Home (IDAC)” nos atributos da página.
5. Valide a página e, após aprovação, selecione-a em Configurações > Leitura > Página inicial.
6. Em Configurações > 2P Growth Home (IDAC), salve o token da instância do RD Station CRM e, se necessário, as URLs definitivas dos vídeos.
7. Teste a conexão e clique em “Preparar campos no RD Station”.
8. Publique o Google Apps Script da lista de próximas turmas e salve a URL `/exec` e o segredo compartilhado na mesma tela.
9. Limpe o LiteSpeed Cache e envie um lead real de teste em cada fluxo.

== Integração ==

O plugin não inclui credenciais do RD Station no navegador. O token fica no WordPress e a comunicação com o CRM ocorre somente no servidor.

O formulário cria um contato e uma negociação, usa o funil e o estágio padrão da conta e registra interesse, tipo de lead, objetivo e origem em campos estruturados e no histórico. A fonte da negociação é “Site IDAC”. Há validação, rate limit e deduplicação.

Os cards marcados como “Turmas abertas” aguardam a confirmação do RD Station e então encaminham o visitante para o WhatsApp do IDAC. Uma falha no CRM impede o redirecionamento.

Os cards “Quero participar da próxima turma” abrem um modal com os cursos atuais. Esse cadastro não vai para o RD Station: o servidor WordPress o envia exclusivamente ao Google Sheets por um Apps Script autenticado com segredo compartilhado.

O código que deve ser publicado no Google Apps Script acompanha o ZIP em `integrations/idac-course-waitlist.gs`. Configure a propriedade de script `IDAC_WAITLIST_SECRET`, publique como Web App executado pelo proprietário e salve a URL `/exec` e o mesmo segredo na tela do plugin.

O endpoint externo é opcional e só deve ser usado quando existir uma função intermediária própria.

Os vídeos pesados ficam externos ao ZIP. Enquanto não houver CDN ou URLs da Biblioteca de mídia, o plugin utiliza os arquivos do preview público como fallback.

As atualizações são consultadas em um manifesto público gerado pelo repositório-fonte privado. Nenhuma credencial do GitHub é necessária no WordPress.

== Changelog ==

= 0.2.7 =
* Correção do retorno do Google Apps Script para não exibir erro após a gravação bem-sucedida.
* Modal separado para a lista de próximas turmas, com seleção múltipla dos cursos atuais.
* Entrega exclusiva ao Google Sheets, sem criar lead no RD Station.
* Proxy WordPress seguro, validação, rate limit e deduplicação para a lista de turmas.
* Formulário simplificado com uma única opção geral de cursos presenciais.
* Redirecionamento pós-RD Station para o WhatsApp nos cards de Turmas abertas.
* Preparação automática e idempotente dos campos do formulário e da fonte Site IDAC.
* Mapeamento estruturado dos próximos leads e remoção da avaliação automática Muito frio.
* Menu de cursos com acessos separados para modalidades presenciais e online.
* Integração direta e protegida do formulário com o RD Station CRM.
* Criação de contato, negociação e anotação com o contexto do lead.
* Teste de token, validação, rate limit, deduplicação e diagnóstico administrativo.

