/**
 * Google Apps Script endpoint for the IDAC course waitlist.
 *
 * Deploy this file as a Web App and set the Script Property
 * IDAC_WAITLIST_SECRET. WordPress is the only intended caller.
 */

const IDAC_WAITLIST_SPREADSHEET_ID = '1PPXwpy-Az5Ja5X0oMg78MCxa3rI40KacBLomAbp7Dxs';
const IDAC_WAITLIST_SHEET_NAME = 'Página1';
const IDAC_WAITLIST_HEADERS = [
  'Recebido em',
  'Nome completo',
  'E-mail',
  'WhatsApp',
  'Cursos de interesse',
  'Origem do CTA',
  'Página de origem',
  'Consentimento',
];

function doPost(event) {
  try {
    const payload = JSON.parse(event?.postData?.contents || '{}');
    const expectedSecret = String(
      PropertiesService.getScriptProperties().getProperty('IDAC_WAITLIST_SECRET') || '',
    );

    if (!expectedSecret || String(payload.secret || '') !== expectedSecret) {
      throw new Error('Unauthorized request.');
    }

    const name = sanitizeCell_(payload.name);
    const email = sanitizeCell_(payload.email);
    const phone = sanitizeCell_(payload.phone);
    const courses = Array.isArray(payload.courses)
      ? payload.courses.map(sanitizeCell_).filter(Boolean)
      : [];

    if (!name || !email || !phone || !courses.length || payload.privacy !== true) {
      throw new Error('Invalid waitlist payload.');
    }

    const lock = LockService.getScriptLock();
    lock.waitLock(10000);

    try {
      const spreadsheet = SpreadsheetApp.openById(IDAC_WAITLIST_SPREADSHEET_ID);
      spreadsheet.setSpreadsheetTimeZone('America/Sao_Paulo');
      const sheet = spreadsheet.getSheetByName(IDAC_WAITLIST_SHEET_NAME);

      if (!sheet) throw new Error('Destination sheet not found.');

      ensureHeaders_(sheet);

      const nextRow = sheet.getLastRow() + 1;
      sheet.getRange(nextRow, 1, 1, IDAC_WAITLIST_HEADERS.length).setValues([[
        new Date(),
        name,
        email,
        phone,
        courses.join(' | '),
        sanitizeCell_(payload.cta_origin),
        sanitizeCell_(payload.page_url),
        'Sim',
      ]]);
      sheet.getRange(nextRow, 1).setNumberFormat('dd/MM/yyyy HH:mm:ss');
    } finally {
      lock.releaseLock();
    }

    return jsonResponse_({ success: true });
  } catch (error) {
    console.error(error);
    return jsonResponse_({ success: false, message: 'Unable to append waitlist entry.' });
  }
}

function ensureHeaders_(sheet) {
  if (String(sheet.getRange(1, 1).getValue() || '').trim()) return;

  const headerRange = sheet.getRange(1, 1, 1, IDAC_WAITLIST_HEADERS.length);
  headerRange
    .setValues([IDAC_WAITLIST_HEADERS])
    .setFontWeight('bold')
    .setBackground('#f1f3f4')
    .setFontColor('#202124')
    .setVerticalAlignment('middle');

  sheet.setFrozenRows(1);
  sheet.setRowHeight(1, 34);
  sheet.autoResizeColumns(1, IDAC_WAITLIST_HEADERS.length);
  sheet.setColumnWidth(5, 380);
  sheet.setColumnWidth(7, 320);
}

function sanitizeCell_(value) {
  const text = String(value ?? '').trim().slice(0, 2000);
  return /^[=+\-@]/.test(text) ? `'${text}` : text;
}

function jsonResponse_(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
