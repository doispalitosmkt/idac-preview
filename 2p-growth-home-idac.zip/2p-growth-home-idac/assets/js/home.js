const endpoint = String(window.twoPGrowthHomeConfig?.leadEndpoint || "").trim();
const waitlistEndpoint = String(window.twoPGrowthHomeConfig?.waitlistEndpoint || "").trim();

const leadIntegrationConfig = Object.freeze({
  endpoint,
  provider: "rd-station-crm",
  schemaVersion: "1.0",
  submissionIdentifiers: Object.freeze({
    curso: "site-idac-curso",
    projeto: "site-idac-projeto",
    geral: "site-idac-contato",
  }),
});

const waitlistIntegrationConfig = Object.freeze({
  endpoint: waitlistEndpoint,
  provider: "google-sheets",
  schemaVersion: "1.0",
});

document.documentElement.classList.add("js");

const attributionStorageKey = "idac-attributed-landing-url";
const attributionQueryParameters = [
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_content",
  "utm_term",
];

const getAttributedPageUrl = () => {
  const currentUrl = new URL(window.location.href);
  currentUrl.hash = "";
  const hasUtm = attributionQueryParameters.some((parameter) => currentUrl.searchParams.has(parameter));

  try {
    if (hasUtm) {
      window.sessionStorage.setItem(attributionStorageKey, currentUrl.toString());
      return currentUrl.toString();
    }

    const storedUrl = window.sessionStorage.getItem(attributionStorageKey);
    if (storedUrl) {
      const parsedStoredUrl = new URL(storedUrl);
      if (parsedStoredUrl.origin === currentUrl.origin) return parsedStoredUrl.toString();
    }

    window.sessionStorage.setItem(attributionStorageKey, currentUrl.toString());
  } catch {
    // Storage may be unavailable in privacy-restricted browsers; the current URL still preserves UTMs.
  }

  return currentUrl.toString();
};

const header = document.querySelector("[data-header]");
const menu = document.querySelector("[data-menu]");
const menuToggle = document.querySelector("[data-menu-toggle]");
const menuLabel = document.querySelector("[data-menu-label]");

const setMenuState = (isOpen) => {
  if (!menu || !menuToggle || !menuLabel || !header) return;

  menu.classList.toggle("is-open", isOpen);
  header.classList.toggle("is-menu-open", isOpen);
  document.body.classList.toggle("menu-open", isOpen);
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuLabel.textContent = isOpen ? "Fechar" : "Menu";
};

const updateHeader = () => {
  header?.classList.toggle("is-scrolled", window.scrollY > 24);
};

updateHeader();
window.addEventListener("scroll", updateHeader, { passive: true });

menuToggle?.addEventListener("click", () => {
  setMenuState(menuToggle.getAttribute("aria-expanded") !== "true");
});

const submenuParents = [...(menu?.querySelectorAll(".menu-item-has-children") || [])];

const closeSubmenus = (except = null) => {
  submenuParents.forEach((parent) => {
    if (parent === except) return;
    parent.classList.remove("is-submenu-open");
    const trigger = parent.querySelector(":scope > [data-submenu-toggle], :scope > a");
    trigger?.setAttribute("aria-expanded", "false");
  });
};

submenuParents.forEach((parent) => {
  const trigger = parent.querySelector(":scope > [data-submenu-toggle], :scope > a");
  const submenu = parent.querySelector(":scope > .sub-menu");
  if (!trigger || !submenu) return;

  trigger.setAttribute("aria-haspopup", "true");
  trigger.setAttribute("aria-expanded", "false");
  trigger.addEventListener("click", (event) => {
    event.preventDefault();
    const shouldOpen = !parent.classList.contains("is-submenu-open");
    closeSubmenus(parent);
    parent.classList.toggle("is-submenu-open", shouldOpen);
    trigger.setAttribute("aria-expanded", String(shouldOpen));
  });
});

menu?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    if (link.parentElement?.classList.contains("menu-item-has-children")) return;
    closeSubmenus();
    setMenuState(false);
  });
});

document.addEventListener("click", (event) => {
  if (menu && !menu.contains(event.target)) closeSubmenus();
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeSubmenus();
    setMenuState(false);
  }
});

window.addEventListener("resize", () => {
  if (window.innerWidth > 900) {
    closeSubmenus();
    setMenuState(false);
  }
});

const revealItems = document.querySelectorAll("[data-reveal]");

if ("IntersectionObserver" in window) {
  const revealObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      });
    },
    { threshold: 0.12, rootMargin: "0px 0px -48px" },
  );

  revealItems.forEach((item) => revealObserver.observe(item));
} else {
  revealItems.forEach((item) => item.classList.add("is-visible"));
}

const navLinks = [...document.querySelectorAll(".site-nav a")]
  .map((link) => {
    try {
      const url = new URL(link.href, window.location.href);
      const isCurrentDocument =
        url.origin === window.location.origin &&
        url.pathname.replace(/\/$/, "") === window.location.pathname.replace(/\/$/, "");

      return isCurrentDocument && url.hash ? { link, hash: url.hash } : null;
    } catch {
      return null;
    }
  })
  .filter(Boolean);
const observedSections = navLinks
  .map(({ hash }) => document.querySelector(hash))
  .filter(Boolean);

if ("IntersectionObserver" in window && observedSections.length) {
  const navObserver = new IntersectionObserver(
    (entries) => {
      const visibleEntry = entries
        .filter((entry) => entry.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];

      if (!visibleEntry) return;

      navLinks.forEach(({ link, hash }) => {
        const isCurrent = hash === `#${visibleEntry.target.id}`;
        link.classList.toggle("is-current", isCurrent);
        if (isCurrent) link.setAttribute("aria-current", "location");
        else link.removeAttribute("aria-current");
      });
    },
    { rootMargin: "-35% 0px -55%", threshold: [0, 0.2, 0.6] },
  );

  observedSections.forEach((section) => navObserver.observe(section));
}

document.querySelectorAll("[data-structure-carousel]").forEach((carousel) => {
  const slides = [...carousel.querySelectorAll("[data-carousel-slide]")];
  const dots = [...carousel.querySelectorAll("[data-carousel-dot]")];
  const previousButton = carousel.querySelector("[data-carousel-prev]");
  const nextButton = carousel.querySelector("[data-carousel-next]");
  const status = carousel.querySelector("[data-carousel-status]");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

  if (slides.length < 2) return;

  let currentIndex = 0;
  let autoplayTimer;
  let isVisible = false;
  let isInteracting = false;

  const stopAutoplay = () => {
    window.clearInterval(autoplayTimer);
    autoplayTimer = undefined;
  };

  const startAutoplay = () => {
    stopAutoplay();
    if (reducedMotion.matches || !isVisible || isInteracting || document.hidden) return;

    autoplayTimer = window.setInterval(() => {
      showSlide(currentIndex + 1);
    }, 5600);
  };

  const showSlide = (nextIndex, announce = false) => {
    currentIndex = (nextIndex + slides.length) % slides.length;

    slides.forEach((slide, index) => {
      const isActive = index === currentIndex;
      slide.classList.toggle("is-active", isActive);
      slide.setAttribute("aria-hidden", String(!isActive));
    });

    dots.forEach((dot, index) => {
      const isActive = index === currentIndex;
      dot.classList.toggle("is-active", isActive);
      if (isActive) dot.setAttribute("aria-current", "true");
      else dot.removeAttribute("aria-current");
    });

    if (announce && status) {
      const description = slides[currentIndex].querySelector("img")?.alt || "Imagem da galeria";
      status.textContent = `Imagem ${currentIndex + 1} de ${slides.length}: ${description}`;
    }
  };

  const selectSlide = (nextIndex) => {
    showSlide(nextIndex, true);
    startAutoplay();
  };

  previousButton?.addEventListener("click", () => selectSlide(currentIndex - 1));
  nextButton?.addEventListener("click", () => selectSlide(currentIndex + 1));
  dots.forEach((dot, index) => dot.addEventListener("click", () => selectSlide(index)));

  carousel.addEventListener("keydown", (event) => {
    if (event.key === "ArrowLeft") selectSlide(currentIndex - 1);
    if (event.key === "ArrowRight") selectSlide(currentIndex + 1);
  });

  carousel.addEventListener("pointerenter", () => {
    isInteracting = true;
    stopAutoplay();
  });

  carousel.addEventListener("pointerleave", () => {
    isInteracting = false;
    startAutoplay();
  });

  carousel.addEventListener("focusin", () => {
    isInteracting = true;
    stopAutoplay();
  });

  carousel.addEventListener("focusout", () => {
    window.requestAnimationFrame(() => {
      if (carousel.contains(document.activeElement)) return;
      isInteracting = false;
      startAutoplay();
    });
  });

  if ("IntersectionObserver" in window) {
    const carouselObserver = new IntersectionObserver(
      ([entry]) => {
        isVisible = entry.isIntersecting;
        if (isVisible) startAutoplay();
        else stopAutoplay();
      },
      { threshold: 0.35 },
    );

    carouselObserver.observe(carousel);
  } else {
    isVisible = true;
    startAutoplay();
  }

  document.addEventListener("visibilitychange", startAutoplay);
  reducedMotion.addEventListener?.("change", startAutoplay);
  showSlide(0);
});

const activateVideo = (videoId) => {
  const frame = document.querySelector(`[data-video-frame="${videoId}"]`);
  const video = frame?.querySelector("video");
  const source = video?.querySelector("source[data-src]");

  if (!frame || !video || !source) return;

  document.querySelectorAll("video").forEach((otherVideo) => {
    if (otherVideo !== video) otherVideo.pause();
  });

  if (!source.src) {
    source.src = source.dataset.src;
    video.load();
  }

  frame.classList.add("is-playing");
  document
    .querySelectorAll(`[data-video-trigger="${videoId}"]`)
    .forEach((videoTrigger) => videoTrigger.setAttribute("aria-pressed", "true"));

  const playPromise = video.play();
  if (playPromise instanceof Promise) playPromise.catch(() => undefined);

  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ event: "video_start", video_name: videoId });
};

document.querySelectorAll("[data-video-trigger]").forEach((trigger) => {
  trigger.addEventListener("click", () => activateVideo(trigger.dataset.videoTrigger));
});

document.querySelectorAll("[data-video-frame]").forEach((frame) => {
  const video = frame.querySelector("video");
  const videoId = frame.dataset.videoFrame;

  video?.addEventListener("ended", () => {
    frame.classList.remove("is-playing");
    document
      .querySelectorAll(`[data-video-trigger="${videoId}"]`)
      .forEach((videoTrigger) => videoTrigger.setAttribute("aria-pressed", "false"));
  });
});

document.querySelectorAll("details").forEach((detail, index) => {
  detail.addEventListener("toggle", () => {
    if (!detail.open) return;

    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ event: "faq_open", question_id: `faq-${index + 1}` });
  });
});

const waitlistDialog = document.querySelector("[data-waitlist-dialog]");
const waitlistForm = waitlistDialog?.querySelector("[data-waitlist-form]");

if (waitlistDialog && waitlistForm) {
  const closeButton = waitlistDialog.querySelector("[data-waitlist-close]");
  const originField = waitlistForm.querySelector("[data-waitlist-origin-field]");
  const status = waitlistForm.querySelector("[data-waitlist-status]");
  const submitButton = waitlistForm.querySelector("[data-waitlist-submit]");
  const submitLabel = submitButton?.textContent || "Quero ser avisado";

  const setWaitlistStatus = (message = "", state = "") => {
    if (!status) return;
    status.textContent = message;
    status.classList.remove("is-success", "is-error", "is-pending");
    if (state) status.classList.add(`is-${state}`);
  };

  const closeWaitlist = () => {
    waitlistDialog.close();
  };

  document.querySelectorAll("[data-waitlist-trigger]").forEach((trigger) => {
    trigger.addEventListener("click", () => {
      waitlistForm.reset();
      setWaitlistStatus();
      if (originField) originField.value = trigger.dataset.waitlistOrigin || "proxima-turma";

      const selectedCourse = waitlistForm.querySelector(
        `input[name="courses"][value="${trigger.dataset.waitlistCourse || ""}"]`,
      );
      if (selectedCourse) selectedCourse.checked = true;

      waitlistDialog.showModal();
      document.body.classList.add("waitlist-open");
      waitlistForm.querySelector('input[name="name"]')?.focus();

      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: "course_waitlist_open",
        course: trigger.dataset.waitlistCourse,
        cta_location: trigger.dataset.waitlistOrigin,
      });
    });
  });

  closeButton?.addEventListener("click", closeWaitlist);
  waitlistDialog.addEventListener("click", (event) => {
    if (event.target === waitlistDialog) closeWaitlist();
  });
  waitlistDialog.addEventListener("close", () => {
    document.body.classList.remove("waitlist-open");
  });

  waitlistForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = new FormData(waitlistForm);
    if (data.get("website")) return;

    const courses = data.getAll("courses").map((course) => course.toString());
    if (!courses.length) {
      setWaitlistStatus("Escolha pelo menos um curso para acompanhar.", "error");
      waitlistForm.querySelector('input[name="courses"]')?.focus();
      return;
    }

    if (!waitlistIntegrationConfig.endpoint) {
      setWaitlistStatus(
        "A lista de interesse está pronta. A gravação será ativada assim que o conector da planilha for publicado.",
        "pending",
      );
      return;
    }

    const payload = {
      schema_version: waitlistIntegrationConfig.schemaVersion,
      destination: waitlistIntegrationConfig.provider,
      contact: {
        name: data.get("name")?.toString().trim(),
        email: data.get("email")?.toString().trim(),
        personal_phone: data.get("personal_phone")?.toString().trim(),
      },
      courses,
      attribution: {
        cta_origin: data.get("cta_origin")?.toString() || "proxima-turma",
        page_url: getAttributedPageUrl(),
        referrer: document.referrer,
      },
      consent: {
        privacy: data.get("privacy_consent") === "true",
      },
      website: data.get("website")?.toString() || "",
    };

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.setAttribute("aria-busy", "true");
      submitButton.textContent = "Enviando...";
    }
    setWaitlistStatus();

    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      event: "course_waitlist_submit",
      courses,
      cta_location: payload.attribution.cta_origin,
    });

    try {
      const response = await fetch(waitlistIntegrationConfig.endpoint, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        credentials: "omit",
        body: JSON.stringify(payload),
      });

      if (!response.ok) throw new Error(`Waitlist endpoint responded with ${response.status}`);

      waitlistForm.reset();
      setWaitlistStatus("Cadastro recebido. Avisaremos quando houver uma nova turma.", "success");
      window.dataLayer.push({ event: "course_waitlist_success", courses });
    } catch (error) {
      console.error("Não foi possível registrar o aviso de turma.", error);
      setWaitlistStatus("Não foi possível enviar agora. Tente novamente em alguns instantes.", "error");
      window.dataLayer.push({ event: "course_waitlist_error", courses });
    } finally {
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.removeAttribute("aria-busy");
        submitButton.textContent = submitLabel;
      }
    }
  });
}

const leadForm = document.querySelector("[data-lead-form]");

const openClassWhatsAppFollowUp = {
  phone: "5511992026448",
  text: "Olá, acabei de me cadastrar no site e gostaria de saber mais.",
};

if (leadForm) {
  const interestSelect = leadForm.querySelector("[data-lead-interest]");
  const leadTypeField = leadForm.querySelector("[data-lead-type-field]");
  const leadOriginField = leadForm.querySelector("[data-lead-origin-field]");
  const submissionField = leadForm.querySelector("[data-lead-submission-field]");
  const pagePathField = leadForm.querySelector("[data-page-path-field]");
  const context = leadForm.querySelector("[data-lead-form-context]");
  const status = leadForm.querySelector("[data-lead-form-status]");
  const submitButton = leadForm.querySelector("[data-lead-submit]");
  const submitLabel = submitButton?.textContent || "Enviar interesse";
  const query = new URLSearchParams(window.location.search);

  const setStatus = (message = "", state = "") => {
    if (!status) return;
    status.textContent = message;
    status.classList.remove("is-success", "is-error", "is-pending");
    if (state) status.classList.add(`is-${state}`);
  };

  const getSelectedOption = () => interestSelect?.selectedOptions?.[0];

  const syncClassification = () => {
    const option = getSelectedOption();
    const leadType = option?.dataset.leadType || "";
    const interestLabel = option?.value ? option.textContent.trim() : "";

    if (leadTypeField) leadTypeField.value = leadType;
    if (submissionField) {
      submissionField.value =
        leadIntegrationConfig.submissionIdentifiers[leadType] ||
        leadIntegrationConfig.submissionIdentifiers.geral;
    }

    if (context) {
      context.textContent = interestLabel
        ? `Interesse selecionado: ${interestLabel}.`
        : "Selecione seu interesse para que o contato seja encaminhado corretamente.";
    }
  };

  const selectIntent = (intent, origin) => {
    const option = [...(interestSelect?.options || [])].find((item) => item.value === intent);
    if (option && interestSelect) interestSelect.value = option.value;
    if (leadOriginField) leadOriginField.value = origin || "formulario-direto";
    syncClassification();
    setStatus();
  };

  const fillAttribution = () => {
    if (pagePathField) pagePathField.value = window.location.pathname;
    leadForm.querySelectorAll("[data-attribution-field]").forEach((field) => {
      field.value = query.get(field.dataset.attributionField) || "";
    });
  };

  const buildLeadPayload = () => {
    const data = new FormData(leadForm);
    const option = getSelectedOption();

    return {
      schema_version: leadIntegrationConfig.schemaVersion,
      destination: leadIntegrationConfig.provider,
      operation: "CREATE_CONTACT_AND_DEAL",
      submission_identifier: data.get("submission_identifier"),
      contact: {
        name: data.get("name")?.toString().trim(),
        email: data.get("email")?.toString().trim(),
        personal_phone: data.get("personal_phone")?.toString().trim(),
      },
      classification: {
        lead_type: data.get("cf_tipo_de_lead"),
        interest: data.get("cf_interesse_idac"),
        interest_label: option?.textContent.trim() || "",
        cta_origin: data.get("cf_origem_cta"),
      },
      deal: {
        status: "ongoing",
        routing_key: data.get("cf_tipo_de_lead"),
        title: option?.textContent.trim()
          ? `Site IDAC — ${option.textContent.trim()}`
          : "Site IDAC — Novo interesse",
      },
      attribution: {
        page_url: getAttributedPageUrl(),
        page_path: data.get("page_path"),
        referrer: document.referrer,
        utm_source: data.get("utm_source"),
        utm_medium: data.get("utm_medium"),
        utm_campaign: data.get("utm_campaign"),
        utm_content: data.get("utm_content"),
        utm_term: data.get("utm_term"),
      },
      message: data.get("message")?.toString().trim() || "",
      consent: {
        privacy: data.get("privacy_consent") === "true",
        legal_basis: data.get("legal_basis"),
      },
    };
  };

  document.querySelectorAll('a[data-cta-location][href="#contato"]').forEach((link) => {
    link.addEventListener("click", () => {
      selectIntent(link.dataset.ctaIntent || "geral", link.dataset.ctaLocation);

      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: "lead_form_open",
        cta_location: link.dataset.ctaLocation,
        cta_intent: link.dataset.ctaIntent,
        page_path: window.location.pathname,
      });
    });
  });

  interestSelect?.addEventListener("change", () => {
    if (leadOriginField) leadOriginField.value = "selecao-manual";
    syncClassification();
    setStatus();
  });

  leadForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const data = new FormData(leadForm);
    if (data.get("website")) return;

    syncClassification();
    const payload = buildLeadPayload();

    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({
      event: "lead_form_submit",
      form_name: "cta-final",
      lead_type: payload.classification.lead_type,
      lead_interest: payload.classification.interest,
      cta_location: payload.classification.cta_origin,
    });

    if (!leadIntegrationConfig.endpoint) {
      setStatus(
        "Formulário preparado. O envio será ativado assim que a conexão com o RD Station for configurada.",
        "pending",
      );
      window.dataLayer.push({ event: "lead_form_connection_pending", form_name: "cta-final" });
      return;
    }

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.setAttribute("aria-busy", "true");
      submitButton.textContent = "Enviando...";
    }
    setStatus();

    try {
      const response = await fetch(leadIntegrationConfig.endpoint, {
        method: "POST",
        headers: { Accept: "application/json", "Content-Type": "application/json" },
        credentials: "omit",
        body: JSON.stringify(payload),
      });

      if (!response.ok) throw new Error(`Lead endpoint responded with ${response.status}`);

      leadForm.reset();
      if (leadOriginField) leadOriginField.value = "formulario-direto";
      fillAttribution();
      syncClassification();
      const shouldOpenWhatsApp = payload.classification.cta_origin.startsWith("turma-aberta-");
      setStatus(
        shouldOpenWhatsApp
          ? "Cadastro recebido. Abrindo a conversa com a equipe do IDAC no WhatsApp."
          : "Interesse enviado. A equipe do IDAC entrará em contato.",
        "success",
      );
      window.dataLayer.push({ event: "lead_form_success", form_name: "cta-final" });

      if (shouldOpenWhatsApp) {
        const whatsappUrl = new URL("https://api.whatsapp.com/send/");
        whatsappUrl.searchParams.set("phone", openClassWhatsAppFollowUp.phone);
        whatsappUrl.searchParams.set("text", openClassWhatsAppFollowUp.text);
        window.dataLayer.push({
          event: "lead_whatsapp_redirect",
          form_name: "cta-final",
          cta_location: payload.classification.cta_origin,
        });
        window.location.assign(whatsappUrl.toString());
      }
    } catch (error) {
      console.error("Não foi possível enviar o lead.", error);
      setStatus("Não foi possível enviar agora. Tente novamente em alguns instantes.", "error");
      window.dataLayer.push({ event: "lead_form_error", form_name: "cta-final" });
    } finally {
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.removeAttribute("aria-busy");
        submitButton.textContent = submitLabel;
      }
    }
  });

  fillAttribution();
  const initialIntent = query.get("interesse");
  if (initialIntent) selectIntent(initialIntent, "url-param");
  else syncClassification();
}

document.querySelectorAll("[data-external]").forEach((link) => {
  link.addEventListener("click", () => {
    window.dataLayer = window.dataLayer || [];
    window.dataLayer.push({ event: `${link.dataset.external}_click` });
  });
});

document.querySelectorAll("[data-year]").forEach((year) => {
  year.textContent = String(new Date().getFullYear());
});
