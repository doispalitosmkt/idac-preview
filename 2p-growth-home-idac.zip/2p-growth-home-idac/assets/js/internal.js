(()=>{// Reaproveita os fluxos aprovados em main.js. Apenas o contexto da interna é acrescentado.
const page = document.body.dataset.internalPage;
const form = document.querySelector('[data-lead-form]');
if (page && form) {
  const input = form.querySelector('[data-lead-origin-field]');
  if (input && input.value === 'formulario-direto') input.value = `interna-${page}`;
}

})();