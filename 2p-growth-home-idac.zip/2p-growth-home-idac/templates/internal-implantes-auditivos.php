<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html><html class="two-p-growth-home-idac-document" <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>" /><meta name="viewport" content="width=device-width,initial-scale=1" /><meta name="theme-color" content="#101416" />
<link rel="icon" href="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'favicon.png' ) ); ?>" />
<?php two_p_idac_head(); wp_head(); ?></head>
<body <?php body_class( 'two-p-growth-home-idac idac-internal' ); ?> data-internal-page="implantes-auditivos">
<?php wp_body_open(); if ( two_p_idac_preview_key() ) { echo '<aside class="in-admin-preview">Prévia autenticada — nenhum formulário envia dados nesta visualização.</aside>'; } ?><a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
  <header class="site-header" data-header><div class="container header-inner">
    <a class="brand" href="<?php echo esc_url( two_p_idac_internal_url( '/' ) ); ?>" aria-label="Instituto DAC — início"><img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>" alt="Instituto DAC" width="214" height="89" /></a>
    <button class="menu-toggle" type="button" aria-controls="site-menu" aria-expanded="false" data-menu-toggle><span data-menu-label>Menu</span></button>
    
        <nav class="site-nav" id="site-menu" aria-label="Navegação principal" data-menu>
          <?php
          wp_nav_menu(
            array(
              'theme_location' => TWO_P_GROWTH_HOME_IDAC_MENU,
              'container'      => false,
              'menu_class'     => 'menu two-p-growth-home-menu',
              'fallback_cb'    => 'two_p_growth_home_idac_menu_fallback',
            )
          );
          ?>
        </nav><a class="button button-small header-cta" href="#contato" data-cta-intent="geral" data-cta-location="interna-implantes-auditivos-header">Falar com o IDAC</a>
  </div></header><main id="conteudo"><section class="in-hero"><div class="container in-hero-grid"><div class="in-hero-copy">
    <nav class="in-breadcrumb" aria-label="Localização"><a href="<?php echo esc_url( two_p_idac_internal_url( '/' ) ); ?>">Início</a><span aria-hidden="true">/</span><span>Formações</span></nav>
    <p class="eyebrow">Otorrinolaringologia</p><h1>Curso de Implantes Auditivos</h1>
    <p class="in-intro">Tecnologia, anatomia e planejamento. Conheça a formação em implantes auditivos que integra a trajetória de educação médica do Instituto DAC.</p>
    <div class="in-hero-actions"><a class="button" href="#contato" data-cta-intent="cursos" data-cta-location="interna-implantes-auditivos-hero">Consultar próximas oportunidades<span aria-hidden="true"> ↗</span></a><a class="in-text-link" href="#programa">Explorar a formação <span aria-hidden="true">↓</span></a></div>
    <p class="in-location"><span class="in-dot" aria-hidden="true"></span> Aclimação · São Paulo</p>
  </div><figure class="in-hero-figure"><img class="" src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-implantes-auditivos.jpg' ) ); ?>" alt="Referência visual de formação em implantes auditivos" width="1000" height="760" fetchpriority="high" /><figcaption><span>Conhecimento que se transforma em prática.</span><b aria-hidden="true">↗</b></figcaption></figure></div></section><div class="in-topics"><div class="container"><span><b>01</b>Anatomia do osso temporal</span><span><b>02</b>Planejamento cirúrgico</span><span><b>03</b>Implantes auditivos</span></div></div>
  <section class="in-section"><div class="container in-editorial"><div><p class="eyebrow">O encontro entre saber e fazer</p><h2>Amplie seu repertório.<br />Aprofunde sua prática.</h2></div><div><p class="in-lead">A edição XI reuniu o Instituto DAC e o Hospital CEMA, com atividades teóricas e práticas. Consulte a equipe sobre novas oportunidades nessa especialidade.</p><h3>Para quem é esta formação</h3><p>Médicos otorrinolaringologistas interessados em anatomia cirúrgica e em tecnologias de implantes auditivos.</p></div></div></section>
  <section class="in-section in-program" id="programa"><div class="container in-program-grid"><div><div class="in-section-head"><p class="eyebrow">Conteúdo da formação</p><h2>Um olhar mais próximo<br />sobre cada tema.</h2><p>Explore os eixos de estudo. A equipe do IDAC orienta sobre formato, programação e disponibilidade de cada nova oportunidade.</p></div><div class="in-modules"><details open><summary><span>01</span><h3>Sistemas de implantes auditivos</h3><b aria-hidden="true">+</b></summary><p>Conteúdos relacionados a implantes cocleares, condução óssea e implantes de orelha média.</p></details><details ><summary><span>02</span><h3>Anatomia cirúrgica e radiológica</h3><b aria-hidden="true">+</b></summary><p>Estudo do osso temporal e suas relações anatômicas.</p></details><details ><summary><span>03</span><h3>Indicações e planejamento</h3><b aria-hidden="true">+</b></summary><p>Temas de discussão sobre critérios de indicação e planejamento dos casos.</p></details><details ><summary><span>04</span><h3>Instrumental e tecnologia</h3><b aria-hidden="true">+</b></summary><p>Apresentação do instrumental e de recursos de planejamento cirúrgico.</p></details><details ><summary><span>05</span><h3>Abordagens cirúrgicas</h3><b aria-hidden="true">+</b></summary><p>Conteúdo dedicado às abordagens dos sistemas estudados.</p></details><details ><summary><span>06</span><h3>Prática de dissecção</h3><b aria-hidden="true">+</b></summary><p>Estudo anatômico em cadáveres frescos no ambiente de formação do IDAC.</p></details></div></div><aside class="in-course-aside"><span class="in-aside-mark" aria-hidden="true">↗</span><p class="eyebrow">Seu próximo passo</p><h2>Conte o que você<br />quer aprofundar.</h2><p>Converse com a equipe sobre essa formação e as possibilidades para o seu momento profissional.</p><a class="button" href="#contato" data-cta-intent="cursos" data-cta-location="interna-implantes-auditivos-programa">Conversar sobre a formação<span aria-hidden="true"> ↗</span></a><button class="in-waitlist" type="button" data-waitlist-trigger data-waitlist-course="implantes-auditivos" data-waitlist-origin="interna-implantes-auditivos">Quero participar da próxima turma <span aria-hidden="true">→</span></button><div class="in-aside-address">Instituto DAC<br />Rua Pedra Azul, 505<br />Aclimação · São Paulo</div></aside></div></section>
  <section class="in-section"><div class="container in-people"><div><p class="eyebrow">Conhecimento compartilhado</p><h2>Quem integra a<br />história desta formação.</h2><p>Profissionais apresentados no programa desta formação. Consulte a composição da equipe para cada nova edição.</p></div><ul><li>Prof. Dr. Andy de Oliveira Vicente</li></ul></div></section>
  <section class="in-structure"><div class="container in-structure-grid"><img class="" src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/idac-microscopio-real.webp' ) ); ?>" alt="Microscópio e estrutura de treinamento do Instituto DAC" width="1000" height="760" loading="lazy" /><div><p class="eyebrow">Um instituto, várias possibilidades</p><h2>A estrutura para<br />aprender fazendo.</h2><p>Ambiente, tecnologia e suporte operacional para conectar o conhecimento à experiência prática. Um espaço para médicos, professores, empresas e instituições de saúde.</p><a class="in-text-link" href="<?php echo esc_url( two_p_idac_internal_url( '/quem-somos/' ) ); ?>">Conheça o Instituto DAC <span aria-hidden="true">↗</span></a></div></div></section><section class="in-section in-related"><div class="container"><div class="in-section-head"><p class="eyebrow">Continue explorando</p><h2>Conhecimento que<br />atravessa especialidades.</h2></div><div class="in-related-grid"><a class="in-related-item" href="<?php echo esc_url( two_p_idac_internal_url( '/ii-otology-hands-on/' ) ); ?>"><img class="" src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-otologia.jpg' ) ); ?>" alt="Referência visual da especialidade de otologia" width="1000" height="760" loading="lazy" /><div><span>Otorrinolaringologia</span><h3>Otologia hands-on</h3><b aria-hidden="true">↗</b></div></a><a class="in-related-item" href="<?php echo esc_url( two_p_idac_internal_url( '/vias-de-acesso-e-disseccao-cirurgica-em-cavidades-toracica-e-abdominal-em-fresh-frozen-specimens/' ) ); ?>"><img class="" src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-anatomia-cirurgica.jpg' ) ); ?>" alt="Profissionais em ambiente de treinamento de anatomia cirúrgica" width="1000" height="760" loading="lazy" /><div><span>Cirurgia geral</span><h3>Vias de acesso</h3><b aria-hidden="true">↗</b></div></a></div></div></section><section class="final-cta" id="contato" aria-labelledby="final-cta-title">
        <div class="container final-cta-inner" data-reveal>
          <p class="eyebrow eyebrow-light">Comece uma conversa</p>
          <h2 id="final-cta-title">Qual experiência médica você quer construir?</h2>
          <p>
            Conte seu objetivo à equipe do IDAC e descubra o formato mais adequado para sua turma,
            treinamento ou projeto.
          </p>
          <form class="final-cta-form" data-lead-form data-integration="rd-station-crm">
            <p class="final-cta-form-context" data-lead-form-context aria-live="polite">
              Selecione seu interesse para que o contato seja encaminhado corretamente.
            </p>
            <div class="final-cta-form-row">
              <label>
                Nome completo
                <input type="text" name="name" autocomplete="name" required />
              </label>
              <label>
                WhatsApp
                <input type="tel" name="personal_phone" autocomplete="tel" placeholder="(11) 90000-0000" required />
              </label>
            </div>
            <label>
              E-mail
              <input type="email" name="email" autocomplete="email" required />
            </label>
            <label>
              Qual é o seu interesse?
              <select name="cf_interesse_idac" data-lead-interest required>
                <option value="">Selecione uma opção</option>
                <optgroup label="Cursos e próximas turmas">
                  <option value="cursos" data-lead-type="curso">Cursos presenciais e próximas turmas</option>
                </optgroup>
                <optgroup label="Treinamentos e projetos">
                  <option value="individual" data-lead-type="projeto">Mentoria médica individualizada</option>
                  <option value="professores" data-lead-type="projeto">Curso em Parceria com Professores</option>
                  <option value="corporativo" data-lead-type="projeto">Treinamento Corporativo para Médicos</option>
                  <option value="locacao-eventos" data-lead-type="projeto">Locação para workshops e eventos</option>
                  <option value="pesquisa" data-lead-type="projeto">Projeto de Pesquisa em Saúde</option>
                  <option value="inovacao" data-lead-type="projeto">Desenvolvimento e Validação de Tecnologia Médica</option>
                </optgroup>
                <optgroup label="Outros assuntos">
                  <option value="estrutura" data-lead-type="geral">Estrutura e localização</option>
                  <option value="duvida" data-lead-type="geral">Dúvidas e outras informações</option>
                  <option value="geral" data-lead-type="geral">Ainda não sei qual formato escolher</option>
                </optgroup>
              </select>
            </label>
            <label>
              Conte seu objetivo <span class="form-optional">(opcional)</span>
              <textarea
                name="message"
                rows="3"
                placeholder="Turma presencial, treinamento individual, parceria ou projeto corporativo"
              ></textarea>
            </label>
            <label class="final-cta-consent">
              <input type="checkbox" name="privacy_consent" value="true" required />
              <span>Li e concordo com o tratamento dos meus dados conforme o <a href="<?php echo esc_url( two_p_idac_internal_url( '/politica-de-privacidade/' ) ); ?>">Aviso de privacidade</a>.</span>
            </label>
            <input type="hidden" name="cf_tipo_de_lead" value="" data-lead-type-field />
            <input type="hidden" name="cf_origem_cta" value="interna-implantes-auditivos" data-lead-origin-field />
            <input type="hidden" name="submission_identifier" value="site-idac-contato" data-lead-submission-field />
            <input type="hidden" name="page_path" value="" data-page-path-field />
            <input type="hidden" name="utm_source" value="" data-attribution-field="utm_source" />
            <input type="hidden" name="utm_medium" value="" data-attribution-field="utm_medium" />
            <input type="hidden" name="utm_campaign" value="" data-attribution-field="utm_campaign" />
            <input type="hidden" name="utm_content" value="" data-attribution-field="utm_content" />
            <input type="hidden" name="utm_term" value="" data-attribution-field="utm_term" />
            <input type="hidden" name="legal_basis" value="consentimento" />
            <div class="final-cta-honeypot" aria-hidden="true">
              <label>Não preencha este campo<input type="text" name="website" tabindex="-1" autocomplete="off" /></label>
            </div>
            <button type="submit" class="button" data-lead-submit>Enviar interesse</button>
            <p class="final-cta-form-status" data-lead-form-status role="status" aria-live="polite"></p>
          </form>
        </div>
      </section></main><dialog class="waitlist-dialog" data-waitlist-dialog aria-labelledby="waitlist-title">
        <div class="waitlist-dialog-panel">
          <button class="waitlist-dialog-close" type="button" data-waitlist-close aria-label="Fechar formulário">×</button>
          <p class="eyebrow">Próximas turmas</p>
          <h2 id="waitlist-title">Avise-me quando uma nova turma abrir.</h2>
          <p class="waitlist-dialog-intro">
            Escolha um ou mais cursos para receber o contato da equipe quando houver uma nova oportunidade.
          </p>
          <form class="waitlist-form" data-waitlist-form>
            <div class="waitlist-form-row">
              <label>
                Nome completo
                <input type="text" name="name" autocomplete="name" required />
              </label>
              <label>
                WhatsApp
                <input type="tel" name="personal_phone" autocomplete="tel" placeholder="(11) 90000-0000" required />
              </label>
            </div>
            <label>
              E-mail
              <input type="email" name="email" autocomplete="email" required />
            </label>
            <fieldset class="waitlist-courses">
              <legend>Quais cursos você quer acompanhar?</legend>
              <div class="waitlist-course-grid">
                <label><input type="checkbox" name="courses" value="suturas" /> <span>Suturas</span></label>
                <label><input type="checkbox" name="courses" value="medicina-regenerativa" /> <span>Medicina Regenerativa</span></label>
                <label><input type="checkbox" name="courses" value="anatomia-topografica" /> <span>Anatomia Topográfica</span></label>
                <label><input type="checkbox" name="courses" value="via-aerea" /> <span>Via Aérea</span></label>
                <label><input type="checkbox" name="courses" value="radiofrequencia-nervo-periferico" /> <span>Radiofrequência de Nervo Periférico</span></label>
                <label><input type="checkbox" name="courses" value="implantes-auditivos" /> <span>Curso de Implantes Auditivos</span></label>
              </div>
            </fieldset>
            <label class="waitlist-consent">
              <input type="checkbox" name="privacy_consent" value="true" required />
              <span>Li e concordo com o tratamento dos meus dados conforme o <a href="<?php echo esc_url( two_p_idac_internal_url( '/politica-de-privacidade/' ) ); ?>">Aviso de privacidade</a>.</span>
            </label>
            <input type="hidden" name="cta_origin" value="proxima-turma" data-waitlist-origin-field />
            <div class="waitlist-honeypot" aria-hidden="true">
              <label>Não preencha este campo<input type="text" name="website" tabindex="-1" autocomplete="off" /></label>
            </div>
            <button class="button" type="submit" data-waitlist-submit>Quero ser avisado</button>
            <p class="waitlist-form-status" data-waitlist-status role="status" aria-live="polite"></p>
          </form>
        </div>
      </dialog><footer class="site-footer" id="rodape">
      <div class="container footer-grid">
        <div class="footer-brand">
          <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>" alt="Instituto DAC" width="214" height="89" loading="lazy" />
          <p>
            Educação médica prática, estrutura e operação para médicos, professores, empresas e
            instituições de saúde.
          </p>
          <a
            class="footer-contact"
            href="#contato"
            data-cta-location="rodape"
            data-cta-intent="geral"
          >Falar com o IDAC</a>
        </div>

        <nav class="footer-nav" aria-label="Navegação do rodapé">
          <h2>Explore</h2>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/quem-somos/' ) ); ?>">Quem somos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/contato/' ) ); ?>">Contato</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#modalidades' ) ); ?>">Modalidades</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#estrutura' ) ); ?>">Estrutura</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#diferenciais' ) ); ?>">Cursos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/quem-somos/#formacoes' ) ); ?>">Histórico de cursos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#depoimentos' ) ); ?>">Depoimentos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#faq' ) ); ?>">Perguntas frequentes</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#localizacao' ) ); ?>">Localização</a>
        </nav>

        <div class="footer-visit">
          <h2>Visite o IDAC</h2>
          <address>Rua Pedra Azul, 505<br />Aclimação — São Paulo, SP<br />CEP 04109-000</address>
          <a
            class="footer-route"
            href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
            target="_blank"
            rel="noopener noreferrer"
            data-external="maps"
          >Traçar rota até o instituto</a>

          <h2 class="footer-contact-title">Contato</h2>
          <a
            href="#contato"
            data-cta-location="rodape"
            data-cta-intent="geral"
          >(11) 91468-8835</a>
          <a href="mailto:comercial@institutodac.com">comercial@institutodac.com</a>
          <nav class="footer-social" aria-label="Instituto DAC nas redes sociais">
            <?php two_p_growth_home_idac_render_youtube_icon(); ?>
            <a href="https://www.instagram.com/instituto_dac/" aria-label="Instagram" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
            <a href="https://www.linkedin.com/company/instituto-dac/" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><circle cx="5.5" cy="6" r="1.8"/><path d="M4 9h3v11H4zm6 0h3v1.5c.6-1 1.6-1.8 3.4-1.8 2.7 0 3.6 1.7 3.6 4.4V20h-3v-6c0-1.6-.5-2.4-1.8-2.4S13 12.5 13 14v6h-3z"/></svg></a>
            <a href="https://www.google.com/maps/place/Instituto+Dac+-+IDAC/@-23.5771323,-46.6287882,17z/" aria-label="Perfil do IDAC no Google" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"><path d="M18 6.7a8 8 0 1 0 2 5.3h-8"/></svg></a>
            <a href="https://api.whatsapp.com/send/?phone=5511914688835" aria-label="WhatsApp" target="_blank" rel="noopener noreferrer" data-external="whatsapp"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M21 11.7a9 9 0 0 1-13.2 8L3 21l1.3-4.6A9 9 0 1 1 21 11.7Z"/><path d="M9 7.5c-2 0-1 3.8 1.6 6.2s5.6 2.7 5.9 1l.3-1-2.7-1.3-1 1c-1.3-.5-2.4-1.6-2.9-2.8l.9-.9L10 7.5Z" fill="currentColor" stroke="none"/></svg></a>
            <a href="https://www.facebook.com/institutodac/" aria-label="Facebook" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><path d="M14.5 21v-8h2.7l.4-3h-3.1V8.3c0-.9.3-1.5 1.6-1.5h1.6V4.1a19 19 0 0 0-2.4-.1c-2.5 0-4.1 1.5-4.1 4.2V10H8.5v3h2.7v8z"/></svg></a>
          </nav>
        </div>

        <div class="footer-map">
          <iframe
            title="Mapa com a localização do Instituto DAC"
            src="https://www.google.com/maps?q=Instituto%20DAC%20-%20IDAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20S%C3%A3o%20Paulo&amp;output=embed"
            width="600"
            height="420"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          ></iframe>
          <a
            href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
            target="_blank"
            rel="noopener noreferrer"
            data-external="maps"
          >Abrir rota no Google Maps</a>
        </div>
      </div>
      <div class="container footer-bottom">
        <p>© <span data-year>2026</span> Instituto DAC. Todos os direitos reservados.</p>
        <a href="<?php echo esc_url( two_p_idac_internal_url( '/politica-de-privacidade/' ) ); ?>">Aviso de privacidade</a>
      </div>
    </footer><?php wp_footer(); ?></body></html>