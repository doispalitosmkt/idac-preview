<?php
defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html class="two-p-growth-home-idac-document" <?php language_attributes(); ?>>
  <head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta
      name="description"
      content="Cadaverlab do Instituto DAC em São Paulo: treinamento em cadáveres Fresh Frozen, cursos presenciais e projetos sob medida para médicos, professores e instituições."
    />
    <meta name="robots" content="index,follow" />
    <meta name="theme-color" content="#101416" />
    <link rel="icon" type="image/png" sizes="64x64" href="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'favicon.png' ) ); ?>" />
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'apple-touch-icon.png' ) ); ?>" />
    <link rel="canonical" href="<?php echo esc_url( home_url( '/' ) ); ?>" />
    <link
      rel="preload"
      href="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'fonts/montserrat-latin.woff2' ) ); ?>"
      as="font"
      type="font/woff2"
      crossorigin
    />
    <link
      rel="preload"
      href="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/hero-idac.webp' ) ); ?>"
      as="image"
      type="image/webp"
      media="(min-width: 641px)"
    />
    <link
      rel="preload"
      href="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/hero-idac-mobile.webp' ) ); ?>"
      as="image"
      type="image/webp"
      media="(max-width: 640px)"
    />
    <meta property="og:type" content="website" />
    <meta property="og:locale" content="pt_BR" />
    <meta property="og:site_name" content="Instituto DAC" />
    <meta property="og:title" content="Cadaverlab | Treinamento em cadáveres Fresh Frozen | Instituto DAC" />
    <meta
      property="og:description"
      content="Educação médica prática em São Paulo, com cursos, treinamentos individualizados e projetos sob medida."
    />
    <meta property="og:url" content="<?php echo esc_url( home_url( '/' ) ); ?>" />
    <meta property="og:image" content="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/og-idac.jpg' ) ); ?>" />
    <meta property="og:image:secure_url" content="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/og-idac.jpg' ) ); ?>" />
    <meta property="og:image:type" content="image/jpeg" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta
      property="og:image:alt"
      content="Médicos em treinamento prático com microscópio cirúrgico no Instituto DAC"
    />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Cadaverlab | Treinamento em cadáveres Fresh Frozen | Instituto DAC" />
    <meta
      name="twitter:description"
      content="Educação médica prática em São Paulo, com cursos, treinamentos individualizados e projetos sob medida."
    />
    <meta name="twitter:image" content="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/og-idac.jpg' ) ); ?>" />
    <meta
      name="twitter:image:alt"
      content="Médicos em treinamento prático com microscópio cirúrgico no Instituto DAC"
    />
    <script type="application/ld+json">
      {
        "@context": "https://schema.org",
        "@type": "EducationalOrganization",
        "name": "Instituto DAC",
        "url": "https://institutodac.com/",
        "logo": "<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>",
        "telephone": "+55 11 91468-8835",
        "address": {
          "@type": "PostalAddress",
          "streetAddress": "Rua Pedra Azul, 505",
          "addressLocality": "São Paulo",
          "addressRegion": "SP",
          "postalCode": "04109-000",
          "addressCountry": "BR"
        }
      }
    </script>
  
    <?php wp_head(); ?>
  </head>
  <body <?php body_class( 'two-p-growth-home-idac' ); ?>>
    <?php wp_body_open(); ?>

    <a class="skip-link" href="#conteudo">Pular para o conteúdo</a>

    <header class="site-header" data-header>
      <div class="container header-inner">
        <a class="brand" href="#inicio" aria-label="Instituto DAC — início">
          <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>" alt="Instituto DAC" width="214" height="89" />
        </a>

        <button
          class="menu-toggle"
          type="button"
          aria-controls="site-menu"
          aria-expanded="false"
          data-menu-toggle
        >
          <span data-menu-label>Menu</span>
        </button>

        
        <nav class="site-nav" id="site-menu" aria-label="Navegação principal" data-menu>
          <?php
          wp_nav_menu(
            array(
              'theme_location' => TWO_P_GROWTH_HOME_IDAC_MENU,
              'container'      => false,
              'menu_class'     => 'menu two-p-growth-home-menu',
              'fallback_cb'    => 'two_p_growth_home_idac_menu_fallback',
            )
          );
          ?>
        </nav>

        <a
          class="button button-small header-cta"
          href="#contato"
          data-cta-location="header"
          data-cta-intent="geral"
        >Falar com o IDAC</a>
      </div>
    </header>

    <main id="conteudo">
      <section class="hero" id="inicio" aria-labelledby="hero-title">
        <picture class="hero-media">
          <source media="(max-width: 640px)" srcset="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/hero-idac-mobile.webp' ) ); ?>" />
          <source srcset="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/hero-idac.webp' ) ); ?>" type="image/webp" />
          <img
            src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/hero-idac.png' ) ); ?>"
            alt="Médicos acompanham treinamento prático com microscópio cirúrgico"
            width="1672"
            height="941"
            fetchpriority="high"
          />
        </picture>
        <div class="hero-shade" aria-hidden="true"></div>

        <div class="container hero-content">
          <p class="eyebrow eyebrow-light">CADAVERLAB - Educação médica prática em São Paulo</p>
          <h1 id="hero-title">Treinamento em cadáveres Fresh Frozen</h1>
          <p class="hero-copy">
            Cursos, treinamentos individualizados e projetos sob medida para médicos, professores,
            empresas e instituições de saúde.
          </p>
          <div class="hero-actions">
            <a
              class="button"
              href="#contato"
              data-cta-location="hero"
              data-cta-intent="cursos"
            >Consultar próximas turmas</a>
            <a class="text-link text-link-light" href="#estrutura">Conhecer a estrutura</a>
          </div>
        </div>

      </section>

      <section class="metrics" aria-label="Números do Instituto DAC">
        <div class="container metrics-grid">
          <div class="metric"><strong>+3.000</strong><span>alunos atendidos</span></div>
          <div class="metric"><strong>+200</strong><span>cursos realizados</span></div>
          <div class="metric"><strong>+150</strong><span>eventos realizados</span></div>
          <div class="metric"><strong>+300</strong><span>empresas e parceiros</span></div>
        </div>
      </section>

      <section class="section section-light" id="modalidades" aria-labelledby="modalidades-title">
        <div class="container">
          <div class="section-heading section-heading-wide" data-reveal>
            <div>
              <p class="eyebrow">Um instituto, várias possibilidades</p>
              <h2 id="modalidades-title">Não existe uma única forma de treinar.</h2>
            </div>
            <p>
              O IDAC combina conhecimento, estrutura e operação para atender diferentes objetivos de
              formação médica — de uma necessidade individual a um grande projeto institucional.
            </p>
          </div>

          <div class="format-showcase">
            <article class="format-feature" data-reveal>
              <figure class="format-media">
                <img
                  src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/modalidade-especializacao.jpg' ) ); ?>"
                  alt="Médicos acompanham uma aula presencial no Instituto DAC"
                  width="1200"
                  height="800"
                  loading="lazy"
                />
                <figcaption>Formação presencial em grupo</figcaption>
              </figure>
              <div class="format-content">
                <p class="format-kicker"><span aria-hidden="true">01</span> Formação continuada</p>
                <h3>Cursos de Especialização Médica</h3>
                <p class="format-lead">
                  Para médicos que querem atualizar conhecimentos e transformar conteúdo em domínio
                  técnico, com a prática ocupando o centro da experiência.
                </p>
                <ul class="format-points">
                  <li>Turmas presenciais conduzidas por especialistas</li>
                  <li>Conteúdo aplicado a situações reais da prática médica</li>
                  <li>Diferentes áreas e níveis de aprofundamento</li>
                </ul>
                <a
                  class="button button-dark"
                  href="#contato"
                  data-cta-location="modalidades"
                  data-cta-intent="cursos"
                >Consultar próximas turmas</a>
              </div>
            </article>

            <article class="format-feature" data-reveal>
              <figure class="format-media">
                <img
                  src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/modalidade-individual.jpg' ) ); ?>"
                  alt="Médico utiliza microscópio cirúrgico durante treinamento no Instituto DAC"
                  width="1200"
                  height="800"
                  loading="lazy"
                />
                <figcaption>Prática focada no objetivo do médico</figcaption>
              </figure>
              <div class="format-content">
                <p class="format-kicker"><span aria-hidden="true">02</span> Mentoria sob medida</p>
                <h3>Mentoria médica individualizada</h3>
                <p class="format-lead">
                  Uma jornada construída em torno da necessidade do profissional, com objetivo, técnica,
                  ritmo e formato definidos para aquele desenvolvimento.
                </p>
                <ul class="format-points">
                  <li>Escopo alinhado diretamente com o médico</li>
                  <li>Estrutura e recursos preparados para o treinamento</li>
                  <li>Acompanhamento concentrado e evolução no próprio ritmo</li>
                </ul>
                <a
                  class="button button-dark"
                  href="#contato"
                  data-cta-location="modalidades"
                  data-cta-intent="individual"
                >Planejar minha mentoria</a>
              </div>
            </article>

            <article class="format-feature" data-reveal>
              <figure class="format-media">
                <img
                  src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/modalidade-professores.jpg' ) ); ?>"
                  alt="Profissionais colaboram durante uma experiência prática no Instituto DAC"
                  width="1200"
                  height="800"
                  loading="lazy"
                />
                <figcaption>Uma estrutura para transformar conteúdo em experiência</figcaption>
              </figure>
              <div class="format-content">
                <p class="format-kicker"><span aria-hidden="true">03</span> Para quem ensina</p>
                <h3>Cursos em Parceria com Professores</h3>
                <p class="format-lead">
                  Professores e especialistas trazem sua proposta. O IDAC entra com a estrutura e o suporte
                  para dar forma a uma experiência de formação consistente.
                </p>
                <ul class="format-points">
                  <li>Liberdade para conteúdo e metodologia próprios</li>
                  <li>Ambiente preparado para receber professor e alunos</li>
                  <li>Apoio operacional do planejamento à realização</li>
                </ul>
                <a
                  class="button button-dark"
                  href="#contato"
                  data-cta-location="modalidades"
                  data-cta-intent="professores"
                >Realizar um curso em parceria</a>
              </div>
            </article>

            <article class="format-feature" data-reveal>
              <figure class="format-media">
                <img
                  src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/modalidade-corporativo-medicos.jpg' ) ); ?>"
                  alt="Equipe médica discute um projeto de capacitação em conjunto"
                  width="1200"
                  height="800"
                  loading="lazy"
                />
                <figcaption>Projetos desenhados para grupos e instituições</figcaption>
              </figure>
              <div class="format-content">
                <p class="format-kicker"><span aria-hidden="true">04</span> Para empresas e equipes</p>
                <h3>Treinamentos Corporativos para Médicos</h3>
                <p class="format-lead">
                  Capacitações desenvolvidas a partir dos objetivos da organização, conectando equipes,
                  técnicas, procedimentos, materiais e novas tecnologias.
                </p>
                <ul class="format-points">
                  <li>Projetos para hospitais, empresas e instituições</li>
                  <li>Conteúdo adequado ao desafio de cada equipe</li>
                  <li>Operação preparada para treinamentos em grupo</li>
                </ul>
                <a
                  class="button button-dark"
                  href="#contato"
                  data-cta-location="modalidades"
                  data-cta-intent="corporativo"
                >Planejar treinamento corporativo</a>
              </div>
            </article>
          </div>

          <div class="format-extra-grid">
            <article class="format-extra-card" data-reveal>
              <p class="format-kicker"><span aria-hidden="true">05</span> Pesquisa e ciência</p>
              <h3>Apoio a Pesquisas em Saúde</h3>
              <p class="format-lead">
                O IDAC apoia projetos científicos e acadêmicos que utilizam espécimes anatômicos para
                investigação, estudo e avanço do conhecimento em saúde.
              </p>
              <ul class="format-points">
                <li>Parcerias com universidades e instituições de pesquisa</li>
                <li>Projetos com espécimes e tecidos destinados à investigação científica</li>
                <li>Estrutura e suporte definidos conforme os objetivos de cada estudo</li>
              </ul>
              <a
                class="button button-dark"
                href="#contato"
                data-cta-location="modalidades"
                data-cta-intent="pesquisa"
              >Desenvolver um projeto de pesquisa</a>
            </article>

            <article class="format-extra-card" data-reveal>
              <p class="format-kicker"><span aria-hidden="true">06</span> Inovação em tecnologia para saúde</p>
              <h3>Desenvolvimento e Validação de Tecnologias Médicas</h3>
              <p class="format-lead">
                Empresas e equipes de inovação podem utilizar a estrutura do IDAC para desenvolver
                estudos, avaliações e testes relacionados a produtos, equipamentos e novas tecnologias
                para a área da saúde.
              </p>
              <ul class="format-points">
                <li>Estudos e testes com peças e tecidos anatômicos</li>
                <li>Apoio ao desenvolvimento de dispositivos, materiais e equipamentos médicos</li>
                <li>Projetos estruturados de acordo com a necessidade de cada tecnologia</li>
              </ul>
              <a
                class="button button-dark"
                href="#contato"
                data-cta-location="modalidades"
                data-cta-intent="inovacao"
              >Conversar sobre um projeto de inovação</a>
            </article>
          </div>
        </div>
      </section>

      <section class="section process" id="como-funciona" aria-labelledby="process-title">
        <div class="container process-layout">
          <div class="process-intro" data-reveal>
            <p class="eyebrow">Como funciona</p>
            <h2 id="process-title">Do objetivo ao treinamento.</h2>
            <p class="process-copy">
              Cada projeto começa com uma conversa e avança com método. O IDAC organiza formato,
              estrutura e operação até o dia da prática.
            </p>
            <figure class="process-image">
              <img
                src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/modalidade-professores.jpg' ) ); ?>"
                alt="Equipe médica colabora durante atividade prática no Instituto DAC"
                width="1200"
                height="800"
                loading="lazy"
              />
              <figcaption>Planejamento, estrutura e operação no mesmo fluxo.</figcaption>
            </figure>
          </div>
          <ol class="process-list">
            <li data-reveal>
              <span>01</span>
              <div><h3>Conte sua necessidade</h3><p>Turma, treinamento individual, parceria com professor ou projeto corporativo.</p></div>
            </li>
            <li data-reveal>
              <span>02</span>
              <div><h3>Desenhamos o formato</h3><p>Público, objetivos, técnica, estrutura e operação necessárias.</p></div>
            </li>
            <li data-reveal>
              <span>03</span>
              <div><h3>Preparamos a experiência</h3><p>Ambiente, agenda e recursos organizados conforme o projeto.</p></div>
            </li>
            <li data-reveal>
              <span>04</span>
              <div>
                <h3>Realizamos o treinamento</h3>
                <p>Prática, acompanhamento e suporte no dia da atividade.</p>
                <a
                  class="button"
                  href="#contato"
                  data-cta-location="processo"
                  data-cta-intent="geral"
                >Conversar com a equipe do IDAC</a>
              </div>
            </li>
          </ol>
        </div>
      </section>

      <section class="section specialties" id="diferenciais" aria-labelledby="specialties-title">
        <div class="container">
          <div class="section-heading section-heading-wide" data-reveal>
            <div>
              <p class="eyebrow eyebrow-light">Amplitude médica</p>
              <h2 id="specialties-title">Conhecimento que atravessa especialidades.</h2>
            </div>
            <p>
              De técnicas fundamentais a treinamentos cirúrgicos avançados, a estrutura recebe diferentes
              áreas e níveis de aprofundamento.
            </p>
          </div>
          <ul class="specialty-gallery" aria-label="Cursos e próximas turmas">
            <li data-reveal>
              <article class="specialty-card">
                <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-suturas.jpg' ) ); ?>" alt="" width="800" height="1000" loading="lazy" />
                <div class="specialty-card-content">
                  <h3>Suturas</h3>
                  <p>Fundamentos e prática de sutura.</p>
                  <a class="specialty-card-details" href="<?php echo esc_url( home_url( '/curso-presencial-de-suturas-e-disseccao/' ) ); ?>">Conhecer o curso</a>
                  <button class="specialty-card-link" type="button" data-waitlist-trigger data-waitlist-course="suturas" data-waitlist-origin="proxima-turma-suturas">Quero participar da próxima turma</button>
                </div>
              </article>
            </li>
            <li data-reveal>
              <article class="specialty-card">
                <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-medicina-regenerativa.jpg' ) ); ?>" alt="" width="800" height="1000" loading="lazy" />
                <div class="specialty-card-content">
                  <h3>Medicina Regenerativa</h3>
                  <p>Bases científicas e atualização profissional.</p>
                  <a class="specialty-card-details" href="<?php echo esc_url( home_url( '/conhecendo-a-medicina-regenerativa/' ) ); ?>">Conhecer o curso</a>
                  <button class="specialty-card-link" type="button" data-waitlist-trigger data-waitlist-course="medicina-regenerativa" data-waitlist-origin="proxima-turma-medicina-regenerativa">Quero participar da próxima turma</button>
                </div>
              </article>
            </li>
            <li data-reveal>
              <article class="specialty-card">
                <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-ortopedia.jpg' ) ); ?>" alt="" width="800" height="1000" loading="lazy" />
                <div class="specialty-card-content">
                  <h3>Anatomia Topográfica</h3>
                  <p>Imersão em planos e regiões anatômicas, com prática em cadáveres frescos.</p>
                  <button class="specialty-card-link" type="button" data-waitlist-trigger data-waitlist-course="anatomia-topografica" data-waitlist-origin="proxima-turma-anatomia-topografica">Quero participar da próxima turma</button>
                </div>
              </article>
            </li>
            <li data-reveal>
              <article class="specialty-card">
                <figure class="specialty-card-photo">
                  <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-via-aerea.webp' ) ); ?>" alt="Manequim e equipamento para simulação de via aérea" width="1200" height="600" loading="lazy" />
                  <figcaption>Imagem ilustrativa</figcaption>
                </figure>
                <div class="specialty-card-content">
                  <h3>Via Aérea</h3>
                  <button class="specialty-card-link" type="button" data-waitlist-trigger data-waitlist-course="via-aerea" data-waitlist-origin="proxima-turma-via-aerea">Quero participar da próxima turma</button>
                </div>
              </article>
            </li>
            <li data-reveal>
              <article class="specialty-card">
                <figure class="specialty-card-photo">
                  <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-radiofrequencia-nervo-periferico.webp' ) ); ?>" alt="Equipamentos e modelo de simulação em uma bancada de treinamento" width="1200" height="600" loading="lazy" />
                  <figcaption>Imagem ilustrativa</figcaption>
                </figure>
                <div class="specialty-card-content">
                  <h3>Radiofrequência de Nervo Periférico</h3>
                  <button class="specialty-card-link" type="button" data-waitlist-trigger data-waitlist-course="radiofrequencia-nervo-periferico" data-waitlist-origin="proxima-turma-radiofrequencia-nervo-periferico">Quero participar da próxima turma</button>
                </div>
              </article>
            </li>
            <li data-reveal>
              <article class="specialty-card">
                <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-implantes-auditivos.jpg' ) ); ?>" alt="" width="800" height="1000" loading="lazy" />
                <div class="specialty-card-content">
                  <h3>Curso de Implantes Auditivos</h3>
                  <p>Anatomia do osso temporal e planejamento cirúrgico.</p>
                  <a class="specialty-card-details" href="<?php echo esc_url( home_url( '/xi-curso-de-implantes-auditivos-med-el-do-brasil/' ) ); ?>">Conhecer o curso</a>
                  <button class="specialty-card-link" type="button" data-waitlist-trigger data-waitlist-course="implantes-auditivos" data-waitlist-origin="proxima-turma-implantes-auditivos">Quero participar da próxima turma</button>
                </div>
              </article>
            </li>
          </ul>
          <a class="text-link text-link-light catalog-history-link" href="<?php echo esc_url( home_url( '/quem-somos/#formacoes' ) ); ?>">Conhecer formações anteriores</a>
        </div>
      </section>

      <dialog class="waitlist-dialog" data-waitlist-dialog aria-labelledby="waitlist-title">
        <div class="waitlist-dialog-panel">
          <button class="waitlist-dialog-close" type="button" data-waitlist-close aria-label="Fechar formulário">×</button>
          <p class="eyebrow">Próximas turmas</p>
          <h2 id="waitlist-title">Avise-me quando uma nova turma abrir.</h2>
          <p class="waitlist-dialog-intro">
            Escolha um ou mais cursos para receber o contato da equipe quando houver uma nova oportunidade.
          </p>
          <form class="waitlist-form" data-waitlist-form>
            <div class="waitlist-form-row">
              <label>
                Nome completo
                <input type="text" name="name" autocomplete="name" required />
              </label>
              <label>
                WhatsApp
                <input type="tel" name="personal_phone" autocomplete="tel" placeholder="(11) 90000-0000" required />
              </label>
            </div>
            <label>
              E-mail
              <input type="email" name="email" autocomplete="email" required />
            </label>
            <fieldset class="waitlist-courses">
              <legend>Quais cursos você quer acompanhar?</legend>
              <div class="waitlist-course-grid">
                <label><input type="checkbox" name="courses" value="suturas" /> <span>Suturas</span></label>
                <label><input type="checkbox" name="courses" value="medicina-regenerativa" /> <span>Medicina Regenerativa</span></label>
                <label><input type="checkbox" name="courses" value="anatomia-topografica" /> <span>Anatomia Topográfica</span></label>
                <label><input type="checkbox" name="courses" value="via-aerea" /> <span>Via Aérea</span></label>
                <label><input type="checkbox" name="courses" value="radiofrequencia-nervo-periferico" /> <span>Radiofrequência de Nervo Periférico</span></label>
                <label><input type="checkbox" name="courses" value="implantes-auditivos" /> <span>Curso de Implantes Auditivos</span></label>
              </div>
            </fieldset>
            <label class="waitlist-consent">
              <input type="checkbox" name="privacy_consent" value="true" required />
              <span>Li e concordo com o tratamento dos meus dados conforme o <a href="<?php echo esc_url( two_p_growth_home_idac_privacy_url() ); ?>">Aviso de privacidade</a>.</span>
            </label>
            <input type="hidden" name="cta_origin" value="proxima-turma" data-waitlist-origin-field />
            <div class="waitlist-honeypot" aria-hidden="true">
              <label>Não preencha este campo<input type="text" name="website" tabindex="-1" autocomplete="off" /></label>
            </div>
            <button class="button" type="submit" data-waitlist-submit>Quero ser avisado</button>
            <p class="waitlist-form-status" data-waitlist-status role="status" aria-live="polite"></p>
          </form>
        </div>
      </dialog>

      <section class="section structure" id="estrutura" aria-labelledby="estrutura-title">
        <div class="container">
          <div class="section-heading" data-reveal>
            <p class="eyebrow">Estrutura integrada</p>
            <h2 id="estrutura-title">Espaço para workshops e eventos.</h2>
            <p>
              Locação na Aclimação, em São Paulo, para workshops, encontros de equipes e confraternizações.
              O espaço recebe até 60 pessoas.
            </p>
          </div>

          <div class="structure-editorial">
            <div
              class="structure-carousel"
              role="region"
              aria-label="Galeria da estrutura e dos treinamentos do Instituto DAC"
              data-structure-carousel
              data-reveal
            >
              <div class="structure-carousel-track">
                <figure class="structure-slide is-active" data-carousel-slide aria-hidden="false">
                  <img
                    src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/fachada-idac.jpg' ) ); ?>"
                    alt="Fachada do Instituto DAC na Aclimação"
                    width="900"
                    height="668"
                    loading="lazy"
                  />
                  <figcaption>Instituto DAC, na Aclimação</figcaption>
                </figure>
                <figure class="structure-slide" data-carousel-slide aria-hidden="true">
                  <img
                    src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/especialidade-suturas.jpg' ) ); ?>"
                    alt="Profissional prepara instrumentos para uma atividade prática no Instituto DAC"
                    width="800"
                    height="1000"
                    loading="lazy"
                  />
                  <figcaption>Ambiente preparado para prática e aperfeiçoamento técnico</figcaption>
                </figure>
                <figure class="structure-slide" data-carousel-slide aria-hidden="true">
                  <img
                    src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/modalidade-professores.jpg' ) ); ?>"
                    alt="Profissionais colaboram durante uma atividade prática no Instituto DAC"
                    width="1200"
                    height="800"
                    loading="lazy"
                  />
                  <figcaption>Estrutura para professores e especialistas</figcaption>
                </figure>
                <figure class="structure-slide" data-carousel-slide aria-hidden="true">
                  <img
                    src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/modalidade-individual.jpg' ) ); ?>"
                    alt="Médico utiliza microscópio durante treinamento individualizado"
                    width="1200"
                    height="800"
                    loading="lazy"
                  />
                  <figcaption>Recursos para treinamentos individualizados</figcaption>
                </figure>
                <figure class="structure-slide" data-carousel-slide aria-hidden="true">
                  <img
                    src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/idac-medica.webp' ) ); ?>"
                    alt="Médica concentrada durante atividade prática no Instituto DAC"
                    width="900"
                    height="668"
                    loading="lazy"
                  />
                  <figcaption>Prática, concentração e suporte técnico</figcaption>
                </figure>
              </div>

              <div class="structure-carousel-controls">
                <button type="button" class="structure-carousel-arrow" data-carousel-prev aria-label="Imagem anterior">←</button>
                <div class="structure-carousel-dots" role="group" aria-label="Selecionar imagem">
                  <button type="button" class="is-active" data-carousel-dot="0" aria-label="Ver imagem 1" aria-current="true"></button>
                  <button type="button" data-carousel-dot="1" aria-label="Ver imagem 2"></button>
                  <button type="button" data-carousel-dot="2" aria-label="Ver imagem 3"></button>
                  <button type="button" data-carousel-dot="3" aria-label="Ver imagem 4"></button>
                  <button type="button" data-carousel-dot="4" aria-label="Ver imagem 5"></button>
                </div>
                <button type="button" class="structure-carousel-arrow" data-carousel-next aria-label="Próxima imagem">→</button>
              </div>
              <span class="sr-only" data-carousel-status aria-live="polite"></span>
            </div>

            <div class="structure-panel" data-reveal>
              <div class="structure-panel-copy">
                <h3>Planeje seu evento no IDAC.</h3>
              </div>

              <dl class="structure-fact-list">
                <div><dt>Workshops</dt><dd>Auditório, TVs, possibilidade de transmissão e sala de reunião.</dd></div>
                <div><dt>Confraternizações</dt><dd>Espaço de festas com forno de pizza, churrasqueira e freezer.</dd></div>
                <div><dt>Disponibilidade</dt><dd>Mais opções de datas durante a semana. Consulte a locação nos fins de semana.</dd></div>
              </dl>
              <a class="button button-small structure-booking" href="#contato" data-cta-location="estrutura-locacao" data-cta-intent="locacao-eventos">Consultar datas para eventos</a>

              <figure class="structure-panel-image">
                <img
                  src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/idac-microscopio-real.webp' ) ); ?>"
                  alt="Médico utiliza microscópio durante treinamento prático no Instituto DAC"
                  width="1319"
                  height="1080"
                  loading="lazy"
                />
                <figcaption>Recursos para prática de alta precisão</figcaption>
              </figure>
            </div>
          </div>

          <div class="structure-facilities" data-reveal>
            <p>Ambientes e recursos para o seu evento</p>
            <ul class="facility-index" aria-label="Ambientes e recursos do Instituto DAC">
              <li><span>01</span><strong>Laboratório</strong></li>
              <li><span>02</span><strong>Auditório</strong></li>
              <li><span>03</span><strong>Recepção e lounge</strong></li>
              <li><span>04</span><strong>Sala de reunião</strong></li>
              <li><span>05</span><strong>Escritório privativo</strong></li>
              <li><span>06</span><strong>Vestiários</strong></li>
              <li><span>07</span><strong>Espaço de festas e área gourmet</strong></li>
            </ul>
          </div>
        </div>
      </section>

      <section class="section video-section" aria-labelledby="video-title">
        <div class="container video-grid">
          <div class="video-copy" data-reveal>
            <p class="eyebrow eyebrow-light">Por dentro do IDAC</p>
            <h2 id="video-title">Conheça a estrutura em movimento.</h2>
            <p>
              Veja como os ambientes se conectam e apoiam diferentes formatos de formação, demonstração e
              treinamento médico.
            </p>
            <button
              class="button video-trigger"
              type="button"
              data-video-trigger="institucional"
              aria-pressed="false"
            >
              <i class="ph-fill ph-play" aria-hidden="true"></i>
              Assistir ao vídeo institucional
            </button>
          </div>
          <div class="video-stage" data-reveal>
            <div class="video-frame" data-video-frame="institucional">
              <img
                class="video-poster"
                src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/poster-video-institucional-idac.webp' ) ); ?>"
                alt="Profissional médica prepara instrumentos em um ambiente de treinamento"
                width="720"
                height="1280"
                loading="lazy"
              />
              <span class="video-kicker">Vídeo institucional</span>
              <button
                class="video-play"
                type="button"
                data-video-trigger="institucional"
                aria-label="Assistir ao vídeo institucional"
                aria-pressed="false"
              >
                <span class="video-play-icon" aria-hidden="true">
                  <i class="ph-fill ph-play"></i>
                </span>
                <span class="video-play-label">Assistir · 2 min</span>
              </button>
              <span class="video-format">
                <i class="ph ph-speaker-high" aria-hidden="true"></i>
                Formato vertical · som disponível
              </span>
              <video class="lazy-video" controls playsinline preload="none" aria-label="Vídeo institucional do Instituto DAC">
                <source data-src="<?php echo esc_url( two_p_growth_home_idac_video_url( 'institucional-idac.mp4' ) ); ?>" type="video/mp4" />
                Seu navegador não suporta vídeo HTML5.
              </video>
            </div>
          </div>
        </div>
      </section>

      <?php two_p_growth_home_idac_render_podcast(); ?>
      <section class="section partners" aria-labelledby="partners-title">
        <div class="container partners-grid">
          <div data-reveal>
            <p class="eyebrow">Conexões</p>
            <h2 id="partners-title">Projetos que aproximam conhecimento e inovação.</h2>
            <p>
              O IDAC recebe professores, empresas, hospitais, laboratórios, sociedades médicas e
              instituições de ensino.
            </p>
          </div>
          <div class="partner-logos" aria-label="Marcas presentes em materiais do Instituto DAC" data-reveal>
            <figure>
              <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-politec.png' ) ); ?>" alt="Politec Saúde" width="260" height="103" loading="lazy" />
            </figure>
            <figure>
              <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-cema-otologia.jpg' ) ); ?>" alt="Departamento de Otologia e Grupo de Implante Coclear do Hospital CEMA" width="521" height="122" loading="lazy" />
            </figure>
          </div>
        </div>
      </section>

      <section class="section testimonials" id="depoimentos" aria-labelledby="testimonials-title">
        <div class="container">
          <div class="section-heading section-heading-wide" data-reveal>
            <div>
              <p class="eyebrow eyebrow-light">Experiência reconhecida</p>
              <h2 id="testimonials-title">Quem vive a prática percebe a diferença.</h2>
            </div>
          </div>

          <div class="review-grid">
            <article class="review-card" data-reveal>
              <p>Cursos cirúrgicos com uma equipe atenta, disponível e preparada para apoiar os participantes.</p>
              <footer><strong>Samuel Zymberg</strong><span>Avaliação no Google</span></footer>
            </article>
            <article class="review-card" data-reveal>
              <p>Estrutura pensada para o estudo e o aperfeiçoamento de cirurgiões de diferentes regiões.</p>
              <footer><strong>Flávio Cabral</strong><span>Avaliação no Google</span></footer>
            </article>
            <article class="review-card" data-reveal>
              <p>Estrutura, professores, acolhimento e uma oportunidade prática que fortalece o aprendizado.</p>
              <footer><strong>Marina Souza</strong><span>Avaliação no Google</span></footer>
            </article>
          </div>

          <div class="testimonials-heading" data-reveal>
            <h3>Depoimentos em vídeo</h3>
            <p>Relatos de profissionais que participaram de experiências presenciais no Instituto DAC. Os vídeos são carregados apenas quando você escolhe assistir.</p>
          </div>

          <div class="video-cards">
            <article class="video-card" data-reveal>
              <div class="portrait-video" data-video-frame="depoimento-1">
                <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/depoimento-mariana.webp' ) ); ?>" alt="Mariana Machado durante depoimento no Instituto DAC" width="780" height="1242" loading="lazy" />
                <video class="lazy-video" controls playsinline preload="none" aria-label="Depoimento em vídeo de participante do Instituto DAC">
                  <source data-src="<?php echo esc_url( two_p_growth_home_idac_video_url( 'depoimento-1.mp4' ) ); ?>" type="video/mp4" />
                </video>
                <button type="button" class="watch-button" data-video-trigger="depoimento-1">Assistir depoimento</button>
              </div>
              <h3>Mariana Machado</h3>
              <p>Relato de participante em uma atividade presencial.</p>
            </article>

            <article class="video-card" data-reveal>
              <div class="portrait-video" data-video-frame="depoimento-2">
                <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/depoimento-jucilaine.webp' ) ); ?>" alt="Jucilaine durante depoimento no Instituto DAC" width="780" height="1242" loading="lazy" />
                <video class="lazy-video" controls playsinline preload="none" aria-label="Depoimento em vídeo de participante do Instituto DAC">
                  <source data-src="<?php echo esc_url( two_p_growth_home_idac_video_url( 'depoimento-2.mp4' ) ); ?>" type="video/mp4" />
                </video>
                <button type="button" class="watch-button" data-video-trigger="depoimento-2">Assistir depoimento</button>
              </div>
              <h3>Jucilaine</h3>
              <p>Impressões de quem participou da rotina de treinamento.</p>
            </article>

            <article class="video-card" data-reveal>
              <div class="portrait-video" data-video-frame="depoimento-3">
                <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/depoimento-rafael.webp' ) ); ?>" alt="Rafael Ribeiro durante depoimento no Instituto DAC" width="782" height="1240" loading="lazy" />
                <video class="lazy-video" controls playsinline preload="none" aria-label="Depoimento em vídeo de participante do Instituto DAC">
                  <source data-src="<?php echo esc_url( two_p_growth_home_idac_video_url( 'depoimento-3.mp4' ) ); ?>" type="video/mp4" />
                </video>
                <button type="button" class="watch-button" data-video-trigger="depoimento-3">Assistir depoimento</button>
              </div>
              <h3>Rafael Ribeiro</h3>
              <p>A visão de quem levou a técnica para a prática.</p>
            </article>
          </div>

          <div class="reviews-action" data-reveal>
            <a
              class="text-link text-link-light"
              href="https://www.google.com/maps/place/Instituto+Dac+-+IDAC/@-23.5771323,-46.6287882,17z/"
              target="_blank"
              rel="noopener noreferrer"
              data-external="google-reviews"
            >Ver avaliações no Google</a>
          </div>
        </div>
      </section>

      <section class="section faq" id="faq" aria-labelledby="faq-title">
        <div class="container faq-grid">
          <div class="faq-intro" data-reveal>
            <p class="eyebrow">Perguntas frequentes</p>
            <h2 id="faq-title">Informação clara antes da prática.</h2>
            <p>
              Não encontrou sua dúvida? Envie seu contato e a equipe orienta o melhor caminho para seu
              objetivo.
            </p>
            <a
              class="text-link"
              href="#contato"
              data-cta-location="faq"
              data-cta-intent="duvida"
            >Tirar uma dúvida</a>
          </div>

          <div class="accordion" data-reveal>
            <details>
              <summary>O Instituto DAC oferece apenas cursos próprios?</summary>
              <p>Não. Além de cursos presenciais, o IDAC oferece treinamento médico individualizado, recebe cursos de professores parceiros e desenvolve treinamentos corporativos.</p>
            </details>
            <details>
              <summary>Como consultar os próximos cursos?</summary>
              <p>A programação muda conforme especialidades, professores e projetos. Preencha o formulário indicando seu interesse para receber as próximas oportunidades compatíveis.</p>
            </details>
            <details>
              <summary>Posso solicitar uma mentoria individualizada?</summary>
              <p>Sim. O objetivo, a técnica e a dinâmica são planejados conforme a necessidade do médico e a viabilidade do projeto.</p>
            </details>
            <details>
              <summary>Sou professor. Posso realizar meu curso no IDAC?</summary>
              <p>Sim. Professores e especialistas podem propor conteúdo e metodologia. O IDAC avalia a estrutura e o suporte necessários para organizar a experiência.</p>
            </details>
            <details>
              <summary>O IDAC realiza treinamentos para empresas e hospitais?</summary>
              <p>Sim. Os projetos podem atender grupos de médicos e ser desenhados para capacitação técnica, novos procedimentos, materiais ou tecnologias.</p>
            </details>
            <details>
              <summary>O que significa Fresh Frozen?</summary>
              <p>É uma forma de preservação utilizada em determinados treinamentos anatômicos para proporcionar uma experiência prática próxima das características reais dos tecidos.</p>
            </details>
            <details>
              <summary>Como são obtidas as peças anatômicas usadas nos treinamentos?</summary>
              <p>O IDAC informa trabalhar com peças de origem legal, documentação e rastreabilidade para finalidade educacional. Detalhes são apresentados conforme o treinamento e a documentação aplicável. <a href="https://g1.globo.com/educacao/noticia/2024/09/30/uso-de-cadaveres-congelados-e-importados-dos-eua-para-cursos-de-harmonizacao-e-real-veja-o-que-se-sabe.ghtml" target="_blank" rel="noopener noreferrer">Entenda o contexto em reportagem do G1</a>.</p>
            </details>
            <details>
              <summary>O treinamento é voltado apenas para estética?</summary>
              <p>Não. O IDAC recebe diferentes especialidades médicas e projetos multidisciplinares, de técnicas fundamentais a treinamentos cirúrgicos avançados.</p>
            </details>
            <details>
              <summary>Onde fica o Instituto DAC?</summary>
              <p>Na Rua Pedra Azul, 505, Aclimação, São Paulo — SP, CEP 04109-000.</p>
            </details>
          </div>
        </div>
      </section>

      <section class="section location" id="localizacao" aria-labelledby="location-title">
        <div class="container location-grid">
          <figure class="location-image" data-reveal>
            <img
              src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/fachada-idac.jpg' ) ); ?>"
              alt="Fachada envidraçada do Instituto DAC na Rua Pedra Azul, 505"
              width="1400"
              height="865"
              loading="lazy"
            />
          </figure>
          <div class="location-copy" data-reveal>
            <p class="eyebrow">Aclimação, São Paulo</p>
            <h2 id="location-title">Estrutura completa em um endereço central.</h2>
            <address>
              Rua Pedra Azul, 505<br />
              Aclimação — São Paulo, SP<br />
              CEP 04109-000
            </address>
            <div class="location-actions">
              <a
                class="button button-dark"
                href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
                target="_blank"
                rel="noopener noreferrer"
                data-external="maps"
              >Traçar rota no Google Maps</a>
              <a
                class="text-link"
                href="#contato"
                data-cta-location="localizacao"
                data-cta-intent="estrutura"
              >Falar sobre a estrutura</a>
            </div>
          </div>
        </div>
        <div class="container visit-guide" data-reveal>
          <div class="visit-guide-head">
            <div>
              <p class="eyebrow">Planeje sua visita</p>
              <h3>Vem de outra cidade? Encontre o que precisa por perto.</h3>
            </div>
            <p>Explore opções de transporte, hospedagem e serviços na região da Aclimação. Consulte rotas e horários antes de sair.</p>
          </div>
          <div class="visit-guide-grid">
            <a class="visit-guide-item" href="https://www.google.com/maps/search/?api=1&amp;query=Esta%C3%A7%C3%A3o%20Ana%20Rosa%20e%20Esta%C3%A7%C3%A3o%20Para%C3%ADso%20S%C3%A3o%20Paulo" target="_blank" rel="noopener noreferrer">
              <span class="visit-guide-icon" aria-hidden="true">01</span>
              <strong>Metrô e transporte</strong>
              <span>Estações Ana Rosa e Paraíso, com integração às linhas Azul e Verde.</span>
              <span class="visit-guide-action">Ver no mapa ↗</span>
            </a>
            <a class="visit-guide-item" href="https://www.google.com/maps/search/?api=1&amp;query=hot%C3%A9is%20perto%20da%20Rua%20Pedra%20Azul%20505%20Aclima%C3%A7%C3%A3o%20S%C3%A3o%20Paulo" target="_blank" rel="noopener noreferrer">
              <span class="visit-guide-icon" aria-hidden="true">02</span>
              <strong>Hotéis</strong>
              <span>Opções na região, como EZ Aclimação e ibis budget Paraíso.</span>
              <span class="visit-guide-action">Buscar hospedagem ↗</span>
            </a>
            <a class="visit-guide-item" href="https://www.google.com/maps/search/?api=1&amp;query=restaurantes%20perto%20da%20Rua%20Pedra%20Azul%20505%20Aclima%C3%A7%C3%A3o%20S%C3%A3o%20Paulo" target="_blank" rel="noopener noreferrer">
              <span class="visit-guide-icon" aria-hidden="true">03</span>
              <strong>Restaurantes e cafés</strong>
              <span>Encontre lugares para almoço, café e jantar nos arredores.</span>
              <span class="visit-guide-action">Explorar opções ↗</span>
            </a>
            <a class="visit-guide-item" href="https://www.google.com/maps/search/?api=1&amp;query=mercados%20perto%20da%20Rua%20Pedra%20Azul%20505%20Aclima%C3%A7%C3%A3o%20S%C3%A3o%20Paulo" target="_blank" rel="noopener noreferrer">
              <span class="visit-guide-icon" aria-hidden="true">04</span>
              <strong>Mercados e conveniência</strong>
              <span>Serviços práticos para quem passa o dia na região.</span>
              <span class="visit-guide-action">Ver no mapa ↗</span>
            </a>
            <a class="visit-guide-item" href="https://www.google.com/maps/search/?api=1&amp;query=Parque%20da%20Aclima%C3%A7%C3%A3o%20Rua%20Pedra%20Azul%20S%C3%A3o%20Paulo" target="_blank" rel="noopener noreferrer">
              <span class="visit-guide-icon" aria-hidden="true">05</span>
              <strong>Parque da Aclimação</strong>
              <span>Uma opção de passeio com acesso pela Rua Pedra Azul.</span>
              <span class="visit-guide-action">Ver no mapa ↗</span>
            </a>
            <a class="visit-guide-item" href="https://www.google.com/maps/search/?api=1&amp;query=Shopping%20P%C3%A1tio%20Paulista%20S%C3%A3o%20Paulo" target="_blank" rel="noopener noreferrer">
              <span class="visit-guide-icon" aria-hidden="true">06</span>
              <strong>Shopping</strong>
              <span>O Pátio Paulista reúne lojas, alimentação e serviços.</span>
              <span class="visit-guide-action">Ver no mapa ↗</span>
            </a>
          </div>
        </div>
      </section>

      <section class="final-cta" id="contato" aria-labelledby="final-cta-title">
        <div class="container final-cta-inner" data-reveal>
          <p class="eyebrow eyebrow-light">Comece uma conversa</p>
          <h2 id="final-cta-title">Qual experiência médica você quer construir?</h2>
          <p>
            Conte seu objetivo à equipe do IDAC e descubra o formato mais adequado para sua turma,
            treinamento ou projeto.
          </p>
          <form class="final-cta-form" data-lead-form data-integration="rd-station-crm">
            <p class="final-cta-form-context" data-lead-form-context aria-live="polite">
              Selecione seu interesse para que o contato seja encaminhado corretamente.
            </p>
            <div class="final-cta-form-row">
              <label>
                Nome completo
                <input type="text" name="name" autocomplete="name" required />
              </label>
              <label>
                WhatsApp
                <input type="tel" name="personal_phone" autocomplete="tel" placeholder="(11) 90000-0000" required />
              </label>
            </div>
            <label>
              E-mail
              <input type="email" name="email" autocomplete="email" required />
            </label>
            <label>
              Qual é o seu interesse?
              <select name="cf_interesse_idac" data-lead-interest required>
                <option value="">Selecione uma opção</option>
                <optgroup label="Cursos e próximas turmas">
                  <option value="cursos" data-lead-type="curso">Cursos presenciais e próximas turmas</option>
                </optgroup>
                <optgroup label="Treinamentos e projetos">
                  <option value="individual" data-lead-type="projeto">Mentoria médica individualizada</option>
                  <option value="professores" data-lead-type="projeto">Curso em Parceria com Professores</option>
                  <option value="corporativo" data-lead-type="projeto">Treinamento Corporativo para Médicos</option>
                  <option value="locacao-eventos" data-lead-type="projeto">Locação para workshops e eventos</option>
                  <option value="pesquisa" data-lead-type="projeto">Projeto de Pesquisa em Saúde</option>
                  <option value="inovacao" data-lead-type="projeto">Desenvolvimento e Validação de Tecnologia Médica</option>
                </optgroup>
                <optgroup label="Outros assuntos">
                  <option value="estrutura" data-lead-type="geral">Estrutura e localização</option>
                  <option value="duvida" data-lead-type="geral">Dúvidas e outras informações</option>
                  <option value="geral" data-lead-type="geral">Ainda não sei qual formato escolher</option>
                </optgroup>
              </select>
            </label>
            <label>
              Conte seu objetivo <span class="form-optional">(opcional)</span>
              <textarea
                name="message"
                rows="3"
                placeholder="Turma presencial, treinamento individual, parceria ou projeto corporativo"
              ></textarea>
            </label>
            <label class="final-cta-consent">
              <input type="checkbox" name="privacy_consent" value="true" required />
              <span>Li e concordo com o tratamento dos meus dados conforme o <a href="<?php echo esc_url( two_p_growth_home_idac_privacy_url() ); ?>">Aviso de privacidade</a>.</span>
            </label>
            <input type="hidden" name="cf_tipo_de_lead" value="" data-lead-type-field />
            <input type="hidden" name="cf_origem_cta" value="formulario-direto" data-lead-origin-field />
            <input type="hidden" name="submission_identifier" value="site-idac-contato" data-lead-submission-field />
            <input type="hidden" name="page_path" value="" data-page-path-field />
            <input type="hidden" name="utm_source" value="" data-attribution-field="utm_source" />
            <input type="hidden" name="utm_medium" value="" data-attribution-field="utm_medium" />
            <input type="hidden" name="utm_campaign" value="" data-attribution-field="utm_campaign" />
            <input type="hidden" name="utm_content" value="" data-attribution-field="utm_content" />
            <input type="hidden" name="utm_term" value="" data-attribution-field="utm_term" />
            <input type="hidden" name="legal_basis" value="consentimento" />
            <div class="final-cta-honeypot" aria-hidden="true">
              <label>Não preencha este campo<input type="text" name="website" tabindex="-1" autocomplete="off" /></label>
            </div>
            <button type="submit" class="button" data-lead-submit>Enviar interesse</button>
            <p class="final-cta-form-status" data-lead-form-status role="status" aria-live="polite"></p>
          </form>
        </div>
      </section>
    </main>

    <footer class="site-footer" id="rodape">
      <div class="container footer-grid">
        <div class="footer-brand">
          <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>" alt="Instituto DAC" width="214" height="89" loading="lazy" />
          <p>
            Educação médica prática, estrutura e operação para médicos, professores, empresas e
            instituições de saúde.
          </p>
          <a
            class="footer-contact"
            href="#contato"
            data-cta-location="rodape"
            data-cta-intent="geral"
          >Falar com o IDAC</a>
        </div>

        <nav class="footer-nav" aria-label="Navegação do rodapé">
          <h2>Explore</h2>
          <a href="<?php echo esc_url( home_url( '/quem-somos/' ) ); ?>">Quem somos</a>
          <a href="<?php echo esc_url( home_url( '/contato/' ) ); ?>">Contato</a>
          <a href="#modalidades">Modalidades</a>
          <a href="#estrutura">Estrutura</a>
          <a href="#diferenciais">Cursos</a>
          <a href="<?php echo esc_url( home_url( '/quem-somos/#formacoes' ) ); ?>">Histórico de cursos</a>
          <a href="#depoimentos">Depoimentos</a>
          <a href="#faq">Perguntas frequentes</a>
          <a href="#localizacao">Localização</a>
        </nav>

        <div class="footer-visit">
          <h2>Visite o IDAC</h2>
          <address>Rua Pedra Azul, 505<br />Aclimação — São Paulo, SP<br />CEP 04109-000</address>
          <a
            class="footer-route"
            href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
            target="_blank"
            rel="noopener noreferrer"
            data-external="maps"
          >Traçar rota até o instituto</a>

          <h2 class="footer-contact-title">Contato</h2>
          <a
            href="#contato"
            data-cta-location="rodape"
            data-cta-intent="geral"
          >(11) 91468-8835</a>
          <a href="mailto:comercial@institutodac.com">comercial@institutodac.com</a>
          <nav class="footer-social" aria-label="Instituto DAC nas redes sociais">
            <?php two_p_growth_home_idac_render_youtube_icon(); ?>
            <a href="https://www.instagram.com/instituto_dac/" aria-label="Instagram" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
            <a href="https://www.linkedin.com/company/instituto-dac/" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><circle cx="5.5" cy="6" r="1.8"/><path d="M4 9h3v11H4zm6 0h3v1.5c.6-1 1.6-1.8 3.4-1.8 2.7 0 3.6 1.7 3.6 4.4V20h-3v-6c0-1.6-.5-2.4-1.8-2.4S13 12.5 13 14v6h-3z"/></svg></a>
            <a href="https://www.google.com/maps/place/Instituto+Dac+-+IDAC/@-23.5771323,-46.6287882,17z/" aria-label="Perfil do IDAC no Google" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"><path d="M18 6.7a8 8 0 1 0 2 5.3h-8"/></svg></a>
            <a href="https://api.whatsapp.com/send/?phone=5511914688835" aria-label="WhatsApp" target="_blank" rel="noopener noreferrer" data-external="whatsapp"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M21 11.7a9 9 0 0 1-13.2 8L3 21l1.3-4.6A9 9 0 1 1 21 11.7Z"/><path d="M9 7.5c-2 0-1 3.8 1.6 6.2s5.6 2.7 5.9 1l.3-1-2.7-1.3-1 1c-1.3-.5-2.4-1.6-2.9-2.8l.9-.9L10 7.5Z" fill="currentColor" stroke="none"/></svg></a>
            <a href="https://www.facebook.com/institutodac/" aria-label="Facebook" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><path d="M14.5 21v-8h2.7l.4-3h-3.1V8.3c0-.9.3-1.5 1.6-1.5h1.6V4.1a19 19 0 0 0-2.4-.1c-2.5 0-4.1 1.5-4.1 4.2V10H8.5v3h2.7v8z"/></svg></a>
          </nav>
        </div>

        <div class="footer-map">
          <iframe
            title="Mapa com a localização do Instituto DAC"
            src="https://www.google.com/maps?q=Instituto%20DAC%20-%20IDAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20S%C3%A3o%20Paulo&amp;output=embed"
            width="600"
            height="420"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          ></iframe>
          <a
            href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
            target="_blank"
            rel="noopener noreferrer"
            data-external="maps"
          >Abrir rota no Google Maps</a>
        </div>
      </div>
      <div class="container footer-bottom">
        <p>© <span data-year>2026</span> Instituto DAC. Todos os direitos reservados.</p>
        <a href="<?php echo esc_url( two_p_growth_home_idac_privacy_url() ); ?>">Aviso de privacidade</a>
      </div>
    </footer>
    <?php wp_footer(); ?>
  </body>
</html>
