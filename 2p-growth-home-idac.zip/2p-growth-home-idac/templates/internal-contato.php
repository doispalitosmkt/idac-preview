<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html><html class="two-p-growth-home-idac-document" <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>" /><meta name="viewport" content="width=device-width,initial-scale=1" /><meta name="theme-color" content="#101416" />
<link rel="icon" href="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'favicon.png' ) ); ?>" />
<?php two_p_idac_head(); wp_head(); ?></head>
<body <?php body_class( 'two-p-growth-home-idac idac-internal' ); ?> data-internal-page="contato">
<?php wp_body_open(); if ( two_p_idac_preview_key() ) { echo '<aside class="in-admin-preview">Prévia autenticada — nenhum formulário envia dados nesta visualização.</aside>'; } ?><a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
  <header class="site-header" data-header><div class="container header-inner">
    <a class="brand" href="<?php echo esc_url( two_p_idac_internal_url( '/' ) ); ?>" aria-label="Instituto DAC — início"><img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>" alt="Instituto DAC" width="214" height="89" /></a>
    <button class="menu-toggle" type="button" aria-controls="site-menu" aria-expanded="false" data-menu-toggle><span data-menu-label>Menu</span></button>
    
        <nav class="site-nav" id="site-menu" aria-label="Navegação principal" data-menu>
          <?php
          wp_nav_menu(
            array(
              'theme_location' => TWO_P_GROWTH_HOME_IDAC_MENU,
              'container'      => false,
              'menu_class'     => 'menu two-p-growth-home-menu',
              'fallback_cb'    => 'two_p_growth_home_idac_menu_fallback',
            )
          );
          ?>
        </nav><a class="button button-small header-cta" href="#contato" data-cta-intent="geral" data-cta-location="interna-contato-header">Falar com o IDAC</a>
  </div></header><main id="conteudo"><section class="in-contact-intro">
    <div class="container in-contact-grid">
      <div>
        <nav class="in-breadcrumb" aria-label="Localização"><a href="<?php echo esc_url( two_p_idac_internal_url( '/' ) ); ?>">Início</a><span>/</span><span>Contato</span></nav>
        <p class="eyebrow">Vamos conversar</p>
        <h1>Uma conversa pode abrir<br />novas possibilidades.</h1>
        <p>Cursos, prática individual, parcerias ou projetos para sua instituição. Conte seu objetivo e encontre o caminho com o IDAC.</p>
      </div>
      <figure class="in-contact-photo">
        <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/fachada-idac.jpg' ) ); ?>" alt="Fachada do Instituto DAC na Rua Pedra Azul, 505, Aclimação, São Paulo" width="1400" height="865" fetchpriority="high" />
      </figure>
    </div>
  </section>
  <section class="in-contact-info"><div class="container"><div><span>Visite o instituto</span><address>Rua Pedra Azul, 505<br />Aclimação · São Paulo, SP<br />CEP 04109-000</address></div><div><span>Contato da equipe</span><a href="#contato" data-cta-intent="geral" data-cta-location="contato-telefone">(11) 91468-8835</a><p>Envie seu interesse no formulário abaixo.</p></div><a class="in-text-link" href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%20Rua%20Pedra%20Azul%20505" target="_blank" rel="noopener noreferrer">Traçar rota até o IDAC <span aria-hidden="true">↗</span></a></div></section><section class="final-cta" id="contato" aria-labelledby="final-cta-title">
        <div class="container final-cta-inner" data-reveal>
          <p class="eyebrow eyebrow-light">Comece uma conversa</p>
          <h2 id="final-cta-title">Qual experiência médica você quer construir?</h2>
          <p>
            Conte seu objetivo à equipe do IDAC e descubra o formato mais adequado para sua turma,
            treinamento ou projeto.
          </p>
          <form class="final-cta-form" data-lead-form data-integration="rd-station-crm">
            <p class="final-cta-form-context" data-lead-form-context aria-live="polite">
              Selecione seu interesse para que o contato seja encaminhado corretamente.
            </p>
            <div class="final-cta-form-row">
              <label>
                Nome completo
                <input type="text" name="name" autocomplete="name" required />
              </label>
              <label>
                WhatsApp
                <input type="tel" name="personal_phone" autocomplete="tel" placeholder="(11) 90000-0000" required />
              </label>
            </div>
            <label>
              E-mail
              <input type="email" name="email" autocomplete="email" required />
            </label>
            <label>
              Qual é o seu interesse?
              <select name="cf_interesse_idac" data-lead-interest required>
                <option value="">Selecione uma opção</option>
                <optgroup label="Cursos e próximas turmas">
                  <option value="cursos" data-lead-type="curso">Cursos presenciais e próximas turmas</option>
                </optgroup>
                <optgroup label="Treinamentos e projetos">
                  <option value="individual" data-lead-type="projeto">Mentoria médica individualizada</option>
                  <option value="professores" data-lead-type="projeto">Curso em Parceria com Professores</option>
                  <option value="corporativo" data-lead-type="projeto">Treinamento Corporativo para Médicos</option>
                  <option value="locacao-eventos" data-lead-type="projeto">Locação para workshops e eventos</option>
                  <option value="pesquisa" data-lead-type="projeto">Projeto de Pesquisa em Saúde</option>
                  <option value="inovacao" data-lead-type="projeto">Desenvolvimento e Validação de Tecnologia Médica</option>
                </optgroup>
                <optgroup label="Outros assuntos">
                  <option value="estrutura" data-lead-type="geral">Estrutura e localização</option>
                  <option value="duvida" data-lead-type="geral">Dúvidas e outras informações</option>
                  <option value="geral" data-lead-type="geral">Ainda não sei qual formato escolher</option>
                </optgroup>
              </select>
            </label>
            <label>
              Conte seu objetivo <span class="form-optional">(opcional)</span>
              <textarea
                name="message"
                rows="3"
                placeholder="Turma presencial, treinamento individual, parceria ou projeto corporativo"
              ></textarea>
            </label>
            <label class="final-cta-consent">
              <input type="checkbox" name="privacy_consent" value="true" required />
              <span>Li e concordo com o tratamento dos meus dados conforme o <a href="<?php echo esc_url( two_p_idac_internal_url( '/politica-de-privacidade/' ) ); ?>">Aviso de privacidade</a>.</span>
            </label>
            <input type="hidden" name="cf_tipo_de_lead" value="" data-lead-type-field />
            <input type="hidden" name="cf_origem_cta" value="interna-contato" data-lead-origin-field />
            <input type="hidden" name="submission_identifier" value="site-idac-contato" data-lead-submission-field />
            <input type="hidden" name="page_path" value="" data-page-path-field />
            <input type="hidden" name="utm_source" value="" data-attribution-field="utm_source" />
            <input type="hidden" name="utm_medium" value="" data-attribution-field="utm_medium" />
            <input type="hidden" name="utm_campaign" value="" data-attribution-field="utm_campaign" />
            <input type="hidden" name="utm_content" value="" data-attribution-field="utm_content" />
            <input type="hidden" name="utm_term" value="" data-attribution-field="utm_term" />
            <input type="hidden" name="legal_basis" value="consentimento" />
            <div class="final-cta-honeypot" aria-hidden="true">
              <label>Não preencha este campo<input type="text" name="website" tabindex="-1" autocomplete="off" /></label>
            </div>
            <button type="submit" class="button" data-lead-submit>Enviar interesse</button>
            <p class="final-cta-form-status" data-lead-form-status role="status" aria-live="polite"></p>
          </form>
        </div>
      </section></main><footer class="site-footer" id="rodape">
      <div class="container footer-grid">
        <div class="footer-brand">
          <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>" alt="Instituto DAC" width="214" height="89" loading="lazy" />
          <p>
            Educação médica prática, estrutura e operação para médicos, professores, empresas e
            instituições de saúde.
          </p>
          <a
            class="footer-contact"
            href="#contato"
            data-cta-location="rodape"
            data-cta-intent="geral"
          >Falar com o IDAC</a>
        </div>

        <nav class="footer-nav" aria-label="Navegação do rodapé">
          <h2>Explore</h2>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/quem-somos/' ) ); ?>">Quem somos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/contato/' ) ); ?>">Contato</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#modalidades' ) ); ?>">Modalidades</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#estrutura' ) ); ?>">Estrutura</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#diferenciais' ) ); ?>">Cursos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/quem-somos/#formacoes' ) ); ?>">Histórico de cursos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#depoimentos' ) ); ?>">Depoimentos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#faq' ) ); ?>">Perguntas frequentes</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#localizacao' ) ); ?>">Localização</a>
        </nav>

        <div class="footer-visit">
          <h2>Visite o IDAC</h2>
          <address>Rua Pedra Azul, 505<br />Aclimação — São Paulo, SP<br />CEP 04109-000</address>
          <a
            class="footer-route"
            href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
            target="_blank"
            rel="noopener noreferrer"
            data-external="maps"
          >Traçar rota até o instituto</a>

          <h2 class="footer-contact-title">Contato</h2>
          <a
            href="#contato"
            data-cta-location="rodape"
            data-cta-intent="geral"
          >(11) 91468-8835</a>
          <a href="mailto:comercial@institutodac.com">comercial@institutodac.com</a>
          <nav class="footer-social" aria-label="Instituto DAC nas redes sociais">
            <?php two_p_growth_home_idac_render_youtube_icon(); ?>
            <a href="https://www.instagram.com/instituto_dac/" aria-label="Instagram" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
            <a href="https://www.linkedin.com/company/instituto-dac/" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><circle cx="5.5" cy="6" r="1.8"/><path d="M4 9h3v11H4zm6 0h3v1.5c.6-1 1.6-1.8 3.4-1.8 2.7 0 3.6 1.7 3.6 4.4V20h-3v-6c0-1.6-.5-2.4-1.8-2.4S13 12.5 13 14v6h-3z"/></svg></a>
            <a href="https://www.google.com/maps/place/Instituto+Dac+-+IDAC/@-23.5771323,-46.6287882,17z/" aria-label="Perfil do IDAC no Google" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"><path d="M18 6.7a8 8 0 1 0 2 5.3h-8"/></svg></a>
            <a href="https://api.whatsapp.com/send/?phone=5511914688835" aria-label="WhatsApp" target="_blank" rel="noopener noreferrer" data-external="whatsapp"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M21 11.7a9 9 0 0 1-13.2 8L3 21l1.3-4.6A9 9 0 1 1 21 11.7Z"/><path d="M9 7.5c-2 0-1 3.8 1.6 6.2s5.6 2.7 5.9 1l.3-1-2.7-1.3-1 1c-1.3-.5-2.4-1.6-2.9-2.8l.9-.9L10 7.5Z" fill="currentColor" stroke="none"/></svg></a>
            <a href="https://www.facebook.com/institutodac/" aria-label="Facebook" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><path d="M14.5 21v-8h2.7l.4-3h-3.1V8.3c0-.9.3-1.5 1.6-1.5h1.6V4.1a19 19 0 0 0-2.4-.1c-2.5 0-4.1 1.5-4.1 4.2V10H8.5v3h2.7v8z"/></svg></a>
          </nav>
        </div>

        <div class="footer-map">
          <iframe
            title="Mapa com a localização do Instituto DAC"
            src="https://www.google.com/maps?q=Instituto%20DAC%20-%20IDAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20S%C3%A3o%20Paulo&amp;output=embed"
            width="600"
            height="420"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          ></iframe>
          <a
            href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
            target="_blank"
            rel="noopener noreferrer"
            data-external="maps"
          >Abrir rota no Google Maps</a>
        </div>
      </div>
      <div class="container footer-bottom">
        <p>© <span data-year>2026</span> Instituto DAC. Todos os direitos reservados.</p>
        <a href="<?php echo esc_url( two_p_idac_internal_url( '/politica-de-privacidade/' ) ); ?>">Aviso de privacidade</a>
      </div>
    </footer><?php wp_footer(); ?></body></html>