<?php defined( 'ABSPATH' ) || exit; ?>
<!doctype html><html class="two-p-growth-home-idac-document" <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>" /><meta name="viewport" content="width=device-width,initial-scale=1" /><meta name="theme-color" content="#101416" />
<link rel="icon" href="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'favicon.png' ) ); ?>" />
<?php two_p_idac_head(); wp_head(); ?></head>
<body <?php body_class( 'two-p-growth-home-idac idac-internal' ); ?> data-internal-page="privacidade">
<?php wp_body_open(); if ( two_p_idac_preview_key() ) { echo '<aside class="in-admin-preview">Prévia autenticada — nenhum formulário envia dados nesta visualização.</aside>'; } ?><a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
  <header class="site-header" data-header><div class="container header-inner">
    <a class="brand" href="<?php echo esc_url( two_p_idac_internal_url( '/' ) ); ?>" aria-label="Instituto DAC — início"><img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>" alt="Instituto DAC" width="214" height="89" /></a>
    <button class="menu-toggle" type="button" aria-controls="site-menu" aria-expanded="false" data-menu-toggle><span data-menu-label>Menu</span></button>
    
        <nav class="site-nav" id="site-menu" aria-label="Navegação principal" data-menu>
          <?php
          wp_nav_menu(
            array(
              'theme_location' => TWO_P_GROWTH_HOME_IDAC_MENU,
              'container'      => false,
              'menu_class'     => 'menu two-p-growth-home-menu',
              'fallback_cb'    => 'two_p_growth_home_idac_menu_fallback',
            )
          );
          ?>
        </nav><a class="button button-small header-cta" href="<?php echo esc_url( two_p_idac_internal_url( '/contato/#contato' ) ); ?>" data-cta-intent="geral" data-cta-location="interna-privacidade-header">Falar com o IDAC</a>
  </div></header><main id="conteudo"><section class="in-contact-intro in-legal-intro"><div class="container"><p class="eyebrow">Instituto DAC</p><h1>Política de Privacidade</h1><p>Informações sobre o tratamento dos dados enviados ao site e os canais para falar com o instituto.</p></div></section><article class="container in-legal"><p>Esta política descreve as finalidades e os serviços envolvidos quando você navega no site do Instituto DAC, envia um formulário ou solicita informações sobre cursos e projetos.</p><section><h2>1. Dados que você informa</h2><p>Os formulários de contato podem solicitar nome, e-mail, telefone/WhatsApp, área de interesse e uma mensagem opcional. A lista de próximas turmas também registra os cursos selecionados. O envio inclui a página de origem e parâmetros de campanha, quando presentes, para identificar o contexto da solicitação.</p></section><section><h2>2. Para que usamos essas informações</h2><p>Os dados são utilizados para responder solicitações, orientar sobre cursos e projetos e entrar em contato a respeito do interesse informado. A inscrição na lista de próximas turmas permite que a equipe comunique oportunidades relacionadas aos cursos selecionados.</p></section><section><h2>3. Serviços utilizados no atendimento</h2><p>Os formulários de contato e de próximas turmas são encaminhados à equipe comercial por e-mail e registrados no RD Station CRM. A lista de próximas turmas também é registrada em uma planilha do Google, por integração com o Google Apps Script.</p></section><section><h2>4. Links, mapas e serviços externos</h2><p>O site pode apresentar mapa do Google e links para WhatsApp e outros sites. Ao utilizar esses recursos, aplicam-se também as práticas de privacidade dos respectivos fornecedores. O WhatsApp só é aberto nas jornadas em que essa continuidade de atendimento é apresentada.</p></section><section><h2>5. Cookies e dados técnicos</h2><p>O ambiente WordPress pode utilizar cookies e ferramentas de análise. As preferências disponíveis são apresentadas pelo mecanismo de consentimento do site. Dados técnicos necessários à segurança e ao funcionamento dos formulários podem ser tratados para prevenção de abuso e diagnóstico de falhas.</p></section><section><h2>6. Armazenamento e proteção</h2><p>O acesso aos dados deve ser limitado às pessoas e aos fornecedores envolvidos nas finalidades descritas. A conservação considera a finalidade do atendimento e as obrigações aplicáveis. Informações sobre prazos e sobre uma solicitação específica podem ser obtidas com o Instituto DAC.</p></section><section><h2>7. Suas solicitações</h2><p>Você pode entrar em contato para solicitar informações sobre o tratamento dos seus dados, acesso ou correção das informações e avaliação de pedidos de exclusão ou revogação do consentimento, conforme o caso.</p></section><section><h2>8. Fale com o instituto</h2><p>Para solicitações sobre privacidade, utilize o <a href="<?php echo esc_url( two_p_idac_internal_url( '/contato/#contato' ) ); ?>">formulário de contato</a> e informe o assunto na mensagem. O canal divulgado do Instituto DAC é <a href="tel:+5511914688835">(11) 91468-8835</a>.</p></section></article></main><footer class="site-footer" id="rodape">
      <div class="container footer-grid">
        <div class="footer-brand">
          <img src="<?php echo esc_url( two_p_growth_home_idac_asset_url( 'images/logo-idac.png' ) ); ?>" alt="Instituto DAC" width="214" height="89" loading="lazy" />
          <p>
            Educação médica prática, estrutura e operação para médicos, professores, empresas e
            instituições de saúde.
          </p>
          <a
            class="footer-contact"
            href="<?php echo esc_url( two_p_idac_internal_url( '/contato/#contato' ) ); ?>"
            data-cta-location="rodape"
            data-cta-intent="geral"
          >Falar com o IDAC</a>
        </div>

        <nav class="footer-nav" aria-label="Navegação do rodapé">
          <h2>Explore</h2>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/quem-somos/' ) ); ?>">Quem somos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/contato/' ) ); ?>">Contato</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#modalidades' ) ); ?>">Modalidades</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#estrutura' ) ); ?>">Estrutura</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#diferenciais' ) ); ?>">Cursos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/quem-somos/#formacoes' ) ); ?>">Histórico de cursos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#depoimentos' ) ); ?>">Depoimentos</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#faq' ) ); ?>">Perguntas frequentes</a>
          <a href="<?php echo esc_url( two_p_idac_internal_url( '/#localizacao' ) ); ?>">Localização</a>
        </nav>

        <div class="footer-visit">
          <h2>Visite o IDAC</h2>
          <address>Rua Pedra Azul, 505<br />Aclimação — São Paulo, SP<br />CEP 04109-000</address>
          <a
            class="footer-route"
            href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
            target="_blank"
            rel="noopener noreferrer"
            data-external="maps"
          >Traçar rota até o instituto</a>

          <h2 class="footer-contact-title">Contato</h2>
          <a
            href="<?php echo esc_url( two_p_idac_internal_url( '/contato/#contato' ) ); ?>"
            data-cta-location="rodape"
            data-cta-intent="geral"
          >(11) 91468-8835</a>
          <a href="mailto:comercial@institutodac.com">comercial@institutodac.com</a>
          <nav class="footer-social" aria-label="Instituto DAC nas redes sociais">
            <?php two_p_growth_home_idac_render_youtube_icon(); ?>
            <a href="https://www.instagram.com/instituto_dac/" aria-label="Instagram" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
            <a href="https://www.linkedin.com/company/instituto-dac/" aria-label="LinkedIn" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><circle cx="5.5" cy="6" r="1.8"/><path d="M4 9h3v11H4zm6 0h3v1.5c.6-1 1.6-1.8 3.4-1.8 2.7 0 3.6 1.7 3.6 4.4V20h-3v-6c0-1.6-.5-2.4-1.8-2.4S13 12.5 13 14v6h-3z"/></svg></a>
            <a href="https://www.google.com/maps/place/Instituto+Dac+-+IDAC/@-23.5771323,-46.6287882,17z/" aria-label="Perfil do IDAC no Google" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5"><path d="M18 6.7a8 8 0 1 0 2 5.3h-8"/></svg></a>
            <a href="https://api.whatsapp.com/send/?phone=5511914688835" aria-label="WhatsApp" target="_blank" rel="noopener noreferrer" data-external="whatsapp"><svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M21 11.7a9 9 0 0 1-13.2 8L3 21l1.3-4.6A9 9 0 1 1 21 11.7Z"/><path d="M9 7.5c-2 0-1 3.8 1.6 6.2s5.6 2.7 5.9 1l.3-1-2.7-1.3-1 1c-1.3-.5-2.4-1.6-2.9-2.8l.9-.9L10 7.5Z" fill="currentColor" stroke="none"/></svg></a>
            <a href="https://www.facebook.com/institutodac/" aria-label="Facebook" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><path d="M14.5 21v-8h2.7l.4-3h-3.1V8.3c0-.9.3-1.5 1.6-1.5h1.6V4.1a19 19 0 0 0-2.4-.1c-2.5 0-4.1 1.5-4.1 4.2V10H8.5v3h2.7v8z"/></svg></a>
          </nav>
        </div>

        <div class="footer-map">
          <iframe
            title="Mapa com a localização do Instituto DAC"
            src="https://www.google.com/maps?q=Instituto%20DAC%20-%20IDAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20S%C3%A3o%20Paulo&amp;output=embed"
            width="600"
            height="420"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          ></iframe>
          <a
            href="https://www.google.com/maps/dir/?api=1&amp;destination=Instituto%20DAC%2C%20Rua%20Pedra%20Azul%2C%20505%2C%20Aclima%C3%A7%C3%A3o%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2004109-000"
            target="_blank"
            rel="noopener noreferrer"
            data-external="maps"
          >Abrir rota no Google Maps</a>
        </div>
      </div>
      <div class="container footer-bottom">
        <p>© <span data-year>2026</span> Instituto DAC. Todos os direitos reservados.</p>
        <a href="<?php echo esc_url( two_p_idac_internal_url( '/politica-de-privacidade/' ) ); ?>">Aviso de privacidade</a>
      </div>
    </footer><?php wp_footer(); ?></body></html>