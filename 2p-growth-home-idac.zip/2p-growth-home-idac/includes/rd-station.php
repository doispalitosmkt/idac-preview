<?php
/**
 * Server-side RD Station CRM integration.
 *
 * @package TwoPGrowthHomeIDAC
 */

defined( 'ABSPATH' ) || exit;

define( 'TWO_P_GROWTH_HOME_IDAC_RD_API_BASE', 'https://crm.rdstation.com/api/v1/' );

/**
 * Returns the configured CRM instance token without exposing it to the browser.
 */
function two_p_growth_home_idac_rd_token() {
	if ( defined( 'TWO_P_GROWTH_HOME_IDAC_RD_TOKEN' ) ) {
		return trim( (string) TWO_P_GROWTH_HOME_IDAC_RD_TOKEN );
	}

	$settings = two_p_growth_home_idac_get_settings();

	return isset( $settings['rd_token'] ) ? trim( (string) $settings['rd_token'] ) : '';
}

/**
 * Checks whether the direct CRM integration can be used.
 */
function two_p_growth_home_idac_rd_is_configured() {
	return '' !== two_p_growth_home_idac_rd_token();
}

/**
 * Returns the public WordPress REST endpoint consumed by the lead form.
 */
function two_p_growth_home_idac_internal_lead_endpoint() {
	return rest_url( 'two-p-growth-home-idac/v1/leads' );
}

/**
 * Executes a request against the fixed RD Station CRM API host.
 *
 * @param string               $path   API path relative to the v1 base URL.
 * @param string               $method HTTP method.
 * @param array<string, mixed> $body   Optional JSON body.
 * @return array<string, mixed>|WP_Error
 */
function two_p_growth_home_idac_rd_request( $path, $method = 'GET', $body = array() ) {
	$token = two_p_growth_home_idac_rd_token();
	if ( ! $token ) {
		return new WP_Error( 'rd_not_configured', 'O token do RD Station CRM ainda não foi configurado.' );
	}

	$url  = add_query_arg( 'token', $token, TWO_P_GROWTH_HOME_IDAC_RD_API_BASE . ltrim( $path, '/' ) );
	$args = array(
		'method'      => strtoupper( $method ),
		'timeout'     => 15,
		'redirection' => 0,
		'headers'     => array(
			'Accept'       => 'application/json',
			'Content-Type' => 'application/json',
		),
	);

	if ( $body ) {
		$args['body'] = wp_json_encode( $body );
	}

	$response = wp_remote_request( $url, $args );
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'rd_connection_error', 'Não foi possível conectar ao RD Station CRM.' );
	}

	$status  = (int) wp_remote_retrieve_response_code( $response );
	$content = wp_remote_retrieve_body( $response );
	$data    = json_decode( $content, true );

	if ( $status < 200 || $status >= 300 ) {
		$message = 401 === $status
			? 'O RD Station recusou o token informado.'
			: sprintf( 'O RD Station retornou o código HTTP %d.', $status );

		return new WP_Error(
			'rd_api_error',
			$message,
			array(
				'status' => $status,
				'body'   => is_array( $data ) ? $data : array(),
			)
		);
	}

	return is_array( $data ) ? $data : array();
}

/**
 * Registers the same-origin endpoint used by the public lead form.
 */
function two_p_growth_home_idac_register_lead_route() {
	register_rest_route(
		'two-p-growth-home-idac/v1',
		'/leads',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => 'two_p_growth_home_idac_receive_lead',
			'permission_callback' => '__return_true',
		)
	);
}
add_action( 'rest_api_init', 'two_p_growth_home_idac_register_lead_route' );

/**
 * Rejects browser submissions originating from a different host.
 *
 * Requests without an Origin or Referer still pass because privacy tools and
 * proxies may remove both headers; validation and rate limiting remain active.
 *
 * @param WP_REST_Request $request REST request.
 */
function two_p_growth_home_idac_is_same_origin_request( $request ) {
	$source = $request->get_header( 'origin' );
	if ( ! $source ) {
		$source = $request->get_header( 'referer' );
	}

	if ( ! $source ) {
		return true;
	}

	$source_host = wp_parse_url( $source, PHP_URL_HOST );
	$site_host   = wp_parse_url( home_url( '/' ), PHP_URL_HOST );

	return $source_host && $site_host && strtolower( $source_host ) === strtolower( $site_host );
}

/**
 * Applies a small per-IP submission limit before contacting the CRM.
 *
 * @return true|WP_Error
 */
function two_p_growth_home_idac_check_lead_rate_limit() {
	$ip_candidates = array(
		isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) : '',
		isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '',
	);
	$ip            = '';

	foreach ( $ip_candidates as $candidate ) {
		if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
			$ip = $candidate;
			break;
		}
	}

	if ( ! $ip ) {
		return true;
	}

	$key   = 'two_p_idac_rate_' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 32 );
	$count = (int) get_transient( $key );

	if ( $count >= 10 ) {
		return new WP_Error(
			'lead_rate_limited',
			'Muitas tentativas foram recebidas. Aguarde alguns minutos e tente novamente.',
			array( 'status' => 429 )
		);
	}

	set_transient( $key, $count + 1, 10 * MINUTE_IN_SECONDS );

	return true;
}

/**
 * Defines every interest accepted from the public form and its CRM category.
 *
 * @return array<string, array{label: string, type: string}>
 */
function two_p_growth_home_idac_lead_interests() {
	return array(
		'cursos'                       => array( 'label' => 'Cursos presenciais e próximas turmas', 'type' => 'curso' ),
		'anatomia-topografica'         => array( 'label' => 'Imersão em Anatomia Topográfica', 'type' => 'curso' ),
		'vias-de-acesso'               => array( 'label' => 'Vias de Acesso e Dissecção Cirúrgica', 'type' => 'curso' ),
		'mini-residencia-reconstrucoes' => array( 'label' => 'Mini-residência em Reconstruções Cirúrgicas', 'type' => 'curso' ),
		'full-face'                    => array( 'label' => 'Full Face, Fios de Sustentação e Bioestimuladores', 'type' => 'curso' ),
		'medicina-regenerativa'        => array( 'label' => 'Medicina Regenerativa', 'type' => 'curso' ),
		'suturas'                      => array( 'label' => 'Suturas', 'type' => 'curso' ),
		'retalhos-membro-superior'     => array( 'label' => 'Retalhos para Membro Superior', 'type' => 'curso' ),
		'trapezio-inferior'            => array( 'label' => 'Transferência do Trapézio Inferior', 'type' => 'curso' ),
		'individual'                   => array( 'label' => 'Treinamento Médico Individualizado', 'type' => 'projeto' ),
		'professores'                  => array( 'label' => 'Curso em Parceria com Professores', 'type' => 'projeto' ),
		'corporativo'                  => array( 'label' => 'Treinamento Corporativo para Médicos', 'type' => 'projeto' ),
		'pesquisa'                     => array( 'label' => 'Projeto de Pesquisa em Saúde', 'type' => 'projeto' ),
		'inovacao'                     => array( 'label' => 'Desenvolvimento e Validação de Tecnologia Médica', 'type' => 'projeto' ),
		'estrutura'                    => array( 'label' => 'Estrutura e localização', 'type' => 'geral' ),
		'duvida'                       => array( 'label' => 'Dúvidas e outras informações', 'type' => 'geral' ),
		'geral'                        => array( 'label' => 'Ainda não sei qual formato escolher', 'type' => 'geral' ),
	);
}

/**
 * Normalizes and validates the public form payload.
 *
 * @param array<string, mixed> $payload Raw JSON payload.
 * @return array<string, mixed>|WP_Error
 */
function two_p_growth_home_idac_validate_lead_payload( $payload ) {
	$contact        = isset( $payload['contact'] ) && is_array( $payload['contact'] ) ? $payload['contact'] : array();
	$classification = isset( $payload['classification'] ) && is_array( $payload['classification'] ) ? $payload['classification'] : array();
	$attribution    = isset( $payload['attribution'] ) && is_array( $payload['attribution'] ) ? $payload['attribution'] : array();
	$consent        = isset( $payload['consent'] ) && is_array( $payload['consent'] ) ? $payload['consent'] : array();
	$name           = isset( $contact['name'] ) ? sanitize_text_field( $contact['name'] ) : '';
	$email          = isset( $contact['email'] ) ? sanitize_email( $contact['email'] ) : '';
	$phone          = isset( $contact['personal_phone'] ) ? preg_replace( '/[^0-9+]/', '', (string) $contact['personal_phone'] ) : '';
	$interest       = isset( $classification['interest'] ) ? sanitize_key( $classification['interest'] ) : '';
	$interests      = two_p_growth_home_idac_lead_interests();

	if ( strlen( $name ) < 2 || ! is_email( $email ) || strlen( preg_replace( '/\D/', '', $phone ) ) < 8 ) {
		return new WP_Error( 'invalid_contact', 'Confira nome, e-mail e telefone.', array( 'status' => 400 ) );
	}

	if ( ! isset( $interests[ $interest ] ) ) {
		return new WP_Error( 'invalid_interest', 'Selecione um interesse válido.', array( 'status' => 400 ) );
	}

	if ( empty( $consent['privacy'] ) ) {
		return new WP_Error( 'privacy_required', 'O aceite do Aviso de privacidade é obrigatório.', array( 'status' => 400 ) );
	}

	$clean_attribution = array();
	foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term' ) as $field ) {
		$clean_attribution[ $field ] = isset( $attribution[ $field ] )
			? wp_html_excerpt( sanitize_text_field( $attribution[ $field ] ), 160, '' )
			: '';
	}

	$clean_attribution['page_url'] = isset( $attribution['page_url'] ) ? esc_url_raw( $attribution['page_url'] ) : '';
	$clean_attribution['referrer'] = isset( $attribution['referrer'] ) ? esc_url_raw( $attribution['referrer'] ) : '';

	return array(
		'name'                  => wp_html_excerpt( $name, 120, '' ),
		'email'                 => $email,
		'phone'                 => wp_html_excerpt( $phone, 24, '' ),
		'interest'              => $interest,
		'interest_label'        => $interests[ $interest ]['label'],
		'lead_type'             => $interests[ $interest ]['type'],
		'cta_origin'            => isset( $classification['cta_origin'] ) ? wp_html_excerpt( sanitize_key( $classification['cta_origin'] ), 100, '' ) : 'formulario-direto',
		'message'               => isset( $payload['message'] ) ? wp_html_excerpt( sanitize_textarea_field( $payload['message'] ), 3000, '' ) : '',
		'submission_identifier' => isset( $payload['submission_identifier'] ) ? wp_html_excerpt( sanitize_key( $payload['submission_identifier'] ), 100, '' ) : 'site-idac-contato',
		'attribution'           => $clean_attribution,
	);
}

/**
 * Builds the note saved in the RD deal timeline.
 *
 * @param array<string, mixed> $lead Validated lead.
 */
function two_p_growth_home_idac_build_rd_note( $lead ) {
	$lines = array(
		'Lead recebido pelo formulário da nova home do Instituto DAC.',
		'Tipo de lead: ' . $lead['lead_type'],
		'Interesse: ' . $lead['interest_label'] . ' (' . $lead['interest'] . ')',
		'Origem do CTA: ' . $lead['cta_origin'],
		'Identificador: ' . $lead['submission_identifier'],
	);

	if ( $lead['message'] ) {
		$lines[] = 'Mensagem: ' . $lead['message'];
	}
	if ( $lead['attribution']['page_url'] ) {
		$lines[] = 'Página: ' . $lead['attribution']['page_url'];
	}
	if ( $lead['attribution']['referrer'] ) {
		$lines[] = 'Referência: ' . $lead['attribution']['referrer'];
	}

	$utm_parts = array();
	foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term' ) as $field ) {
		if ( $lead['attribution'][ $field ] ) {
			$utm_parts[] = $field . '=' . $lead['attribution'][ $field ];
		}
	}
	if ( $utm_parts ) {
		$lines[] = 'Atribuição: ' . implode( ' | ', $utm_parts );
	}

	$lines[] = 'Base legal informada no formulário: consentimento.';

	return implode( "\n", $lines );
}

/**
 * Receives a validated lead, creates a deal with its contact and writes context
 * to the deal timeline.
 *
 * @param WP_REST_Request $request REST request.
 * @return WP_REST_Response|WP_Error
 */
function two_p_growth_home_idac_receive_lead( $request ) {
	if ( ! two_p_growth_home_idac_is_same_origin_request( $request ) ) {
		return new WP_Error( 'invalid_origin', 'Origem da requisição não autorizada.', array( 'status' => 403 ) );
	}

	if ( ! two_p_growth_home_idac_rd_is_configured() ) {
		return new WP_Error( 'rd_not_configured', 'A integração ainda não foi configurada.', array( 'status' => 503 ) );
	}

	$rate_limit = two_p_growth_home_idac_check_lead_rate_limit();
	if ( is_wp_error( $rate_limit ) ) {
		return $rate_limit;
	}

	$payload = $request->get_json_params();
	$lead    = two_p_growth_home_idac_validate_lead_payload( is_array( $payload ) ? $payload : array() );
	if ( is_wp_error( $lead ) ) {
		return $lead;
	}

	$dedupe_key = 'two_p_idac_lead_' . substr( hash( 'sha256', strtolower( $lead['email'] ) . '|' . $lead['interest'] ), 0, 32 );
	if ( get_transient( $dedupe_key ) ) {
		return new WP_REST_Response( array( 'success' => true, 'duplicate' => true ), 200 );
	}

	$deal_name = wp_html_excerpt( 'Site IDAC — ' . $lead['interest_label'] . ' — ' . $lead['name'], 180, '' );
	$result    = two_p_growth_home_idac_rd_request(
		'deals',
		'POST',
		array(
			'contacts' => array(
				array(
					'name'        => $lead['name'],
					'emails'      => array( array( 'email' => $lead['email'] ) ),
					'phones'      => array( array( 'phone' => $lead['phone'], 'type' => 'work' ) ),
					'notes'       => two_p_growth_home_idac_build_rd_note( $lead ),
					'legal_bases' => array(
						array(
							'category' => 'communications',
							'type'     => 'consent',
							'status'   => 'granted',
						),
					),
				),
			),
			'deal'     => array(
				'name'   => $deal_name,
				'rating' => 1,
			),
		)
	);

	if ( is_wp_error( $result ) ) {
		update_option(
			'two_p_growth_home_idac_rd_last_error',
			array(
				'time'    => current_time( 'mysql' ),
				'message' => $result->get_error_message(),
			),
			false
		);

		return new WP_Error( 'lead_delivery_failed', 'Não foi possível enviar agora. Tente novamente em alguns instantes.', array( 'status' => 502 ) );
	}

	$deal_id = isset( $result['id'] ) ? $result['id'] : ( isset( $result['_id'] ) ? $result['_id'] : '' );
	$user_id = isset( $result['user']['id'] ) ? $result['user']['id'] : ( isset( $result['user']['_id'] ) ? $result['user']['_id'] : '' );

	if ( $deal_id ) {
		$activity = array(
			'deal_id' => $deal_id,
			'text'    => two_p_growth_home_idac_build_rd_note( $lead ),
		);
		if ( $user_id ) {
			$activity['user_id'] = $user_id;
		}

		two_p_growth_home_idac_rd_request( 'activities', 'POST', array( 'activity' => $activity ) );
	}

	delete_option( 'two_p_growth_home_idac_rd_last_error' );
	set_transient( $dedupe_key, $deal_id ? $deal_id : 'created', 5 * MINUTE_IN_SECONDS );

	return new WP_REST_Response( array( 'success' => true ), 201 );
}

/**
 * Tests the stored token from the protected WordPress settings screen.
 */
function two_p_growth_home_idac_test_rd_connection() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Você não tem permissão para realizar esta ação.', 'two-p-growth-home-idac' ) );
	}

	check_admin_referer( 'two_p_growth_home_idac_test_rd' );
	$result = two_p_growth_home_idac_rd_request( 'token/check' );
	$key    = 'two_p_growth_home_idac_rd_test_' . get_current_user_id();

	if ( is_wp_error( $result ) ) {
		set_transient( $key, array( 'type' => 'error', 'message' => $result->get_error_message() ), MINUTE_IN_SECONDS );
	} else {
		delete_option( 'two_p_growth_home_idac_rd_last_error' );
		set_transient( $key, array( 'type' => 'success', 'message' => 'Conexão confirmada com o RD Station CRM. Nenhum lead foi criado por este teste.' ), MINUTE_IN_SECONDS );
	}

	wp_safe_redirect( admin_url( 'options-general.php?page=two-p-growth-home-idac' ) );
	exit;
}
add_action( 'admin_post_two_p_growth_home_idac_test_rd', 'two_p_growth_home_idac_test_rd_connection' );

/**
 * Shows the result of the protected token check.
 */
function two_p_growth_home_idac_rd_test_notice() {
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	if ( ! current_user_can( 'manage_options' ) || 'two-p-growth-home-idac' !== $page ) {
		return;
	}

	$key    = 'two_p_growth_home_idac_rd_test_' . get_current_user_id();
	$notice = get_transient( $key );
	if ( ! is_array( $notice ) ) {
		return;
	}

	delete_transient( $key );
	$type = 'success' === $notice['type'] ? 'success' : 'error';
	printf(
		'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
		esc_attr( $type ),
		esc_html( $notice['message'] )
	);
}
add_action( 'admin_notices', 'two_p_growth_home_idac_rd_test_notice' );
