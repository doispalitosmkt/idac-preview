<?php
/**
 * Internal page templates, authenticated previews and reversible dashboard migration.
 * No activation hook changes pages, SEO settings or redirects.
 */
defined( 'ABSPATH' ) || exit;

function two_p_idac_pages() {
	static $pages = null;
	if ( null === $pages ) {
		$file = TWO_P_GROWTH_HOME_IDAC_DIR . 'data/internal-pages.json';
		$pages = is_readable( $file ) ? json_decode( file_get_contents( $file ), true ) : array();
		$pages = is_array( $pages ) ? $pages : array();
	}
	return $pages;
}

function two_p_idac_preview_key() {
	if ( ! isset( $_GET['idac_internal_preview'] ) || ! is_scalar( $_GET['idac_internal_preview'] ) || ! current_user_can( 'manage_options' ) ) {
		return '';
	}
	$key = sanitize_key( wp_unslash( $_GET['idac_internal_preview'] ) );
	$nonce = isset( $_GET['_wpnonce'] ) && is_scalar( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
	return isset( two_p_idac_pages()[ $key ] ) && wp_verify_nonce( $nonce, 'idac_internal_preview_' . $key ) ? $key : '';
}

function two_p_idac_internal_key() {
	$preview = two_p_idac_preview_key();
	if ( $preview ) {
		return $preview;
	}
	if ( ! is_singular( 'page' ) ) {
		return '';
	}
	$template = get_page_template_slug( get_queried_object_id() );
	foreach ( two_p_idac_pages() as $key => $page ) {
		if ( $page['template'] === $template ) {
			return $key;
		}
	}
	return '';
}

function two_p_idac_register_templates( $templates ) {
	foreach ( two_p_idac_pages() as $page ) {
		$templates[ $page['template'] ] = 'IDAC — ' . $page['title'];
	}
	return $templates;
}
add_filter( 'theme_page_templates', 'two_p_idac_register_templates' );

function two_p_idac_template_include( $template ) {
	$key = two_p_idac_internal_key();
	$file = TWO_P_GROWTH_HOME_IDAC_DIR . 'templates/internal-' . $key . '.php';
	return $key && is_readable( $file ) ? $file : $template;
}
add_filter( 'template_include', 'two_p_idac_template_include', 100 );

function two_p_idac_resolve_page( $definition ) {
	$post = get_page_by_path( $definition['slug'], OBJECT, 'page' );
	return $post && 'page' === $post->post_type && ! in_array( $post->post_status, array( 'trash', 'auto-draft' ), true ) ? $post : null;
}

function two_p_idac_preview_url( $key ) {
	return add_query_arg( array( 'idac_internal_preview' => $key, '_wpnonce' => wp_create_nonce( 'idac_internal_preview_' . $key ) ), home_url( '/' ) );
}

function two_p_idac_internal_url( $path ) {
	if ( two_p_idac_preview_key() ) {
		$parts = explode( '#', $path, 2 );
		$slug = trim( $parts[0], '/' );
		foreach ( two_p_idac_pages() as $key => $page ) {
			if ( $page['slug'] === $slug ) {
				return two_p_idac_preview_url( $key ) . ( isset( $parts[1] ) ? '#' . $parts[1] : '' );
			}
		}
	}
	return home_url( $path );
}

function two_p_idac_canonical( $original = '' ) {
	$key = two_p_idac_internal_key();
	return $key ? home_url( '/' . two_p_idac_pages()[ $key ]['slug'] . '/' ) : $original;
}

function two_p_idac_title( $original ) {
	$key = two_p_idac_internal_key();
	return $key ? two_p_idac_pages()[ $key ]['title'] . ' | Instituto DAC' : $original;
}

function two_p_idac_description( $original ) {
	$key = two_p_idac_internal_key();
	return $key ? two_p_idac_pages()[ $key ]['description'] : $original;
}
add_filter( 'pre_get_document_title', 'two_p_idac_title' );
add_filter( 'wpseo_title', 'two_p_idac_title' );
add_filter( 'wpseo_metadesc', 'two_p_idac_description' );
add_filter( 'wpseo_canonical', 'two_p_idac_canonical' );
add_filter( 'get_canonical_url', 'two_p_idac_canonical' );
add_filter( 'wpseo_opengraph_title', 'two_p_idac_title' );
add_filter( 'wpseo_opengraph_desc', 'two_p_idac_description' );
add_filter( 'wpseo_opengraph_url', 'two_p_idac_canonical' );
add_filter( 'rank_math/frontend/title', 'two_p_idac_title' );
add_filter( 'rank_math/frontend/description', 'two_p_idac_description' );
add_filter( 'rank_math/frontend/canonical', 'two_p_idac_canonical' );

function two_p_idac_head() {
	$key = two_p_idac_internal_key();
	if ( ! $key ) {
		return;
	}
	$page = two_p_idac_pages()[ $key ];
	$seo_plugin = defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' );
	if ( ! current_theme_supports( 'title-tag' ) && ! $seo_plugin ) {
		echo '<title>' . esc_html( two_p_idac_title( '' ) ) . '</title>';
	}
	if ( ! $seo_plugin ) {
		echo '<meta name="description" content="' . esc_attr( $page['description'] ) . '" />';
		if ( ! is_singular( 'page' ) ) {
			echo '<link rel="canonical" href="' . esc_url( two_p_idac_canonical() ) . '" />';
		}
		echo '<meta property="og:title" content="' . esc_attr( two_p_idac_title( '' ) ) . '" /><meta property="og:description" content="' . esc_attr( $page['description'] ) . '" /><meta property="og:url" content="' . esc_url( two_p_idac_canonical() ) . '" /><meta property="og:image" content="' . esc_url( two_p_growth_home_idac_asset_url( 'images/og-idac.jpg' ) ) . '" />';
	}
}

function two_p_idac_noindex() {
	$routing = get_option( 'two_p_idac_routing', array() );
	return two_p_idac_preview_key() || ( ! empty( $routing['noindex_old_home'] ) && is_page( 'home' ) );
}

function two_p_idac_robots( $robots ) {
	if ( two_p_idac_noindex() ) {
		unset( $robots['index'] );
		$robots['noindex'] = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'two_p_idac_robots' );
function two_p_idac_yoast_robots( $robots ) {
	if ( two_p_idac_noindex() ) {
		$robots['index'] = 'noindex';
	}
	return $robots;
}
add_filter( 'wpseo_robots_array', 'two_p_idac_yoast_robots' );

/** Keep pages deliberately retired from search out of both sitemap implementations. */
function two_p_idac_sitemap_exclusions( $ids ) {
	$routing = get_option( 'two_p_idac_routing', array() );
	$paths = ! empty( $routing['noindex_old_home'] ) ? array( 'home' ) : array();
	$rules = two_p_idac_redirect_definitions();
	foreach ( two_p_idac_active_redirects( $routing, $rules ) as $id ) {
		if ( isset( $rules[ $id ] ) && two_p_idac_redirect_target( $rules[ $id ] ) ) {
			$paths[] = trim( $rules[ $id ]['from'], '/' );
		}
	}
	foreach ( $paths as $path ) {
		$post = get_page_by_path( $path, OBJECT, 'page' );
		if ( $post ) {
			$ids[] = (int) $post->ID;
		}
	}
	return array_values( array_unique( $ids ) );
}
add_filter( 'wpseo_exclude_from_sitemap_by_post_ids', 'two_p_idac_sitemap_exclusions' );
function two_p_idac_core_sitemap( $args, $post_type ) {
	if ( 'page' === $post_type ) {
		$args['post__not_in'] = two_p_idac_sitemap_exclusions( isset( $args['post__not_in'] ) ? $args['post__not_in'] : array() );
	}
	return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', 'two_p_idac_core_sitemap', 10, 2 );

function two_p_idac_redirect_definitions() {
	$file = TWO_P_GROWTH_HOME_IDAC_DIR . 'data/internal-redirects.json';
	$data = is_readable( $file ) ? json_decode( file_get_contents( $file ), true ) : array();
	return is_array( $data ) ? $data : array();
}

/** Leaves existing choices alone and supplies defaults for newly consolidated catalogs. */
function two_p_idac_active_redirects( $routing, $definitions ) {
	$ids = isset( $routing['redirects'] ) && is_array( $routing['redirects'] ) ? $routing['redirects'] : array();
	if ( empty( $routing['catalog_choices_saved'] ) ) {
		foreach ( $definitions as $id => $rule ) {
			if ( ! empty( $rule['enabled_by_default'] ) && ! in_array( $id, $ids, true ) ) {
				$ids[] = $id;
			}
		}
	}
	return $ids;
}

/** Home anchors are valid only when the plugin's home is the published front page. */
function two_p_idac_redirect_target( $rule ) {
	$target_path = trim( (string) wp_parse_url( $rule['to'], PHP_URL_PATH ), '/' );
	if ( '' === $target_path ) {
		$front_id = (int) get_option( 'page_on_front' );
		if ( ! $front_id || 'page' !== get_option( 'show_on_front' ) || TWO_P_GROWTH_HOME_IDAC_TEMPLATE !== get_page_template_slug( $front_id ) ) {
			return null;
		}
		$target = get_post( $front_id );
	} else {
		$target = get_page_by_path( $target_path, OBJECT, 'page' );
	}
	return $target && 'publish' === $target->post_status ? $target : null;
}

function two_p_idac_frontend_rules() {
	if ( isset( $_GET['idac_internal_preview'] ) ) {
		if ( ! two_p_idac_preview_key() ) {
			wp_die( 'Prévia disponível somente para administradores autorizados.', 'Prévia IDAC', array( 'response' => 403 ) );
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow', true );
		return;
	}
	if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || ! in_array( $_SERVER['REQUEST_METHOD'], array( 'GET', 'HEAD' ), true ) ) {
		return;
	}
	$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH );
	if ( ! is_string( $path ) ) {
		return;
	}
	$base = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $base && 0 === strpos( $path, $base . '/' ) ) {
		$path = substr( $path, strlen( $base ) );
	}
	$routing = get_option( 'two_p_idac_routing', array() );
	$definitions = two_p_idac_redirect_definitions();
	foreach ( two_p_idac_active_redirects( $routing, $definitions ) as $id ) {
		if ( ! isset( $definitions[ $id ] ) || rtrim( $path, '/' ) !== rtrim( $definitions[ $id ]['from'], '/' ) ) {
			continue;
		}
		$rule = $definitions[ $id ];
		if ( ! two_p_idac_redirect_target( $rule ) ) {
			return;
		}
		$args = array();
		foreach ( array( 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term' ) as $field ) {
			if ( isset( $_GET[ $field ] ) && is_scalar( $_GET[ $field ] ) ) {
				$args[ $field ] = sanitize_text_field( wp_unslash( $_GET[ $field ] ) );
			}
		}
		if ( wp_safe_redirect( add_query_arg( $args, home_url( $rule['to'] ) ), 301, 'IDAC' ) ) {
			exit;
		}
		return;
	}
}
add_action( 'template_redirect', 'two_p_idac_frontend_rules', 0 );

function two_p_idac_history() {
	$history = get_option( 'two_p_idac_migration_history', array() );
	return is_array( $history ) ? $history : array();
}

function two_p_idac_save_batch( $batch ) {
	$history = two_p_idac_history();
	$history[ $batch['id'] ] = $batch;
	update_option( 'two_p_idac_migration_history', $history, false );
	$stored = two_p_idac_history();
	return isset( $stored[ $batch['id'] ] ) && $stored[ $batch['id'] ] === $batch;
}

function two_p_idac_lock() {
	$lock = get_option( 'two_p_idac_migration_lock', array() );
	if ( ! empty( $lock['until'] ) && $lock['until'] < time() ) {
		delete_option( 'two_p_idac_migration_lock' );
	}
	return add_option( 'two_p_idac_migration_lock', array( 'until' => time() + 300 ), '', false );
}

function two_p_idac_restore_item( $item ) {
	if ( $item['existed'] ) {
		update_post_meta( $item['id'], '_wp_page_template', $item['before'] );
	} else {
		delete_post_meta( $item['id'], '_wp_page_template' );
	}
	return (string) get_post_meta( $item['id'], '_wp_page_template', true ) === (string) $item['before'];
}

/** Validate the whole selection before changing any existing page. */
function two_p_idac_apply_pages( $keys, $privacy_approved = false ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return new WP_Error( 'forbidden', 'Permissão insuficiente.' );
	}
	$definitions = two_p_idac_pages();
	$items = array();
	foreach ( array_unique( $keys ) as $key ) {
		if ( ! isset( $definitions[ $key ] ) ) {
			return new WP_Error( 'unknown_page', 'Página fora do mapa autorizado.' );
		}
		$definition = $definitions[ $key ];
		if ( ! empty( $definition['needsReview'] ) && ! $privacy_approved ) {
			return new WP_Error( 'privacy_review', 'Valide o texto de privacidade antes de aplicar essa página.' );
		}
		$post = two_p_idac_resolve_page( $definition );
		if ( ! $post || ! current_user_can( 'edit_post', $post->ID ) ) {
			return new WP_Error( 'missing_page', 'Página ausente ou sem permissão: /' . $definition['slug'] . '/. Nenhuma página foi alterada.' );
		}
		$before = get_post_meta( $post->ID, '_wp_page_template', true );
		if ( $before === $definition['template'] ) {
			continue;
		}
		$items[] = array( 'key' => $key, 'id' => $post->ID, 'slug' => $definition['slug'], 'before' => $before, 'existed' => metadata_exists( 'post', $post->ID, '_wp_page_template' ), 'after' => $definition['template'] );
	}
	if ( ! $items ) {
		return new WP_Error( 'no_changes', 'Selecione páginas que ainda não usam o novo modelo.' );
	}
	if ( ! two_p_idac_lock() ) {
		return new WP_Error( 'busy', 'Há outra aplicação em andamento. Aguarde sua conclusão.' );
	}
	try {
		$batch = array( 'id' => wp_generate_uuid4(), 'kind' => 'pages', 'date' => current_time( 'mysql' ), 'status' => 'prepared', 'items' => $items );
		if ( ! two_p_idac_save_batch( $batch ) ) {
			return new WP_Error( 'snapshot_failed', 'Não foi possível preservar as configurações anteriores. Nenhuma página foi alterada.' );
		}
		$changed = array();
		foreach ( $items as $item ) {
			update_post_meta( $item['id'], '_wp_page_template', $item['after'] );
			$changed[] = $item;
			if ( get_post_meta( $item['id'], '_wp_page_template', true ) !== $item['after'] ) {
				$restored = true;
				foreach ( $changed as $undo ) {
					$restored = two_p_idac_restore_item( $undo ) && $restored;
				}
				$batch['status'] = $restored ? 'failed_restored' : 'needs_restore';
				two_p_idac_save_batch( $batch );
				return new WP_Error( 'write_failed', $restored ? 'A aplicação falhou e as configurações anteriores foram restauradas.' : 'A aplicação falhou. Use a reversão do lote para conferir a restauração.' );
			}
		}
		$batch['status'] = 'applied';
		two_p_idac_save_batch( $batch );
		return $batch;
	} finally {
		delete_option( 'two_p_idac_migration_lock' );
	}
}

function two_p_idac_apply_routing( $ids, $noindex ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return new WP_Error( 'forbidden', 'Permissão insuficiente.' );
	}
	$definitions = two_p_idac_redirect_definitions();
	foreach ( $ids as $id ) {
		if ( ! isset( $definitions[ $id ] ) ) {
			return new WP_Error( 'unknown_redirect', 'Regra não reconhecida.' );
		}
		$rule = $definitions[ $id ];
		$post = two_p_idac_redirect_target( $rule );
		if ( ! $post ) {
			return new WP_Error( 'missing_target', 'O destino precisa existir e estar publicado: ' . $rule['to'] );
		}
		if ( ! empty( $rule['requires'] ) && get_page_template_slug( $post->ID ) !== two_p_idac_pages()[ $rule['requires'] ]['template'] ) {
			return new WP_Error( 'content_not_migrated', 'Aplique Quem Somos com os diferenciais antes de consolidar Vantagens.' );
		}
	}
	if ( ! two_p_idac_lock() ) {
		return new WP_Error( 'busy', 'Há outra aplicação em andamento.' );
	}
	try {
		$before = get_option( 'two_p_idac_routing', array() );
		$after = array( 'redirects' => array_values( array_unique( $ids ) ), 'noindex_old_home' => (bool) $noindex, 'catalog_choices_saved' => true );
		if ( $before === $after ) {
			return new WP_Error( 'no_changes', 'As regras selecionadas já estão configuradas.' );
		}
		$batch = array( 'id' => wp_generate_uuid4(), 'kind' => 'routing', 'date' => current_time( 'mysql' ), 'status' => 'prepared', 'before' => $before, 'after' => $after );
		if ( ! two_p_idac_save_batch( $batch ) ) {
			return new WP_Error( 'snapshot_failed', 'Não foi possível registrar as configurações anteriores.' );
		}
		update_option( 'two_p_idac_routing', $after, false );
		if ( get_option( 'two_p_idac_routing', array() ) !== $after ) {
			return new WP_Error( 'write_failed', 'Não foi possível salvar as regras. Confira o histórico.' );
		}
		$batch['status'] = 'applied';
		two_p_idac_save_batch( $batch );
		return $batch;
	} finally {
		delete_option( 'two_p_idac_migration_lock' );
	}
}

function two_p_idac_rollback( $id ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		return new WP_Error( 'forbidden', 'Permissão insuficiente.' );
	}
	$history = two_p_idac_history();
	if ( ! isset( $history[ $id ] ) || ! in_array( $history[ $id ]['status'], array( 'applied', 'prepared', 'needs_restore' ), true ) ) {
		return new WP_Error( 'invalid_batch', 'Lote indisponível para reversão.' );
	}
	if ( ! two_p_idac_lock() ) {
		return new WP_Error( 'busy', 'Há outra aplicação em andamento.' );
	}
	try {
		$batch = $history[ $id ];
		$conflicts = array();
		if ( 'routing' === $batch['kind'] ) {
			$current = get_option( 'two_p_idac_routing', array() );
			if ( $current === $batch['after'] ) {
				update_option( 'two_p_idac_routing', $batch['before'], false );
				if ( get_option( 'two_p_idac_routing', array() ) !== $batch['before'] ) {
					$conflicts[] = 'regras';
				}
			} elseif ( $current !== $batch['before'] ) {
				$conflicts[] = 'regras modificadas depois deste lote';
			}
		} else {
			foreach ( $batch['items'] as $item ) {
				$current = get_post_meta( $item['id'], '_wp_page_template', true );
				if ( $current === $item['after'] ) {
					if ( ! two_p_idac_restore_item( $item ) ) {
						$conflicts[] = $item['slug'];
					}
				} elseif ( $current !== $item['before'] ) {
					$conflicts[] = $item['slug'];
				}
			}
		}
		$batch['status'] = $conflicts ? 'needs_restore' : 'rolled_back';
		$batch['conflicts'] = $conflicts;
		two_p_idac_save_batch( $batch );
		return $conflicts ? new WP_Error( 'manual_changes', 'Configurações alteradas depois do lote foram preservadas: ' . implode( ', ', $conflicts ) ) : $batch;
	} finally {
		delete_option( 'two_p_idac_migration_lock' );
	}
}

function two_p_idac_admin_menu() {
	add_submenu_page( 'options-general.php', 'Páginas internas IDAC', 'Páginas internas IDAC', 'manage_options', 'two-p-idac-internals', 'two_p_idac_admin_page' );
}
add_action( 'admin_menu', 'two_p_idac_admin_menu' );

function two_p_idac_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$notice = get_transient( 'two_p_idac_notice_' . get_current_user_id() );
	delete_transient( 'two_p_idac_notice_' . get_current_user_id() );
	echo '<div class="wrap"><h1>Páginas internas IDAC</h1><p>Confira as prévias e aplique os modelos às páginas existentes. Instalar ou atualizar o plugin não altera as páginas automaticamente.</p>';
	if ( $notice ) {
		echo '<div class="notice notice-info"><p>' . esc_html( $notice ) . '</p></div>';
	}
	echo '<h2>1. Prévias e aplicação em lote</h2><p>IDs, endereços, conteúdo do Elementor e metadados de SEO são preservados. O modelo passa a apresentar o conteúdo reformulado do pacote.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="two_p_idac_apply" />';
	wp_nonce_field( 'two_p_idac_apply' );
	echo '<table class="widefat striped"><thead><tr><th>Aplicar</th><th>Página e URL</th><th>Estado atual</th><th>Prévia</th></tr></thead><tbody>';
	foreach ( two_p_idac_pages() as $key => $page ) {
		$post = two_p_idac_resolve_page( $page );
		$current = $post ? get_page_template_slug( $post->ID ) : '';
		echo '<tr><td><input type="checkbox" name="pages[]" value="' . esc_attr( $key ) . '" aria-label="Aplicar ' . esc_attr( $page['title'] ) . '" ' . disabled( ! $post || $current === $page['template'], true, false ) . ' /></td><td><strong>' . esc_html( $page['title'] ) . '</strong><br /><code>/' . esc_html( $page['slug'] ) . '/</code></td><td>' . esc_html( $post ? 'ID ' . $post->ID . ' · ' . ( $current === $page['template'] ? 'Novo modelo aplicado' : ( $current ?: 'Padrão / Elementor' ) ) : 'Página não localizada — não será criada automaticamente' ) . '</td><td><a target="_blank" rel="noopener" href="' . esc_url( two_p_idac_preview_url( $key ) ) . '">Abrir prévia</a></td></tr>';
	}
	echo '</tbody></table><p><button type="button" class="button" onclick="this.form.querySelectorAll(\'input[name=&quot;pages[]&quot;]:not(:disabled)\').forEach(function(e){if(e.value!==\'privacidade\')e.checked=true;})">Selecionar páginas de conteúdo</button></p><p><label><input type="checkbox" name="privacy_approved" value="1" /> O texto e os canais da política de privacidade foram validados pelo Instituto DAC.</label></p>';
	submit_button( 'Aplicar páginas selecionadas' );
	echo '</form><hr /><h2>2. Redirecionamentos e indexação</h2><p>Presencial e Online levam à seção de cursos quando a home do plugin está publicada. Use os controles abaixo para ajustar as regras.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="two_p_idac_routing" />';
	wp_nonce_field( 'two_p_idac_routing' );
	$routing = get_option( 'two_p_idac_routing', array() );
	echo '<table class="widefat striped"><thead><tr><th>Ativar</th><th>Origem → destino (301)</th></tr></thead><tbody>';
	$definitions = two_p_idac_redirect_definitions();
	$active_redirects = two_p_idac_active_redirects( $routing, $definitions );
	foreach ( $definitions as $id => $rule ) {
		echo '<tr><td><input type="checkbox" name="redirects[]" value="' . esc_attr( $id ) . '" aria-label="Redirecionar ' . esc_attr( $rule['from'] ) . '" ' . checked( in_array( $id, $active_redirects, true ), true, false ) . ' /></td><td><code>' . esc_html( $rule['from'] ) . '</code><br />→ <code>' . esc_html( $rule['to'] ) . '</code></td></tr>';
	}
	echo '</tbody></table><p><label><input type="checkbox" name="noindex_old_home" value="1" ' . checked( ! empty( $routing['noindex_old_home'] ), true, false ) . ' /> Aplicar noindex somente na home antiga (/home/), mantendo-a acessível.</label></p>';
	submit_button( 'Salvar somente as regras selecionadas' );
	echo '</form><hr /><h2>3. Histórico e reversão</h2><p>A reversão restaura as configurações anteriores. Alterações manuais posteriores ao lote são preservadas e sinalizadas. Após aplicar ou reverter, limpe o cache pelo painel do site.</p>';
	foreach ( array_reverse( two_p_idac_history() ) as $batch ) {
		echo '<div style="padding:12px 0;border-top:1px solid #ddd"><strong>' . esc_html( $batch['date'] ) . '</strong> — ' . esc_html( $batch['kind'] . ' · ' . $batch['status'] );
		if ( in_array( $batch['status'], array( 'applied', 'prepared', 'needs_restore' ), true ) ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="two_p_idac_rollback" /><input type="hidden" name="batch" value="' . esc_attr( $batch['id'] ) . '" />';
			wp_nonce_field( 'two_p_idac_rollback' );
			submit_button( 'Reverter este lote', 'secondary', 'submit', false );
			echo '</form>';
		}
		echo '</div>';
	}
	echo '</div>';
}

function two_p_idac_admin_action() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Permissão insuficiente.', '', array( 'response' => 403 ) );
	}
	$action = isset( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : '';
	check_admin_referer( $action );
	if ( 'two_p_idac_apply' === $action ) {
		$keys = isset( $_POST['pages'] ) && is_array( $_POST['pages'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['pages'] ) ) : array();
		$result = two_p_idac_apply_pages( $keys, ! empty( $_POST['privacy_approved'] ) );
	} elseif ( 'two_p_idac_routing' === $action ) {
		$ids = isset( $_POST['redirects'] ) && is_array( $_POST['redirects'] ) ? array_map( 'sanitize_key', wp_unslash( $_POST['redirects'] ) ) : array();
		$result = two_p_idac_apply_routing( $ids, ! empty( $_POST['noindex_old_home'] ) );
	} else {
		$result = two_p_idac_rollback( isset( $_POST['batch'] ) ? sanitize_text_field( wp_unslash( $_POST['batch'] ) ) : '' );
	}
	set_transient( 'two_p_idac_notice_' . get_current_user_id(), is_wp_error( $result ) ? $result->get_error_message() : 'Operação concluída. Confira as páginas afetadas e limpe o cache.', 120 );
	wp_safe_redirect( admin_url( 'options-general.php?page=two-p-idac-internals' ) );
	exit;
}
add_action( 'admin_post_two_p_idac_apply', 'two_p_idac_admin_action' );
add_action( 'admin_post_two_p_idac_routing', 'two_p_idac_admin_action' );
add_action( 'admin_post_two_p_idac_rollback', 'two_p_idac_admin_action' );
