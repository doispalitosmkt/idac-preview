<?php
/**
 * Course waitlist integration.
 *
 * The public form posts to WordPress. WordPress then signs the server-to-server
 * request sent to a Google Apps Script Web App, keeping the shared secret out
 * of the browser. The CRM and commercial notification use the validated data.
 *
 * @package TwoPGrowthHomeIDAC
 */

defined( 'ABSPATH' ) || exit;

/**
 * Returns the approved courses exposed by the waitlist form.
 *
 * @return array<string, string>
 */
function two_p_growth_home_idac_waitlist_courses() {
	return array(
		'anatomia-topografica'           => 'Imersão em Anatomia Topográfica',
		'vias-de-acesso'                  => 'Vias de Acesso e Dissecção Cirúrgica',
		'mini-residencia-reconstrucoes'   => 'Mini-residência em Reconstruções Cirúrgicas',
		'full-face'                       => 'Full Face, Fios de Sustentação e Bioestimuladores',
		'medicina-regenerativa'           => 'Medicina Regenerativa',
		'suturas'                         => 'Suturas',
		'via-aerea'                      => 'Via Aérea',
		'radiofrequencia-nervo-periferico' => 'Radiofrequência de Nervo Periférico',
		'implantes-auditivos'             => 'Curso de Implantes Auditivos',
		'retalhos-membro-superior'         => 'Retalhos para Membro Superior',
		'trapezio-inferior'                => 'Transferência do Trapézio Inferior',
	);
}

/**
 * Returns the configured Google Apps Script Web App URL.
 */
function two_p_growth_home_idac_waitlist_webhook_url() {
	if ( defined( 'TWO_P_GROWTH_HOME_IDAC_WAITLIST_WEBHOOK_URL' ) ) {
		return trim( (string) TWO_P_GROWTH_HOME_IDAC_WAITLIST_WEBHOOK_URL );
	}

	$settings = two_p_growth_home_idac_get_settings();

	return isset( $settings['waitlist_webhook_url'] ) ? trim( (string) $settings['waitlist_webhook_url'] ) : '';
}

/**
 * Returns the shared webhook secret. It is never localized to the browser.
 */
function two_p_growth_home_idac_waitlist_webhook_secret() {
	if ( defined( 'TWO_P_GROWTH_HOME_IDAC_WAITLIST_WEBHOOK_SECRET' ) ) {
		return trim( (string) TWO_P_GROWTH_HOME_IDAC_WAITLIST_WEBHOOK_SECRET );
	}

	$settings = two_p_growth_home_idac_get_settings();

	return isset( $settings['waitlist_webhook_secret'] ) ? trim( (string) $settings['waitlist_webhook_secret'] ) : '';
}

/**
 * Checks whether the Sheets destination is configured.
 */
function two_p_growth_home_idac_waitlist_is_configured() {
	return '' !== two_p_growth_home_idac_waitlist_webhook_url() && '' !== two_p_growth_home_idac_waitlist_webhook_secret();
}

/**
 * Returns the public same-origin endpoint consumed by the waitlist modal.
 */
function two_p_growth_home_idac_internal_waitlist_endpoint() {
	return rest_url( 'two-p-growth-home-idac/v1/waitlist' );
}

/**
 * Registers the public waitlist endpoint.
 */
function two_p_growth_home_idac_register_waitlist_route() {
	register_rest_route(
		'two-p-growth-home-idac/v1',
		'/waitlist',
		array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => 'two_p_growth_home_idac_receive_waitlist',
			'permission_callback' => '__return_true',
		)
	);
}
add_action( 'rest_api_init', 'two_p_growth_home_idac_register_waitlist_route' );

/**
 * Applies a small per-IP limit before contacting Google Apps Script.
 *
 * @return true|WP_Error
 */
function two_p_growth_home_idac_check_waitlist_rate_limit() {
	$ip_candidates = array(
		isset( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ? wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) : '',
		isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '',
	);
	$ip            = '';

	foreach ( $ip_candidates as $candidate ) {
		if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
			$ip = $candidate;
			break;
		}
	}

	$key   = 'two_p_idac_waitlist_rate_' . hash( 'sha256', $ip ? $ip : 'unknown' );
	$count = (int) get_transient( $key );
	if ( $count >= 10 ) {
		return new WP_Error( 'waitlist_rate_limited', 'Muitas tentativas. Aguarde alguns minutos e tente novamente.', array( 'status' => 429 ) );
	}

	set_transient( $key, $count + 1, 10 * MINUTE_IN_SECONDS );

	return true;
}

/**
 * Validates that the webhook is the expected Google Apps Script endpoint.
 */
function two_p_growth_home_idac_waitlist_webhook_is_allowed( $url ) {
	$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
	$host   = wp_parse_url( $url, PHP_URL_HOST );
	$path   = wp_parse_url( $url, PHP_URL_PATH );

	return 'https' === strtolower( (string) $scheme )
		&& 'script.google.com' === strtolower( (string) $host )
		&& 0 === strpos( (string) $path, '/macros/s/' )
		&& '/exec' === substr( (string) $path, -5 );
}

/**
 * Checks the temporary ContentService URL returned by Google Apps Script.
 *
 * Apps Script responds to doPost() with a 302 redirect. WordPress can preserve
 * POST across that redirect, while the one-time googleusercontent URL expects
 * a GET request. Following it explicitly avoids a false delivery error after
 * the row has already been appended to the spreadsheet.
 */
function two_p_growth_home_idac_waitlist_redirect_is_allowed( $url ) {
	$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
	$host   = wp_parse_url( $url, PHP_URL_HOST );
	$path   = wp_parse_url( $url, PHP_URL_PATH );

	return 'https' === strtolower( (string) $scheme )
		&& 'script.googleusercontent.com' === strtolower( (string) $host )
		&& '/macros/echo' === (string) $path;
}

/**
 * Resolves the safe Apps Script ContentService redirect as a GET request.
 *
 * @param array<string, mixed>|WP_Error $response Initial webhook response.
 * @return array<string, mixed>|WP_Error
 */
function two_p_growth_home_idac_resolve_waitlist_response( $response ) {
	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$status = (int) wp_remote_retrieve_response_code( $response );
	if ( ! in_array( $status, array( 301, 302, 303 ), true ) ) {
		return $response;
	}

	$location = (string) wp_remote_retrieve_header( $response, 'location' );
	if ( ! $location || ! two_p_growth_home_idac_waitlist_redirect_is_allowed( $location ) ) {
		return new WP_Error( 'waitlist_invalid_redirect', 'O Google Apps Script retornou um redirecionamento inválido.' );
	}

	return wp_remote_get(
		$location,
		array(
			'timeout'     => 15,
			'redirection' => 2,
			'headers'     => array( 'Accept' => 'application/json' ),
		)
	);
}

/**
 * Validates a waitlist submission and delivers it to the configured destinations.
 *
 * @param WP_REST_Request $request REST request.
 * @return WP_REST_Response|WP_Error
 */
function two_p_growth_home_idac_receive_waitlist( $request ) {
	if ( ! two_p_growth_home_idac_is_same_origin_request( $request ) ) {
		return new WP_Error( 'waitlist_invalid_origin', 'Origem da solicitação inválida.', array( 'status' => 403 ) );
	}

	$body = $request->get_json_params();
	$body = is_array( $body ) ? $body : array();

	if ( ! empty( $body['website'] ) ) {
		return new WP_REST_Response( array( 'success' => true ), 200 );
	}

	$rate_limit = two_p_growth_home_idac_check_waitlist_rate_limit();
	if ( is_wp_error( $rate_limit ) ) {
		return $rate_limit;
	}

	$contact     = isset( $body['contact'] ) && is_array( $body['contact'] ) ? $body['contact'] : array();
	$attribution = isset( $body['attribution'] ) && is_array( $body['attribution'] ) ? $body['attribution'] : array();
	$consent     = isset( $body['consent'] ) && is_array( $body['consent'] ) ? $body['consent'] : array();
	$name        = isset( $contact['name'] ) ? sanitize_text_field( $contact['name'] ) : '';
	$email       = isset( $contact['email'] ) ? sanitize_email( $contact['email'] ) : '';
	$phone       = isset( $contact['personal_phone'] ) ? sanitize_text_field( $contact['personal_phone'] ) : '';
	$phone_digits = preg_replace( '/\D+/', '', $phone );
	$course_ids   = isset( $body['courses'] ) && is_array( $body['courses'] ) ? array_values( array_unique( array_map( 'sanitize_key', $body['courses'] ) ) ) : array();
	sort( $course_ids );
	$course_map   = two_p_growth_home_idac_waitlist_courses();
	$course_names = array();

	if ( strlen( $name ) < 2 || ! is_email( $email ) || strlen( $phone_digits ) < 8 ) {
		return new WP_Error( 'waitlist_invalid_contact', 'Revise nome, e-mail e WhatsApp.', array( 'status' => 422 ) );
	}

	if ( ! $course_ids || count( $course_ids ) > count( $course_map ) ) {
		return new WP_Error( 'waitlist_invalid_courses', 'Selecione pelo menos um curso válido.', array( 'status' => 422 ) );
	}

	foreach ( $course_ids as $course_id ) {
		if ( ! isset( $course_map[ $course_id ] ) ) {
			return new WP_Error( 'waitlist_invalid_course', 'Um dos cursos selecionados não é válido.', array( 'status' => 422 ) );
		}
		$course_names[] = $course_map[ $course_id ];
	}

	if ( empty( $consent['privacy'] ) ) {
		return new WP_Error( 'waitlist_privacy_required', 'É necessário aceitar o aviso de privacidade.', array( 'status' => 422 ) );
	}

	$dedupe_key = 'two_p_idac_waitlist_dedupe_' . hash( 'sha256', strtolower( $email ) . '|' . implode( ',', $course_ids ) );
	$lead = two_p_growth_home_idac_validate_lead_payload(
		array(
			'contact'               => array( 'name' => $name, 'email' => $email, 'personal_phone' => $phone ),
			'classification'        => array( 'interest' => 'cursos', 'cta_origin' => isset( $attribution['cta_origin'] ) ? $attribution['cta_origin'] : 'proxima-turma' ),
			'attribution'           => $attribution,
			'consent'               => $consent,
			'submission_identifier' => 'site-idac-proxima-turma',
		)
	);
	if ( is_wp_error( $lead ) ) {
		return $lead;
	}
	$lead['interest_label'] = implode( ' | ', $course_names );

	$send_sheet = null;
	if ( two_p_growth_home_idac_waitlist_is_configured() ) {
		$send_sheet = static function () use ( $lead, $course_ids, $course_names ) {
			return two_p_growth_home_idac_send_waitlist_to_sheet( $lead, $course_ids, $course_names );
		};
	}
	return two_p_growth_home_idac_deliver_registration( $dedupe_key, $lead, $send_sheet );
}

/** Delivers the same sanitized waitlist registration to the existing sheet. */
function two_p_growth_home_idac_send_waitlist_to_sheet( $lead, $course_ids, $course_names ) {
	$webhook_url = two_p_growth_home_idac_waitlist_webhook_url();
	if ( ! two_p_growth_home_idac_waitlist_webhook_is_allowed( $webhook_url ) ) {
		update_option( 'two_p_growth_home_idac_waitlist_last_error', array( 'message' => 'O conector da planilha está com uma URL inválida.', 'time' => current_time( 'mysql' ) ), false );
		return new WP_Error( 'waitlist_invalid_webhook', 'Não foi possível concluir o cadastro. Tente novamente em alguns instantes.', array( 'status' => 502 ) );
	}

	$payload = array(
		'secret'       => two_p_growth_home_idac_waitlist_webhook_secret(),
		'submitted_at' => current_time( 'c' ),
		'name'         => $lead['name'],
		'email'        => $lead['email'],
		'phone'        => $lead['phone'],
		'course_ids'   => $course_ids,
		'courses'      => $course_names,
		'cta_origin'   => $lead['cta_origin'],
		'page_url'     => $lead['attribution']['page_url'],
		'privacy'      => true,
	);

	$response = wp_remote_post(
		$webhook_url,
		array(
			'timeout'     => 15,
			'redirection' => 0,
			'headers'     => array(
				'Accept'       => 'application/json',
				'Content-Type' => 'application/json',
			),
			'body'        => wp_json_encode( $payload ),
		)
	);
	$response = two_p_growth_home_idac_resolve_waitlist_response( $response );

	if ( is_wp_error( $response ) ) {
		$error_message = 'Falha de conexão com a planilha.';
		update_option( 'two_p_growth_home_idac_waitlist_last_error', array( 'message' => $error_message, 'time' => current_time( 'mysql' ) ), false );
		return new WP_Error( 'waitlist_delivery_failed', 'Não foi possível registrar agora. Tente novamente.', array( 'status' => 502 ) );
	}

	$status = (int) wp_remote_retrieve_response_code( $response );
	$data   = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( $status < 200 || $status >= 300 || ! is_array( $data ) || empty( $data['success'] ) ) {
		$error_message = sprintf( 'O conector da planilha respondeu com HTTP %d.', $status );
		update_option( 'two_p_growth_home_idac_waitlist_last_error', array( 'message' => $error_message, 'time' => current_time( 'mysql' ) ), false );
		return new WP_Error( 'waitlist_delivery_rejected', 'Não foi possível registrar agora. Tente novamente.', array( 'status' => 502 ) );
	}

	delete_option( 'two_p_growth_home_idac_waitlist_last_error' );

	return true;
}
