<?php

defined( 'ABSPATH' ) || exit;

/** Default links for the shared header and its editable WordPress menu. */
function two_p_growth_home_idac_default_menu_items() {
	return array(
		'Cursos'             => '/#diferenciais',
		'Estrutura'          => '/#estrutura',
		'Quem somos'         => '/quem-somos/',
		'Histórico de cursos' => '/quem-somos/#formacoes',
		'Contato'            => '/contato/',
	);
}

/** Renders the shared menu until one is assigned to the plugin location. */
function two_p_growth_home_idac_menu_fallback() {
	echo '<ul class="menu two-p-growth-home-menu">';
	foreach ( two_p_growth_home_idac_default_menu_items() as $label => $path ) {
		printf( '<li class="menu-item"><a href="%1$s">%2$s</a></li>', esc_url( two_p_idac_internal_url( $path ) ), esc_html( $label ) );
	}
	echo '</ul>';
}

/** Resolves home anchors and keeps approved internal previews linked together. */
function two_p_growth_home_idac_primary_menu_links( $atts, $item, $args ) {
	if ( TWO_P_GROWTH_HOME_IDAC_MENU !== ( $args->theme_location ?? '' ) || empty( $atts['href'] ) || ! two_p_idac_internal_key() ) {
		return $atts;
	}

	$href = $atts['href'];
	if ( strlen( $href ) > 1 && '#' === $href[0] ) {
		$atts['href'] = home_url( '/' . $href );
		return $atts;
	}

	$home = home_url( '/' );
	if ( two_p_idac_preview_key() && 0 === strpos( $href, $home ) && false === strpos( $href, '?' ) ) {
		$atts['href'] = two_p_idac_internal_url( '/' . substr( $href, strlen( $home ) ) );
	}
	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'two_p_growth_home_idac_primary_menu_links', 10, 3 );

/** Creates and assigns a starter menu only when the plugin location is empty. */
function two_p_growth_home_idac_create_primary_menu() {
	$locations = get_nav_menu_locations();
	if ( ! empty( $locations[ TWO_P_GROWTH_HOME_IDAC_MENU ] ) ) {
		return (int) $locations[ TWO_P_GROWTH_HOME_IDAC_MENU ];
	}

	$menu_id = wp_create_nav_menu( 'Menu do site IDAC' );
	if ( is_wp_error( $menu_id ) ) {
		return $menu_id;
	}
	foreach ( two_p_growth_home_idac_default_menu_items() as $label => $path ) {
		$item_id = wp_update_nav_menu_item( $menu_id, 0, array(
			'menu-item-title'  => $label,
			'menu-item-type'   => 'custom',
			'menu-item-url'    => home_url( $path ),
			'menu-item-status' => 'publish',
		) );
		if ( is_wp_error( $item_id ) ) {
			wp_delete_nav_menu( $menu_id );
			return $item_id;
		}
	}

	$locations = get_nav_menu_locations();
	if ( ! empty( $locations[ TWO_P_GROWTH_HOME_IDAC_MENU ] ) ) {
		wp_delete_nav_menu( $menu_id );
		return (int) $locations[ TWO_P_GROWTH_HOME_IDAC_MENU ];
	}
	$locations[ TWO_P_GROWTH_HOME_IDAC_MENU ] = $menu_id;
	set_theme_mod( 'nav_menu_locations', $locations );
	if ( $menu_id !== (int) ( get_nav_menu_locations()[ TWO_P_GROWTH_HOME_IDAC_MENU ] ?? 0 ) ) {
		wp_delete_nav_menu( $menu_id );
		return new WP_Error( 'idac_menu_assignment_failed', 'Não foi possível vincular o menu do IDAC.' );
	}
	return $menu_id;
}

function two_p_growth_home_idac_handle_create_menu() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html( 'Você precisa de permissão para editar menus.' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'two_p_growth_home_idac_create_menu' );
	$menu_id = two_p_growth_home_idac_create_primary_menu();
	if ( is_wp_error( $menu_id ) ) {
		wp_die( esc_html( $menu_id->get_error_message() ), '', array( 'back_link' => true ) );
	}
	wp_safe_redirect( add_query_arg( 'menu', $menu_id, admin_url( 'nav-menus.php' ) ) );
	exit;
}
add_action( 'admin_post_two_p_growth_home_idac_create_menu', 'two_p_growth_home_idac_handle_create_menu' );
