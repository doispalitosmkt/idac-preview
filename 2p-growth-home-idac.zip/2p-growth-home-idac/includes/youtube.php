<?php

defined( 'ABSPATH' ) || exit;

/** Accept only YouTube channel or playlist links and discard tracking parameters. */
function two_p_growth_home_idac_youtube_url( $value, $kind ) {
	$parts = is_string( $value ) ? wp_parse_url( trim( $value ) ) : false;
	if ( ! is_array( $parts ) || 'https' !== strtolower( $parts['scheme'] ?? '' ) || isset( $parts['user'] ) || isset( $parts['pass'] ) || isset( $parts['port'] ) ) {
		return '';
	}

	$host = strtolower( $parts['host'] ?? '' );
	$path = rtrim( rawurldecode( $parts['path'] ?? '' ), '/' );
	if ( ! in_array( $host, array( 'www.youtube.com', 'youtube.com', 'm.youtube.com' ), true ) ) {
		return '';
	}
	if ( 'channel' === $kind ) {
		return preg_match( '~^/(?:@[\p{L}\p{N}_.-]+|(?:channel|c|user)/[A-Za-z0-9_.-]+)(?:/(?:featured|videos|playlists|shorts|streams|podcasts|about))?$~uD', $path )
			? 'https://www.youtube.com' . preg_replace( '~/(featured|videos|playlists|shorts|streams|podcasts|about)$~', '', $path )
			: '';
	}

	if ( ! in_array( $path, array( '/playlist', '/watch', '/embed/videoseries' ), true ) ) {
		return '';
	}
	parse_str( $parts['query'] ?? '', $query );
	$list = $query['list'] ?? '';
	return is_string( $list ) && preg_match( '/^[A-Za-z0-9_-]{10,100}$/D', $list )
		? 'https://www.youtube.com/playlist?list=' . $list
		: '';
}

/** Shows a podcast section when there is an official destination configured. */
function two_p_growth_home_idac_render_podcast() {
	$settings = two_p_growth_home_idac_get_settings();
	$channel  = two_p_growth_home_idac_youtube_url( $settings['youtube_channel_url'], 'channel' );
	$playlist = two_p_growth_home_idac_youtube_url( $settings['youtube_playlist_url'], 'playlist' );
	if ( ! $channel && ! $playlist ) {
		return;
	}
	?>
	<section class="section podcast" id="idacast" aria-labelledby="idacast-title">
		<div class="container podcast-grid<?php echo $playlist ? ' podcast-grid-with-player' : ''; ?>">
			<div class="section-heading">
				<p class="eyebrow">Podcast do Instituto DAC</p>
				<h2 id="idacast-title">IDACast</h2>
				<p>Acompanhe as conversas do Instituto DAC no YouTube.</p>
				<a class="text-link" href="<?php echo esc_url( $channel ?: $playlist ); ?>" target="_blank" rel="noopener noreferrer"><?php echo $channel ? 'Conferir o canal no YouTube' : 'Conferir a playlist no YouTube'; ?></a>
			</div>
			<?php if ( $playlist ) : ?>
				<div class="podcast-player">
					<?php $embed = 'https://www.youtube-nocookie.com/embed/videoseries?' . wp_parse_url( $playlist, PHP_URL_QUERY ); ?>
					<button class="button" type="button" data-idac-youtube-src="<?php echo esc_url( $embed ); ?>">Assistir à playlist do IDACast</button>
					<noscript><a class="button" href="<?php echo esc_url( $playlist ); ?>" target="_blank" rel="noopener noreferrer">Assistir à playlist no YouTube</a></noscript>
				</div>
			<?php endif; ?>
		</div>
	</section>
	<?php
}

/** Adds the official YouTube link to the shared footer. */
function two_p_growth_home_idac_render_youtube_icon() {
	$settings = two_p_growth_home_idac_get_settings();
	$url      = two_p_growth_home_idac_youtube_url( $settings['youtube_channel_url'], 'channel' )
		?: two_p_growth_home_idac_youtube_url( $settings['youtube_playlist_url'], 'playlist' );
	if ( ! $url ) {
		return;
	}
	?>
	<a href="<?php echo esc_url( $url ); ?>" aria-label="YouTube" target="_blank" rel="noopener noreferrer" data-external="youtube"><svg aria-hidden="true" viewBox="0 0 24 24" fill="currentColor"><path d="M21.6 6.8a2.8 2.8 0 0 0-2-2C17.8 4.3 12 4.3 12 4.3s-5.8 0-7.6.5a2.8 2.8 0 0 0-2 2C2 8.6 2 12 2 12s0 3.4.4 5.2a2.8 2.8 0 0 0 2 2c1.8.5 7.6.5 7.6.5s5.8 0 7.6-.5a2.8 2.8 0 0 0 2-2c.4-1.8.4-5.2.4-5.2s0-3.4-.4-5.2ZM10 15.4V8.6l5.8 3.4-5.8 3.4Z"/></svg></a>
	<?php
}
