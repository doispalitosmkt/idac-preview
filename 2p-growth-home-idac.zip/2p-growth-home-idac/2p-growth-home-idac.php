<?php
/**
 * Plugin Name: 2P Growth Home (IDAC)
 * Plugin URI: https://github.com/doispalitosmkt/idac
 * Description: Home e páginas internas do IDAC com templates próprios, prévia e migração reversível pelo painel.
 * Version: 0.3.4
 * Author: Dois Palitos Marketing Digital
 * Author URI: https://doispalitosmkt.com.br/
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Update URI: https://github.com/doispalitosmkt/idac
 * Text Domain: two-p-growth-home-idac
 */

defined( 'ABSPATH' ) || exit;

define( 'TWO_P_GROWTH_HOME_IDAC_VERSION', '0.3.4' );
define( 'TWO_P_GROWTH_HOME_IDAC_FILE', __FILE__ );
define( 'TWO_P_GROWTH_HOME_IDAC_DIR', plugin_dir_path( __FILE__ ) );
define( 'TWO_P_GROWTH_HOME_IDAC_URL', plugin_dir_url( __FILE__ ) );
define( 'TWO_P_GROWTH_HOME_IDAC_TEMPLATE', '2p-growth-home-idac.php' );
define( 'TWO_P_GROWTH_HOME_IDAC_SLUG', '2p-growth-home-idac' );
define( 'TWO_P_GROWTH_HOME_IDAC_MENU', 'two-p-growth-home-idac-primary' );
define( 'TWO_P_GROWTH_HOME_IDAC_UPDATE_MANIFEST', 'https://raw.githubusercontent.com/doispalitosmkt/idac-preview/wordpress-plugin/manifest.json' );

require_once TWO_P_GROWTH_HOME_IDAC_DIR . 'includes/rd-station.php';
require_once TWO_P_GROWTH_HOME_IDAC_DIR . 'includes/waitlist.php';
require_once TWO_P_GROWTH_HOME_IDAC_DIR . 'includes/internal-pages.php';
require_once TWO_P_GROWTH_HOME_IDAC_DIR . 'includes/youtube.php';
require_once TWO_P_GROWTH_HOME_IDAC_DIR . 'includes/primary-menu.php';

/**
 * Registers the page template and the menu location used by the landing page.
 */
function two_p_growth_home_idac_setup() {
	register_nav_menus(
		array(
			TWO_P_GROWTH_HOME_IDAC_MENU => '2P Growth Home (IDAC) — Menu principal',
		)
	);
}
add_action( 'after_setup_theme', 'two_p_growth_home_idac_setup' );

/**
 * Adds the plugin template to the Page Attributes template selector.
 *
 * @param array<string, string> $templates Available page templates.
 * @return array<string, string>
 */
function two_p_growth_home_idac_register_template( $templates ) {
	$templates[ TWO_P_GROWTH_HOME_IDAC_TEMPLATE ] = '2P Growth Home (IDAC)';

	return $templates;
}
add_filter( 'theme_page_templates', 'two_p_growth_home_idac_register_template' );

/**
 * Checks whether the current request uses this plugin's page template.
 */
function two_p_growth_home_idac_is_active_template() {
	if ( two_p_idac_preview_key() ) {
		return false;
	}
	if ( ! is_singular( 'page' ) ) {
		return false;
	}

	return TWO_P_GROWTH_HOME_IDAC_TEMPLATE === get_page_template_slug( get_queried_object_id() );
}

/**
 * Replaces the current theme template only for pages explicitly assigned to the plugin.
 *
 * @param string $template Template selected by WordPress.
 */
function two_p_growth_home_idac_template_include( $template ) {
	if ( ! two_p_growth_home_idac_is_active_template() ) {
		return $template;
	}

	$plugin_template = TWO_P_GROWTH_HOME_IDAC_DIR . 'templates/home.php';

	return is_readable( $plugin_template ) ? $plugin_template : $template;
}
add_filter( 'template_include', 'two_p_growth_home_idac_template_include', 99 );

/**
 * Returns a versioned URL for a packaged plugin asset.
 *
 * @param string $path Path relative to the plugin assets directory.
 */
function two_p_growth_home_idac_asset_url( $path ) {
	return TWO_P_GROWTH_HOME_IDAC_URL . 'assets/' . ltrim( $path, '/' );
}

/**
 * Keeps large videos outside the plugin ZIP. URLs can be replaced by a CDN,
 * WordPress Media Library URLs or a hosting-specific integration through the filter.
 *
 * @param string $filename Original video filename.
 */
function two_p_growth_home_idac_video_url( $filename ) {
	$base_url = 'https://doispalitosmkt.github.io/idac-preview/assets/videos/';
	$defaults = array(
		'institucional-idac.mp4' => $base_url . 'institucional-idac.mp4',
		'depoimento-1.mp4'       => $base_url . 'depoimento-1.mp4',
		'depoimento-2.mp4'       => $base_url . 'depoimento-2.mp4',
		'depoimento-3.mp4'       => $base_url . 'depoimento-3.mp4',
	);
	$settings        = two_p_growth_home_idac_get_settings();
	$configured_urls = is_array( $settings['video_urls'] ) ? $settings['video_urls'] : array();
	$urls            = $defaults;

	foreach ( $configured_urls as $configured_filename => $configured_url ) {
		if ( $configured_url ) {
			$urls[ $configured_filename ] = $configured_url;
		}
	}

	/**
	 * Filters the external video URLs used by the IDAC home page.
	 *
	 * @param array<string, string> $urls Video URLs keyed by their original filename.
	 */
	$urls = apply_filters( 'two_p_growth_home_idac_video_urls', $urls );

	return isset( $urls[ $filename ] ) ? $urls[ $filename ] : '';
}

/**
 * Uses the WordPress privacy policy page when configured.
 */
function two_p_growth_home_idac_privacy_url() {
	$url = get_privacy_policy_url();

	return $url ? $url : home_url( '/politica-de-privacidade/' );
}

/**
 * Loads the landing assets only on pages assigned to this template.
 */
function two_p_growth_home_idac_enqueue_assets() {
	if ( ! two_p_growth_home_idac_is_active_template() && ! two_p_idac_internal_key() ) {
		return;
	}

	wp_enqueue_style(
		'two-p-growth-home-idac',
		two_p_growth_home_idac_asset_url( 'css/home.css' ),
		array(),
		TWO_P_GROWTH_HOME_IDAC_VERSION
	);

	wp_enqueue_script(
		'two-p-growth-home-idac',
		two_p_growth_home_idac_asset_url( 'js/home.js' ),
		array(),
		TWO_P_GROWTH_HOME_IDAC_VERSION,
		true
	);
	if ( two_p_idac_internal_key() ) {
		wp_enqueue_style( 'two-p-idac-internals', two_p_growth_home_idac_asset_url( 'css/internal.css' ), array( 'two-p-growth-home-idac' ), TWO_P_GROWTH_HOME_IDAC_VERSION );
		wp_enqueue_script( 'two-p-idac-internals', two_p_growth_home_idac_asset_url( 'js/internal.js' ), array( 'two-p-growth-home-idac' ), TWO_P_GROWTH_HOME_IDAC_VERSION, true );
	}

	$settings = two_p_growth_home_idac_get_settings();
	$endpoint = defined( 'TWO_P_GROWTH_HOME_IDAC_RD_ENDPOINT' )
		? TWO_P_GROWTH_HOME_IDAC_RD_ENDPOINT
		: $settings['lead_endpoint'];

	if ( ! $endpoint && two_p_growth_home_idac_rd_is_configured() ) {
		$endpoint = two_p_growth_home_idac_internal_lead_endpoint();
	}

	$waitlist_endpoint = ( two_p_growth_home_idac_rd_is_configured() || two_p_growth_home_idac_waitlist_is_configured() )
		? two_p_growth_home_idac_internal_waitlist_endpoint()
		: '';
	if ( two_p_idac_preview_key() ) {
		$endpoint = '';
		$waitlist_endpoint = '';
	}

	wp_localize_script(
		'two-p-growth-home-idac',
		'twoPGrowthHomeConfig',
		array(
			'leadEndpoint' => esc_url_raw(
				apply_filters( 'two_p_growth_home_idac_lead_endpoint', $endpoint )
			),
			'waitlistEndpoint' => esc_url_raw( $waitlist_endpoint ),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'two_p_growth_home_idac_enqueue_assets', 20 );

/**
 * Removes page-builder assets from this standalone template only.
 *
 * Elementor and the active theme remain untouched on every other WordPress page.
 */
function two_p_growth_home_idac_remove_builder_assets() {
	if ( ! two_p_growth_home_idac_is_active_template() && ! two_p_idac_internal_key() ) {
		return;
	}

	$blocked_sources = array(
		'/themes/hello-elementor/',
		'/plugins/elementor/',
		'/plugins/elementor-pro/',
		'/plugins/elementskit-lite/',
		'/plugins/rometheme-for-elementor/',
		'/uploads/elementor/',
	);
	$allowed_handles = array(
		'rtmkit-system-panel-css',
		'rtmkit-system-panel-js',
	);

	global $wp_styles, $wp_scripts;

	if ( $wp_styles instanceof WP_Styles ) {
		foreach ( $wp_styles->queue as $handle ) {
			if ( in_array( $handle, $allowed_handles, true ) ) {
				continue;
			}

			$source = isset( $wp_styles->registered[ $handle ] ) ? $wp_styles->registered[ $handle ]->src : '';
			foreach ( $blocked_sources as $blocked_source ) {
				if ( $source && false !== strpos( $source, $blocked_source ) ) {
					wp_dequeue_style( $handle );
					break;
				}
			}
		}
	}

	if ( $wp_scripts instanceof WP_Scripts ) {
		foreach ( $wp_scripts->queue as $handle ) {
			if ( in_array( $handle, $allowed_handles, true ) ) {
				continue;
			}

			$source = isset( $wp_scripts->registered[ $handle ] ) ? $wp_scripts->registered[ $handle ]->src : '';
			foreach ( $blocked_sources as $blocked_source ) {
				if ( $source && false !== strpos( $source, $blocked_source ) ) {
					wp_dequeue_script( $handle );
					break;
				}
			}
		}
	}
}
add_action( 'wp_enqueue_scripts', 'two_p_growth_home_idac_remove_builder_assets', PHP_INT_MAX );
add_action( 'wp_print_styles', 'two_p_growth_home_idac_remove_builder_assets', PHP_INT_MAX );
add_action( 'wp_print_footer_scripts', 'two_p_growth_home_idac_remove_builder_assets', 0 );

/**
 * Keeps the global Click to Chat widget on the approved IDAC number.
 *
 * This override is scoped to the standalone home. Other WordPress pages keep
 * the number configured directly in the Click to Chat plugin.
 *
 * @param array<string, mixed> $settings Click to Chat frontend settings.
 * @return array<string, mixed>
 */
function two_p_growth_home_idac_whatsapp_chat_settings( $settings ) {
	if ( ! two_p_growth_home_idac_is_active_template() || ! is_array( $settings ) ) {
		return $settings;
	}

	$settings['number'] = '5511914688835';

	return $settings;
}
add_filter( 'ht_ctc_fh_chat', 'two_p_growth_home_idac_whatsapp_chat_settings', PHP_INT_MAX );

/**
 * Returns the plugin settings with a predictable structure.
 *
 * @return array<string, mixed>
 */
function two_p_growth_home_idac_get_settings() {
	$settings = get_option( 'two_p_growth_home_idac_settings', array() );
	$settings = is_array( $settings ) ? $settings : array();

	return wp_parse_args(
		$settings,
		array(
			'lead_endpoint'          => '',
			'rd_token'               => '',
			'rd_owner'               => array(),
			'waitlist_webhook_url'   => '',
			'waitlist_webhook_secret' => '',
			'video_urls'             => array(),
			'youtube_channel_url'    => 'https://www.youtube.com/@InstitutoDAC',
			'youtube_playlist_url'   => 'https://www.youtube.com/playlist?list=PLC1Wb89WT-KI',
		)
	);
}

/**
 * Sanitizes settings edited through the WordPress dashboard.
 *
 * @param mixed $input Submitted settings.
 * @return array<string, mixed>
 */
function two_p_growth_home_idac_sanitize_settings( $input ) {
	$input      = is_array( $input ) ? $input : array();
	$current    = two_p_growth_home_idac_get_settings();
	$video_urls = isset( $input['video_urls'] ) && is_array( $input['video_urls'] )
		? $input['video_urls']
		: array();
	$sanitized  = array();
	$token      = isset( $current['rd_token'] ) ? $current['rd_token'] : '';
	$waitlist_secret = isset( $current['waitlist_webhook_secret'] ) ? $current['waitlist_webhook_secret'] : '';

	if ( ! empty( $input['clear_rd_token'] ) ) {
		$token = '';
	} elseif ( ! empty( $input['rd_token'] ) ) {
		$token = preg_replace( '/\s+/', '', sanitize_text_field( wp_unslash( $input['rd_token'] ) ) );
	}

	if ( ! empty( $input['clear_waitlist_webhook_secret'] ) ) {
		$waitlist_secret = '';
	} elseif ( ! empty( $input['waitlist_webhook_secret'] ) ) {
		$waitlist_secret = preg_replace( '/\s+/', '', sanitize_text_field( wp_unslash( $input['waitlist_webhook_secret'] ) ) );
	}

	foreach ( array( 'institucional-idac.mp4', 'depoimento-1.mp4', 'depoimento-2.mp4', 'depoimento-3.mp4' ) as $filename ) {
		$sanitized[ $filename ] = isset( $video_urls[ $filename ] )
			? esc_url_raw( wp_unslash( $video_urls[ $filename ] ) )
			: '';
	}
	$youtube = array();
	foreach ( array( 'youtube_channel_url' => 'channel', 'youtube_playlist_url' => 'playlist' ) as $field => $kind ) {
		$youtube[ $field ] = $current[ $field ];
		if ( ! isset( $input[ $field ] ) || ! is_string( $input[ $field ] ) ) {
			continue;
		}
		$value = trim( wp_unslash( $input[ $field ] ) );
		$url = two_p_growth_home_idac_youtube_url( $value, $kind );
		if ( $value && ! $url ) {
			$message = 'channel' === $kind ? 'Informe uma URL válida do canal do YouTube.' : 'Informe uma URL válida da playlist do YouTube.';
			add_settings_error( 'two_p_growth_home_idac_settings', $field, $message );
			continue;
		}
		$youtube[ $field ] = $url;
	}

	return array(
		'lead_endpoint'           => isset( $input['lead_endpoint'] ) ? esc_url_raw( wp_unslash( $input['lead_endpoint'] ) ) : '',
		'rd_token'                => $token,
		'rd_owner'                => two_p_growth_home_idac_rd_sanitize_owner( $input, $current, $token ),
		'waitlist_webhook_url'    => isset( $input['waitlist_webhook_url'] ) ? esc_url_raw( wp_unslash( $input['waitlist_webhook_url'] ) ) : '',
		'waitlist_webhook_secret' => $waitlist_secret,
		'video_urls'              => $sanitized,
	) + $youtube;
}

/**
 * Registers the settings used by the standalone home template.
 */
function two_p_growth_home_idac_register_settings() {
	register_setting(
		'two_p_growth_home_idac',
		'two_p_growth_home_idac_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'two_p_growth_home_idac_sanitize_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'two_p_growth_home_idac_register_settings' );

/**
 * Adds a small configuration screen so deployment does not require server access.
 */
function two_p_growth_home_idac_add_settings_page() {
	add_options_page(
		'2P Growth Home (IDAC)',
		'2P Growth Home (IDAC)',
		'manage_options',
		'two-p-growth-home-idac',
		'two_p_growth_home_idac_render_settings_page'
	);
}
add_action( 'admin_menu', 'two_p_growth_home_idac_add_settings_page' );

/**
 * Renders the plugin settings page.
 */
function two_p_growth_home_idac_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$settings         = two_p_growth_home_idac_get_settings();
	$token_configured = two_p_growth_home_idac_rd_is_configured();
	$waitlist_configured = two_p_growth_home_idac_waitlist_is_configured();
	$waitlist_secret_configured = '' !== two_p_growth_home_idac_waitlist_webhook_secret();
	$rd_schema        = two_p_growth_home_idac_get_rd_schema();
	$rd_users         = two_p_growth_home_idac_rd_cached_users( two_p_growth_home_idac_rd_token() );
	$rd_owner         = isset( $settings['rd_owner'] ) && is_array( $settings['rd_owner'] ) ? $settings['rd_owner'] : array();
	$rd_owner_id      = isset( $rd_owner['id'] ) ? $rd_owner['id'] : '';
	if ( $rd_owner_id && ! isset( $rd_users[ $rd_owner_id ] ) ) {
		$rd_users[ $rd_owner_id ] = $rd_owner;
	}
	$last_rd_error    = get_option( 'two_p_growth_home_idac_rd_last_error', array() );
	$last_mail_error  = get_option( 'two_p_growth_home_idac_mail_last_error', '' );
	$last_waitlist_error = get_option( 'two_p_growth_home_idac_waitlist_last_error', array() );
	$video_names      = array(
		'institucional-idac.mp4' => 'Vídeo institucional',
		'depoimento-1.mp4'       => 'Depoimento 1',
		'depoimento-2.mp4'       => 'Depoimento 2',
		'depoimento-3.mp4'       => 'Depoimento 3',
	);
	?>
	<div class="wrap">
		<h1>2P Growth Home (IDAC)</h1>
		<p>Conecte o formulário principal ao RD Station CRM, a lista de próximas turmas ao Google Sheets e, quando necessário, substitua os vídeos externos sem editar arquivos do servidor.</p>
		<?php if ( current_user_can( 'edit_theme_options' ) ) : ?>
			<h2>Menu principal do site</h2>
			<p>A home e as páginas internas do plugin usam o menu vinculado ao local “2P Growth Home (IDAC) — Menu principal”.</p>
			<?php $menu_id = (int) ( get_nav_menu_locations()[ TWO_P_GROWTH_HOME_IDAC_MENU ] ?? 0 ); ?>
			<?php if ( $menu_id ) : ?>
				<p><a class="button" href="<?php echo esc_url( add_query_arg( 'menu', $menu_id, admin_url( 'nav-menus.php' ) ) ); ?>">Editar menu do IDAC</a></p>
			<?php else : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="two_p_growth_home_idac_create_menu" />
					<?php wp_nonce_field( 'two_p_growth_home_idac_create_menu' ); ?>
					<?php submit_button( 'Criar e vincular menu do IDAC', 'secondary', 'submit', false ); ?>
					<a href="<?php echo esc_url( admin_url( 'nav-menus.php?action=locations' ) ); ?>">Vincular um menu existente</a>
				</form>
			<?php endif; ?>
			<hr />
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'two_p_growth_home_idac' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="two-p-growth-home-idac-rd-token">Token de integração do RD Station CRM</label></th>
					<td>
						<input class="regular-text code" id="two-p-growth-home-idac-rd-token" name="two_p_growth_home_idac_settings[rd_token]" type="password" value="" autocomplete="new-password" placeholder="<?php echo esc_attr( $token_configured ? 'Token configurado — deixe vazio para manter' : 'Cole o token aqui' ); ?>" />
						<p class="description">
							<?php echo esc_html( $token_configured ? 'Token salvo no WordPress. O valor nunca é enviado ao navegador.' : 'O token será armazenado no WordPress e usado somente pelo servidor.' ); ?>
						</p>
						<?php if ( $token_configured && ! defined( 'TWO_P_GROWTH_HOME_IDAC_RD_TOKEN' ) ) : ?>
							<label><input type="checkbox" name="two_p_growth_home_idac_settings[clear_rd_token]" value="1" /> Remover o token salvo</label>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="two-p-growth-home-idac-rd-owner">Responsável pelos novos leads</label></th>
					<td>
						<select id="two-p-growth-home-idac-rd-owner" name="two_p_growth_home_idac_settings[rd_owner_id]">
							<option value="">Padrão do RD — dono do token</option>
							<?php foreach ( $rd_users as $rd_user ) : ?>
								<option value="<?php echo esc_attr( $rd_user['id'] ); ?>" <?php selected( $rd_owner_id, $rd_user['id'] ); ?>><?php echo esc_html( $rd_user['name'] . ( ! empty( $rd_user['email'] ) ? ' — ' . $rd_user['email'] : '' ) ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">Use “Carregar usuários do RD” abaixo para buscar a lista. Selecione a pessoa e salve. A escolha vale para os próximos envios; negociações existentes mantêm o responsável atual.</p>
						<?php $rd_owner_status = two_p_growth_home_idac_rd_owner_id(); ?>
						<?php if ( is_wp_error( $rd_owner_status ) ) : ?>
							<p class="notice notice-error inline"><?php echo esc_html( $rd_owner_status->get_error_message() ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="two-p-growth-home-idac-endpoint">Endpoint externo opcional</label></th>
					<td>
						<input class="regular-text code" id="two-p-growth-home-idac-endpoint" name="two_p_growth_home_idac_settings[lead_endpoint]" type="url" value="<?php echo esc_attr( $settings['lead_endpoint'] ); ?>" placeholder="https://..." />
						<p class="description">Deixe vazio para usar a integração interna do plugin. Preencha apenas se houver um endpoint intermediário próprio.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="two-p-growth-home-idac-waitlist-url">Google Sheets — URL do Web App</label></th>
					<td>
						<input class="large-text code" id="two-p-growth-home-idac-waitlist-url" name="two_p_growth_home_idac_settings[waitlist_webhook_url]" type="url" value="<?php echo esc_attr( $settings['waitlist_webhook_url'] ); ?>" placeholder="https://script.google.com/macros/s/.../exec" />
						<p class="description">URL <code>/exec</code> do Apps Script para manter o registro da lista de próximas turmas na planilha, além do RD Station e do e-mail comercial.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="two-p-growth-home-idac-waitlist-secret">Google Sheets — segredo compartilhado</label></th>
					<td>
						<input class="regular-text code" id="two-p-growth-home-idac-waitlist-secret" name="two_p_growth_home_idac_settings[waitlist_webhook_secret]" type="password" value="" autocomplete="new-password" placeholder="<?php echo esc_attr( $waitlist_secret_configured ? 'Segredo configurado — deixe vazio para manter' : 'Cole um segredo longo e aleatório' ); ?>" />
						<p class="description"><?php echo esc_html( $waitlist_configured ? 'Lista de próximas turmas conectada. URL e segredo são usados somente pelo servidor.' : 'Use exatamente o mesmo valor na propriedade IDAC_WAITLIST_SECRET do Apps Script.' ); ?></p>
						<?php if ( $waitlist_secret_configured && ! defined( 'TWO_P_GROWTH_HOME_IDAC_WAITLIST_WEBHOOK_SECRET' ) ) : ?>
							<label><input type="checkbox" name="two_p_growth_home_idac_settings[clear_waitlist_webhook_secret]" value="1" /> Remover o segredo salvo</label>
						<?php endif; ?>
						<?php if ( is_array( $last_waitlist_error ) && ! empty( $last_waitlist_error['message'] ) ) : ?>
							<div class="notice notice-warning inline">
								<p><strong>Última falha da lista de turmas:</strong> <?php echo esc_html( $last_waitlist_error['message'] ); ?><?php echo ! empty( $last_waitlist_error['time'] ) ? ' — ' . esc_html( $last_waitlist_error['time'] ) : ''; ?></p>
							</div>
						<?php endif; ?>
					</td>
				</tr>
				<?php foreach ( $video_names as $filename => $label ) : ?>
					<tr>
						<th scope="row"><label for="two-p-growth-home-idac-<?php echo esc_attr( sanitize_title( $filename ) ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<input class="large-text code" id="two-p-growth-home-idac-<?php echo esc_attr( sanitize_title( $filename ) ); ?>" name="two_p_growth_home_idac_settings[video_urls][<?php echo esc_attr( $filename ); ?>]" type="url" value="<?php echo esc_attr( isset( $settings['video_urls'][ $filename ] ) ? $settings['video_urls'][ $filename ] : '' ); ?>" placeholder="URL externa opcional" />
						</td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<th scope="row"><label for="idac-youtube-channel">Canal do IDAC no YouTube</label></th>
					<td><input class="large-text code" id="idac-youtube-channel" name="two_p_growth_home_idac_settings[youtube_channel_url]" type="url" value="<?php echo esc_attr( $settings['youtube_channel_url'] ); ?>" />
						<p class="description">Use o endereço oficial do canal para o rodapé e o botão do IDACast.</p></td>
				</tr>
				<tr>
					<th scope="row"><label for="idac-youtube-playlist">Playlist do IDACast</label></th>
					<td><input class="large-text code" id="idac-youtube-playlist" name="two_p_growth_home_idac_settings[youtube_playlist_url]" type="url" value="<?php echo esc_attr( $settings['youtube_playlist_url'] ); ?>" />
						<p class="description">Cole o endereço público da playlist. Novos episódios aparecem conforme a playlist for atualizada no YouTube.</p></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php if ( $token_configured ) : ?>
			<hr />
			<h2>Diagnóstico do RD Station CRM</h2>
			<p>Teste o token salvo sem criar contatos ou negociações.</p>
			<p>O formulário de contato e a lista de próximas turmas enviam uma cópia a comercial@institutodac.com pelo serviço de e-mail do WordPress.</p>
			<?php if ( $last_mail_error ) : ?>
				<div class="notice notice-warning inline"><p>O WordPress registrou uma falha ao enviar para o e-mail comercial em <?php echo esc_html( $last_mail_error ); ?>. Confira o serviço de e-mail do site.</p></div>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="two_p_growth_home_idac_load_rd_users" />
				<?php wp_nonce_field( 'two_p_growth_home_idac_load_rd_users' ); ?>
				<?php submit_button( 'Carregar usuários do RD', 'secondary', 'submit', false ); ?>
			</form>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="two_p_growth_home_idac_test_rd" />
				<?php wp_nonce_field( 'two_p_growth_home_idac_test_rd' ); ?>
				<?php submit_button( 'Testar conexão com o RD Station', 'secondary', 'submit', false ); ?>
			</form>
			<p class="description">Depois de salvar ou alterar o token, limpe o cache do LiteSpeed para que a página passe a usar o endpoint interno.</p>
			<h2>Mapeamento dos dados no CRM</h2>
			<?php if ( $rd_schema ) : ?>
				<p><strong>Status:</strong> preparado<?php echo ! empty( $rd_schema['prepared_at'] ) ? ' em ' . esc_html( $rd_schema['prepared_at'] ) : ''; ?>.</p>
				<p class="description">Os próximos leads serão classificados nos campos da negociação e receberão a fonte “Site IDAC”. Executar novamente é seguro: os mesmos campos serão reaproveitados.</p>
			<?php else : ?>
				<p><strong>Status:</strong> preparação pendente.</p>
				<p class="description">Cria ou reaproveita quatro campos de negociação e a fonte “Site IDAC”. Esta ação não cria contatos ou negociações e só altera o CRM quando o botão é clicado.</p>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="two_p_growth_home_idac_prepare_rd_schema" />
				<?php wp_nonce_field( 'two_p_growth_home_idac_prepare_rd_schema' ); ?>
				<?php submit_button( $rd_schema ? 'Revalidar campos no RD Station' : 'Preparar campos no RD Station', 'primary', 'submit', false ); ?>
			</form>
			<?php if ( is_array( $last_rd_error ) && ! empty( $last_rd_error['message'] ) ) : ?>
				<div class="notice notice-warning inline">
					<p><strong>Última falha de entrega:</strong> <?php echo esc_html( $last_rd_error['message'] ); ?><?php echo ! empty( $last_rd_error['time'] ) ? ' — ' . esc_html( $last_rd_error['time'] ) : ''; ?></p>
				</div>
			<?php endif; ?>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Preserves the approved SEO title when the plugin template is active.
 *
 * @param string $title Current document title.
 */
function two_p_growth_home_idac_document_title( $title ) {
	if ( two_p_growth_home_idac_is_active_template() ) {
		return 'Cadaverlab | Treinamento em cadáveres Fresh Frozen | Instituto DAC';
	}

	return $title;
}
add_filter( 'pre_get_document_title', 'two_p_growth_home_idac_document_title' );

/**
 * Shows concise activation instructions until a page uses the template.
 */
function two_p_growth_home_idac_admin_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$assigned_pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => 1,
			'meta_key'       => '_wp_page_template',
			'meta_value'     => TWO_P_GROWTH_HOME_IDAC_TEMPLATE,
			'fields'         => 'ids',
		)
	);

	if ( $assigned_pages ) {
		return;
	}

	printf(
		'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a href="%3$s">%4$s</a></p></div>',
		esc_html( '2P Growth Home (IDAC):' ),
		esc_html( 'crie ou edite uma página e selecione o template “2P Growth Home (IDAC)” em Atributos da página.' ),
		esc_url( admin_url( 'post-new.php?post_type=page' ) ),
		esc_html( 'Criar página' )
	);
}
add_action( 'admin_notices', 'two_p_growth_home_idac_admin_notice' );

/**
 * Reads the public update manifest produced by the private source repository.
 * No GitHub credential is stored in WordPress.
 *
 * @return array<string, mixed>|false
 */
function two_p_growth_home_idac_get_update_manifest() {
	$cache_key = 'two_p_growth_home_idac_update_manifest';
	$cached    = get_site_transient( $cache_key );

	if ( is_array( $cached ) ) {
		return $cached;
	}

	$response = wp_remote_get(
		TWO_P_GROWTH_HOME_IDAC_UPDATE_MANIFEST,
		array(
			'timeout'    => 6,
			'user-agent' => '2P Growth Home (IDAC)/' . TWO_P_GROWTH_HOME_IDAC_VERSION,
		)
	);

	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		return false;
	}

	$manifest = json_decode( wp_remote_retrieve_body( $response ), true );
	if (
		! is_array( $manifest ) ||
		empty( $manifest['version'] ) ||
		empty( $manifest['download_url'] )
	) {
		return false;
	}

	set_site_transient( $cache_key, $manifest, 6 * HOUR_IN_SECONDS );

	return $manifest;
}

/**
 * Adds releases from the public distribution channel to WordPress Updates.
 *
 * @param mixed $transient WordPress update transient.
 * @return mixed
 */
function two_p_growth_home_idac_check_for_update( $transient ) {
	if ( ! is_object( $transient ) ) {
		return $transient;
	}

	$manifest = two_p_growth_home_idac_get_update_manifest();
	if ( ! $manifest || version_compare( TWO_P_GROWTH_HOME_IDAC_VERSION, $manifest['version'], '>=' ) ) {
		return $transient;
	}

	$plugin_file = plugin_basename( TWO_P_GROWTH_HOME_IDAC_FILE );
	$update      = (object) array(
		'id'           => TWO_P_GROWTH_HOME_IDAC_UPDATE_MANIFEST,
		'slug'         => TWO_P_GROWTH_HOME_IDAC_SLUG,
		'plugin'       => $plugin_file,
		'new_version'  => sanitize_text_field( $manifest['version'] ),
		'url'          => esc_url_raw( isset( $manifest['homepage'] ) ? $manifest['homepage'] : '' ),
		'package'      => esc_url_raw( $manifest['download_url'] ),
		'requires'     => sanitize_text_field( isset( $manifest['requires'] ) ? $manifest['requires'] : '6.2' ),
		'requires_php' => sanitize_text_field( isset( $manifest['requires_php'] ) ? $manifest['requires_php'] : '7.4' ),
	);

	$transient->response[ $plugin_file ] = $update;

	return $transient;
}
add_filter( 'site_transient_update_plugins', 'two_p_growth_home_idac_check_for_update' );

/**
 * Supplies the plugin details modal shown by the WordPress update screen.
 *
 * @param mixed  $result Existing API result.
 * @param string $action Requested API action.
 * @param object $args   Request arguments.
 * @return mixed
 */
function two_p_growth_home_idac_plugin_information( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || TWO_P_GROWTH_HOME_IDAC_SLUG !== $args->slug ) {
		return $result;
	}

	$manifest = two_p_growth_home_idac_get_update_manifest();
	if ( ! $manifest ) {
		return $result;
	}

	return (object) array(
		'name'          => '2P Growth Home (IDAC)',
		'slug'          => TWO_P_GROWTH_HOME_IDAC_SLUG,
		'version'       => sanitize_text_field( $manifest['version'] ),
		'author'        => '<a href="https://doispalitosmkt.com.br/">Dois Palitos Marketing Digital</a>',
		'homepage'      => esc_url_raw( isset( $manifest['homepage'] ) ? $manifest['homepage'] : '' ),
		'requires'      => sanitize_text_field( isset( $manifest['requires'] ) ? $manifest['requires'] : '6.2' ),
		'requires_php'  => sanitize_text_field( isset( $manifest['requires_php'] ) ? $manifest['requires_php'] : '7.4' ),
		'download_link' => esc_url_raw( $manifest['download_url'] ),
		'sections'      => array(
			'description' => wp_kses_post( isset( $manifest['description'] ) ? $manifest['description'] : '' ),
			'changelog'   => wp_kses_post( isset( $manifest['changelog'] ) ? $manifest['changelog'] : '' ),
		),
	);
}
add_filter( 'plugins_api', 'two_p_growth_home_idac_plugin_information', 10, 3 );

/**
 * Forces a fresh manifest check after activation.
 */
function two_p_growth_home_idac_clear_update_cache() {
	delete_site_transient( 'two_p_growth_home_idac_update_manifest' );
}
register_activation_hook( TWO_P_GROWTH_HOME_IDAC_FILE, 'two_p_growth_home_idac_clear_update_cache' );

