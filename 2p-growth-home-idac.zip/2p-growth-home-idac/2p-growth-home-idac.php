<?php
/**
 * Plugin Name: 2P Growth Home (IDAC)
 * Plugin URI: https://github.com/doispalitosmkt/idac
 * Description: Disponibiliza a nova página inicial institucional do IDAC como um template independente do Elementor.
 * Version: 0.1.1
 * Author: Dois Palitos Marketing Digital
 * Author URI: https://doispalitosmkt.com.br/
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Update URI: https://github.com/doispalitosmkt/idac
 * Text Domain: two-p-growth-home-idac
 */

defined( 'ABSPATH' ) || exit;

define( 'TWO_P_GROWTH_HOME_IDAC_VERSION', '0.1.1' );
define( 'TWO_P_GROWTH_HOME_IDAC_FILE', __FILE__ );
define( 'TWO_P_GROWTH_HOME_IDAC_DIR', plugin_dir_path( __FILE__ ) );
define( 'TWO_P_GROWTH_HOME_IDAC_URL', plugin_dir_url( __FILE__ ) );
define( 'TWO_P_GROWTH_HOME_IDAC_TEMPLATE', '2p-growth-home-idac.php' );
define( 'TWO_P_GROWTH_HOME_IDAC_SLUG', '2p-growth-home-idac' );
define( 'TWO_P_GROWTH_HOME_IDAC_UPDATE_MANIFEST', 'https://raw.githubusercontent.com/doispalitosmkt/idac-preview/wordpress-plugin/manifest.json' );

/**
 * Registers the page template and the menu location used by the landing page.
 */
function two_p_growth_home_idac_setup() {
	register_nav_menus(
		array(
			'two-p-growth-home-idac-primary' => '2P Growth Home (IDAC) — Menu principal',
		)
	);
}
add_action( 'after_setup_theme', 'two_p_growth_home_idac_setup' );

/**
 * Adds the plugin template to the Page Attributes template selector.
 *
 * @param array<string, string> $templates Available page templates.
 * @return array<string, string>
 */
function two_p_growth_home_idac_register_template( $templates ) {
	$templates[ TWO_P_GROWTH_HOME_IDAC_TEMPLATE ] = '2P Growth Home (IDAC)';

	return $templates;
}
add_filter( 'theme_page_templates', 'two_p_growth_home_idac_register_template' );

/**
 * Checks whether the current request uses this plugin's page template.
 */
function two_p_growth_home_idac_is_active_template() {
	if ( ! is_singular( 'page' ) ) {
		return false;
	}

	return TWO_P_GROWTH_HOME_IDAC_TEMPLATE === get_page_template_slug( get_queried_object_id() );
}

/**
 * Replaces the current theme template only for pages explicitly assigned to the plugin.
 *
 * @param string $template Template selected by WordPress.
 */
function two_p_growth_home_idac_template_include( $template ) {
	if ( ! two_p_growth_home_idac_is_active_template() ) {
		return $template;
	}

	$plugin_template = TWO_P_GROWTH_HOME_IDAC_DIR . 'templates/home.php';

	return is_readable( $plugin_template ) ? $plugin_template : $template;
}
add_filter( 'template_include', 'two_p_growth_home_idac_template_include', 99 );

/**
 * Returns a versioned URL for a packaged plugin asset.
 *
 * @param string $path Path relative to the plugin assets directory.
 */
function two_p_growth_home_idac_asset_url( $path ) {
	return TWO_P_GROWTH_HOME_IDAC_URL . 'assets/' . ltrim( $path, '/' );
}

/**
 * Keeps large videos outside the plugin ZIP. URLs can be replaced by a CDN,
 * WordPress Media Library URLs or a hosting-specific integration through the filter.
 *
 * @param string $filename Original video filename.
 */
function two_p_growth_home_idac_video_url( $filename ) {
	$base_url = 'https://doispalitosmkt.github.io/idac-preview/assets/videos/';
	$defaults = array(
		'institucional-idac.mp4' => $base_url . 'institucional-idac.mp4',
		'depoimento-1.mp4'       => $base_url . 'depoimento-1.mp4',
		'depoimento-2.mp4'       => $base_url . 'depoimento-2.mp4',
		'depoimento-3.mp4'       => $base_url . 'depoimento-3.mp4',
	);
	$settings        = two_p_growth_home_idac_get_settings();
	$configured_urls = is_array( $settings['video_urls'] ) ? $settings['video_urls'] : array();
	$urls            = $defaults;

	foreach ( $configured_urls as $configured_filename => $configured_url ) {
		if ( $configured_url ) {
			$urls[ $configured_filename ] = $configured_url;
		}
	}

	/**
	 * Filters the external video URLs used by the IDAC home page.
	 *
	 * @param array<string, string> $urls Video URLs keyed by their original filename.
	 */
	$urls = apply_filters( 'two_p_growth_home_idac_video_urls', $urls );

	return isset( $urls[ $filename ] ) ? $urls[ $filename ] : '';
}

/**
 * Uses the WordPress privacy policy page when configured.
 */
function two_p_growth_home_idac_privacy_url() {
	$url = get_privacy_policy_url();

	return $url ? $url : home_url( '/privacidade/' );
}

/**
 * Loads the landing assets only on pages assigned to this template.
 */
function two_p_growth_home_idac_enqueue_assets() {
	if ( ! two_p_growth_home_idac_is_active_template() ) {
		return;
	}

	wp_enqueue_style(
		'two-p-growth-home-idac',
		two_p_growth_home_idac_asset_url( 'css/home.css' ),
		array(),
		TWO_P_GROWTH_HOME_IDAC_VERSION
	);

	wp_enqueue_script(
		'two-p-growth-home-idac',
		two_p_growth_home_idac_asset_url( 'js/home.js' ),
		array(),
		TWO_P_GROWTH_HOME_IDAC_VERSION,
		true
	);

	$settings = two_p_growth_home_idac_get_settings();
	$endpoint = defined( 'TWO_P_GROWTH_HOME_IDAC_RD_ENDPOINT' )
		? TWO_P_GROWTH_HOME_IDAC_RD_ENDPOINT
		: $settings['lead_endpoint'];

	wp_localize_script(
		'two-p-growth-home-idac',
		'twoPGrowthHomeConfig',
		array(
			'leadEndpoint' => esc_url_raw(
				apply_filters( 'two_p_growth_home_idac_lead_endpoint', $endpoint )
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'two_p_growth_home_idac_enqueue_assets', 20 );

/**
 * Removes page-builder assets from this standalone template only.
 *
 * Elementor and the active theme remain untouched on every other WordPress page.
 */
function two_p_growth_home_idac_remove_builder_assets() {
	if ( ! two_p_growth_home_idac_is_active_template() ) {
		return;
	}

	$blocked_sources = array(
		'/themes/hello-elementor/',
		'/plugins/elementor/',
		'/plugins/elementor-pro/',
		'/plugins/elementskit-lite/',
		'/plugins/rometheme-for-elementor/',
		'/uploads/elementor/',
	);

	global $wp_styles, $wp_scripts;

	if ( $wp_styles instanceof WP_Styles ) {
		foreach ( $wp_styles->queue as $handle ) {
			$source = isset( $wp_styles->registered[ $handle ] ) ? $wp_styles->registered[ $handle ]->src : '';
			foreach ( $blocked_sources as $blocked_source ) {
				if ( $source && false !== strpos( $source, $blocked_source ) ) {
					wp_dequeue_style( $handle );
					break;
				}
			}
		}
	}

	if ( $wp_scripts instanceof WP_Scripts ) {
		foreach ( $wp_scripts->queue as $handle ) {
			$source = isset( $wp_scripts->registered[ $handle ] ) ? $wp_scripts->registered[ $handle ]->src : '';
			foreach ( $blocked_sources as $blocked_source ) {
				if ( $source && false !== strpos( $source, $blocked_source ) ) {
					wp_dequeue_script( $handle );
					break;
				}
			}
		}
	}
}
add_action( 'wp_enqueue_scripts', 'two_p_growth_home_idac_remove_builder_assets', PHP_INT_MAX );
add_action( 'wp_print_styles', 'two_p_growth_home_idac_remove_builder_assets', PHP_INT_MAX );
add_action( 'wp_print_footer_scripts', 'two_p_growth_home_idac_remove_builder_assets', 0 );

/**
 * Returns the plugin settings with a predictable structure.
 *
 * @return array{lead_endpoint: string, video_urls: array<string, string>}
 */
function two_p_growth_home_idac_get_settings() {
	$settings = get_option( 'two_p_growth_home_idac_settings', array() );
	$settings = is_array( $settings ) ? $settings : array();

	return wp_parse_args(
		$settings,
		array(
			'lead_endpoint' => '',
			'video_urls'    => array(),
		)
	);
}

/**
 * Sanitizes settings edited through the WordPress dashboard.
 *
 * @param mixed $input Submitted settings.
 * @return array{lead_endpoint: string, video_urls: array<string, string>}
 */
function two_p_growth_home_idac_sanitize_settings( $input ) {
	$input      = is_array( $input ) ? $input : array();
	$video_urls = isset( $input['video_urls'] ) && is_array( $input['video_urls'] )
		? $input['video_urls']
		: array();
	$sanitized  = array();

	foreach ( array( 'institucional-idac.mp4', 'depoimento-1.mp4', 'depoimento-2.mp4', 'depoimento-3.mp4' ) as $filename ) {
		$sanitized[ $filename ] = isset( $video_urls[ $filename ] )
			? esc_url_raw( $video_urls[ $filename ] )
			: '';
	}

	return array(
		'lead_endpoint' => isset( $input['lead_endpoint'] ) ? esc_url_raw( $input['lead_endpoint'] ) : '',
		'video_urls'    => $sanitized,
	);
}

/**
 * Registers the settings used by the standalone home template.
 */
function two_p_growth_home_idac_register_settings() {
	register_setting(
		'two_p_growth_home_idac',
		'two_p_growth_home_idac_settings',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'two_p_growth_home_idac_sanitize_settings',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'two_p_growth_home_idac_register_settings' );

/**
 * Adds a small configuration screen so deployment does not require server access.
 */
function two_p_growth_home_idac_add_settings_page() {
	add_options_page(
		'2P Growth Home (IDAC)',
		'2P Growth Home (IDAC)',
		'manage_options',
		'two-p-growth-home-idac',
		'two_p_growth_home_idac_render_settings_page'
	);
}
add_action( 'admin_menu', 'two_p_growth_home_idac_add_settings_page' );

/**
 * Renders the plugin settings page.
 */
function two_p_growth_home_idac_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$settings    = two_p_growth_home_idac_get_settings();
	$video_names = array(
		'institucional-idac.mp4' => 'Vídeo institucional',
		'depoimento-1.mp4'       => 'Depoimento 1',
		'depoimento-2.mp4'       => 'Depoimento 2',
		'depoimento-3.mp4'       => 'Depoimento 3',
	);
	?>
	<div class="wrap">
		<h1>2P Growth Home (IDAC)</h1>
		<p>Configure a integração de leads e, quando necessário, substitua os vídeos externos sem editar arquivos do servidor.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'two_p_growth_home_idac' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="two-p-growth-home-idac-endpoint">Endpoint seguro do formulário</label></th>
					<td>
						<input class="regular-text code" id="two-p-growth-home-idac-endpoint" name="two_p_growth_home_idac_settings[lead_endpoint]" type="url" value="<?php echo esc_attr( $settings['lead_endpoint'] ); ?>" placeholder="https://..." />
						<p class="description">Use o endpoint intermediário que enviará os leads ao RD Station. Nunca informe tokens do RD nesta tela.</p>
					</td>
				</tr>
				<?php foreach ( $video_names as $filename => $label ) : ?>
					<tr>
						<th scope="row"><label for="two-p-growth-home-idac-<?php echo esc_attr( sanitize_title( $filename ) ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<input class="large-text code" id="two-p-growth-home-idac-<?php echo esc_attr( sanitize_title( $filename ) ); ?>" name="two_p_growth_home_idac_settings[video_urls][<?php echo esc_attr( $filename ); ?>]" type="url" value="<?php echo esc_attr( isset( $settings['video_urls'][ $filename ] ) ? $settings['video_urls'][ $filename ] : '' ); ?>" placeholder="URL externa opcional" />
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/**
 * Preserves the approved SEO title when the plugin template is active.
 *
 * @param string $title Current document title.
 */
function two_p_growth_home_idac_document_title( $title ) {
	if ( two_p_growth_home_idac_is_active_template() ) {
		return 'Cadaverlab | Treinamento em cadáveres Fresh Frozen | Instituto DAC';
	}

	return $title;
}
add_filter( 'pre_get_document_title', 'two_p_growth_home_idac_document_title' );

/**
 * Outputs a useful navigation until a WordPress menu is assigned to the plugin location.
 */
function two_p_growth_home_idac_menu_fallback() {
	$items = array(
		'Modalidades'  => home_url( '/#modalidades' ),
		'Estrutura'    => home_url( '/#estrutura' ),
		'Cursos'       => home_url( '/cursos/' ),
		'Quem somos'   => home_url( '/quem-somos/' ),
		'FAQ'          => home_url( '/#faq' ),
		'Localização'  => home_url( '/#localizacao' ),
	);

	echo '<ul class="menu two-p-growth-home-menu">';
	foreach ( $items as $label => $url ) {
		printf(
			'<li class="menu-item"><a href="%1$s">%2$s</a></li>',
			esc_url( $url ),
			esc_html( $label )
		);
	}
	echo '</ul>';
}

/**
 * Shows concise activation instructions until a page uses the template.
 */
function two_p_growth_home_idac_admin_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$assigned_pages = get_posts(
		array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => 1,
			'meta_key'       => '_wp_page_template',
			'meta_value'     => TWO_P_GROWTH_HOME_IDAC_TEMPLATE,
			'fields'         => 'ids',
		)
	);

	if ( $assigned_pages ) {
		return;
	}

	printf(
		'<div class="notice notice-info"><p><strong>%1$s</strong> %2$s <a href="%3$s">%4$s</a></p></div>',
		esc_html( '2P Growth Home (IDAC):' ),
		esc_html( 'crie ou edite uma página e selecione o template “2P Growth Home (IDAC)” em Atributos da página.' ),
		esc_url( admin_url( 'post-new.php?post_type=page' ) ),
		esc_html( 'Criar página' )
	);
}
add_action( 'admin_notices', 'two_p_growth_home_idac_admin_notice' );

/**
 * Reads the public update manifest produced by the private source repository.
 * No GitHub credential is stored in WordPress.
 *
 * @return array<string, mixed>|false
 */
function two_p_growth_home_idac_get_update_manifest() {
	$cache_key = 'two_p_growth_home_idac_update_manifest';
	$cached    = get_site_transient( $cache_key );

	if ( is_array( $cached ) ) {
		return $cached;
	}

	$response = wp_remote_get(
		TWO_P_GROWTH_HOME_IDAC_UPDATE_MANIFEST,
		array(
			'timeout'    => 6,
			'user-agent' => '2P Growth Home (IDAC)/' . TWO_P_GROWTH_HOME_IDAC_VERSION,
		)
	);

	if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
		return false;
	}

	$manifest = json_decode( wp_remote_retrieve_body( $response ), true );
	if (
		! is_array( $manifest ) ||
		empty( $manifest['version'] ) ||
		empty( $manifest['download_url'] )
	) {
		return false;
	}

	set_site_transient( $cache_key, $manifest, 6 * HOUR_IN_SECONDS );

	return $manifest;
}

/**
 * Adds releases from the public distribution channel to WordPress Updates.
 *
 * @param mixed $transient WordPress update transient.
 * @return mixed
 */
function two_p_growth_home_idac_check_for_update( $transient ) {
	if ( ! is_object( $transient ) ) {
		return $transient;
	}

	$manifest = two_p_growth_home_idac_get_update_manifest();
	if ( ! $manifest || version_compare( TWO_P_GROWTH_HOME_IDAC_VERSION, $manifest['version'], '>=' ) ) {
		return $transient;
	}

	$plugin_file = plugin_basename( TWO_P_GROWTH_HOME_IDAC_FILE );
	$update      = (object) array(
		'id'           => TWO_P_GROWTH_HOME_IDAC_UPDATE_MANIFEST,
		'slug'         => TWO_P_GROWTH_HOME_IDAC_SLUG,
		'plugin'       => $plugin_file,
		'new_version'  => sanitize_text_field( $manifest['version'] ),
		'url'          => esc_url_raw( isset( $manifest['homepage'] ) ? $manifest['homepage'] : '' ),
		'package'      => esc_url_raw( $manifest['download_url'] ),
		'requires'     => sanitize_text_field( isset( $manifest['requires'] ) ? $manifest['requires'] : '6.2' ),
		'requires_php' => sanitize_text_field( isset( $manifest['requires_php'] ) ? $manifest['requires_php'] : '7.4' ),
	);

	$transient->response[ $plugin_file ] = $update;

	return $transient;
}
add_filter( 'site_transient_update_plugins', 'two_p_growth_home_idac_check_for_update' );

/**
 * Supplies the plugin details modal shown by the WordPress update screen.
 *
 * @param mixed  $result Existing API result.
 * @param string $action Requested API action.
 * @param object $args   Request arguments.
 * @return mixed
 */
function two_p_growth_home_idac_plugin_information( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || TWO_P_GROWTH_HOME_IDAC_SLUG !== $args->slug ) {
		return $result;
	}

	$manifest = two_p_growth_home_idac_get_update_manifest();
	if ( ! $manifest ) {
		return $result;
	}

	return (object) array(
		'name'          => '2P Growth Home (IDAC)',
		'slug'          => TWO_P_GROWTH_HOME_IDAC_SLUG,
		'version'       => sanitize_text_field( $manifest['version'] ),
		'author'        => '<a href="https://doispalitosmkt.com.br/">Dois Palitos Marketing Digital</a>',
		'homepage'      => esc_url_raw( isset( $manifest['homepage'] ) ? $manifest['homepage'] : '' ),
		'requires'      => sanitize_text_field( isset( $manifest['requires'] ) ? $manifest['requires'] : '6.2' ),
		'requires_php'  => sanitize_text_field( isset( $manifest['requires_php'] ) ? $manifest['requires_php'] : '7.4' ),
		'download_link' => esc_url_raw( $manifest['download_url'] ),
		'sections'      => array(
			'description' => wp_kses_post( isset( $manifest['description'] ) ? $manifest['description'] : '' ),
			'changelog'   => wp_kses_post( isset( $manifest['changelog'] ) ? $manifest['changelog'] : '' ),
		),
	);
}
add_filter( 'plugins_api', 'two_p_growth_home_idac_plugin_information', 10, 3 );

/**
 * Forces a fresh manifest check after activation.
 */
function two_p_growth_home_idac_clear_update_cache() {
	delete_site_transient( 'two_p_growth_home_idac_update_manifest' );
}
register_activation_hook( TWO_P_GROWTH_HOME_IDAC_FILE, 'two_p_growth_home_idac_clear_update_cache' );

